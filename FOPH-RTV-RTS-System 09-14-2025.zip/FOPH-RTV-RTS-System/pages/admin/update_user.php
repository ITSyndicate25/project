<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/includes/functions.php';

header('Content-Type: application/json');

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

// Get and sanitize POST data
$user_id = intval($_POST['user_id'] ?? 0);
$username = $_POST['username'] ?? '';
$requestor_name = $_POST['requestor_name'] ?? '';
$department = $_POST['department'] ?? '';
$email = $_POST['email'] ?? '';
$roles = $_POST['role'] ?? [];
$categories = $_POST['category'] ?? [];

// If roles are received as an array, join them into a comma-separated string
$role_string = is_array($roles) ? implode(',', $roles) : trim($roles);

// If categories are received as an array, join them into a comma-separated string
$category_string = is_array($categories) ? implode(',', $categories) : trim($categories);

// Call the function without the e-signature parameter
$result = updateUser($user_id, $username, $requestor_name, $department, $email, $role_string, $category_string);

// Return the result as a JSON response
echo json_encode($result);

?>