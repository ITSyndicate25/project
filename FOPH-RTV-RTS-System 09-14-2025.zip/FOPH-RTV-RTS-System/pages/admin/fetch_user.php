<?php
ob_start();

session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/includes/functions.php';

header('Content-Type: application/json');
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['draw' => 0, 'recordsTotal' => 0, 'recordsFiltered' => 0, 'data' => [], 'error' => 'Access denied']);
    ob_end_flush(); 
    exit();
}

try {
    // Get DataTables parameters from the GET request
    $dataTableParams = $_GET;

    // Call the reusable function
    $response = getUsersForDataTable($dataTableParams);

    // Check for errors from the function
    if (isset($response['error'])) {
        http_response_code(500);
        echo json_encode(['draw' => $dataTableParams['draw'], 'recordsTotal' => 0, 'recordsFiltered' => 0, 'data' => [], 'error' => 'Error fetching users: ' . $response['error']]);
    } else {
        echo json_encode($response);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['draw' => 0, 'recordsTotal' => 0, 'recordsFiltered' => 0, 'data' => [], 'error' => 'An unexpected error occurred: ' . $e->getMessage()]);
}

ob_end_flush();