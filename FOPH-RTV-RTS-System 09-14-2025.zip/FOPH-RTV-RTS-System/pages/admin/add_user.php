<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/includes/functions.php';

header('Content-Type: application/json');

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit();
}

// Get inputs from the POST request
// Pass the raw POST data and file data directly to the function
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
$requestor_name = $_POST['requestor_name'] ?? '';
$department = $_POST['department'] ?? '';
$id_number = $_POST['id_number'] ?? '';
$email = $_POST['email'] ?? '';
$role = $_POST['role'] ?? [];
$category = $_POST['category'] ?? [];
$e_signature = $_FILES['e_signiture'] ?? null; // Get the uploaded file array

// Call the function
$result = addUser($username, $password, $role, $requestor_name, $department, $id_number, $email, $category, $e_signature);

// Return the result as a JSON response
echo json_encode($result);
?>