<?php
session_start();
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not authenticated.']);
    exit();
}

$current_user_id = $_SESSION['user_id'];

try {
    $db = new Connection();
    $conn = $db->link;

    $draw = $_POST['draw'] ?? 1;
    $start = intval($_POST['start'] ?? 0);
    $length = intval($_POST['length'] ?? 10);
    $search_value = $_POST['search']['value'] ?? '';

    // Build query for recent activities with corrected action labels
    $base_query = "
        SELECT 
            id,
            control_no,
            requestor_name,
            material_status,
            CASE 
                WHEN checked_by_id = ? AND checked_status = 'Approved' THEN 'Checked'
                WHEN checked_by_id = ? AND checked_status = 'Disapproved' THEN 'Disapproved (as Checker)'
                WHEN approved_by_id = ? AND approved_status = 'Approved' THEN 'Approved'
                WHEN approved_by_id = ? AND approved_status = 'Disapproved' THEN 'Disapproved (as Approver)'
                WHEN noted_by_id = ? AND noted_status = 'Approved' THEN 'Noted'
                WHEN noted_by_id = ? AND noted_status = 'Disapproved' THEN 'Disapproved (as Noter)'
            END as action_taken,
            CASE 
                WHEN checked_by_id = ? THEN checked_at
                WHEN approved_by_id = ? THEN approved_at
                WHEN noted_by_id = ? THEN noted_at
            END as action_date
        FROM rts_forms
        WHERE (checked_by_id = ? OR approved_by_id = ? OR noted_by_id = ?)
        AND (
            (checked_by_id = ? AND checked_at IS NOT NULL) OR
            (approved_by_id = ? AND approved_at IS NOT NULL) OR
            (noted_by_id = ? AND noted_at IS NOT NULL)
        )
    ";

    $user_params = array_fill(0, 15, $current_user_id);
    
    // Add search
    if (!empty($search_value)) {
        $base_query .= " AND (control_no LIKE ? OR requestor_name LIKE ?)";
        $search_param = '%' . $search_value . '%';
        $user_params[] = $search_param;
        $user_params[] = $search_param;
    }

    // Count total
    $count_query = "SELECT COUNT(*) FROM (" . $base_query . ") as count_table";
    $stmt_count = sqlsrv_query($conn, $count_query, $user_params);
    $total_records = 0;
    if ($stmt_count && sqlsrv_fetch($stmt_count)) {
        $total_records = sqlsrv_get_field($stmt_count, 0);
    }

    // Final query with pagination
    $final_query = $base_query . " ORDER BY action_date DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
    $user_params[] = $start;
    $user_params[] = $length;

    $stmt = sqlsrv_query($conn, $final_query, $user_params);

    if ($stmt === false) {
        throw new Exception("Database query failed: " . print_r(sqlsrv_errors(), true));
    }

    $data = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if (isset($row['action_date']) && $row['action_date'] instanceof DateTime) {
            $row['action_date'] = $row['action_date']->format('Y-m-d H:i:s');
        }
        $data[] = $row;
    }

    echo json_encode([
        'status' => 'success',
        'draw' => intval($draw),
        'recordsTotal' => intval($total_records),
        'recordsFiltered' => intval($total_records),
        'data' => $data
    ]);

    $db->close();

} catch (Exception $e) {
    error_log("Error in fetch_recent_activities: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'An internal server error occurred.']);
}
?>