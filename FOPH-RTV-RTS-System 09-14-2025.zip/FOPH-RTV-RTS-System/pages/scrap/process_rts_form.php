<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/includes/functions.php';
require_once APP_ROOT . '/assets/db/connection.php';

// Set the content type to JSON to handle the AJAX request
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit();
}

$userData = getUserData($_SESSION['user_id']);
if (!$userData['success']) {
    echo json_encode(['status' => 'error', 'message' => 'User data not found.']);
    exit();
}

$user_department = $userData['data']['department'];
$user_role = $userData['data']['role'];

if (!checkScrapPermission($user_department, $user_role)) {
    echo json_encode(['status' => 'error', 'message' => 'Insufficient permissions.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = null;
    try {
        $control_no = generateRTSNumber();
        if ($control_no === false) {
            throw new Exception("Failed to generate RTS control number.");
        }

        $db = new Connection();
        $conn = $db->link;

        if (!sqlsrv_begin_transaction($conn)) {
            throw new Exception("Failed to start DB transaction: " . print_r(sqlsrv_errors(), true));
        }

        // Prepare RTS form data
        $requestor_id = $_SESSION['user_id'];
        $requestor_name = $_SESSION['username'];
        $requestor_department = $user_department;

        $material_type_arr = $_POST['material_type'] ?? [];
        $material_type = !empty($material_type_arr) ? implode(', ', $material_type_arr) : null;
        
        // **IMPORTANT CHANGE:** Explicitly set material_status to 'Pending'
        $material_status = 'Pending';

        $judgement_arr = $_POST['judgement'] ?? [];
        $judgement = !empty($judgement_arr) ? implode(', ', $judgement_arr) : null;

        $details = $_POST['details'] ?? null;
        $remark = $_POST['remark'] ?? null;
        $return_date = !empty($_POST['return_date']) ? date('Y-m-d', strtotime($_POST['return_date'])) : null;

        $department = $_POST['department'] ?? null;
        $model = $_POST['model'] ?? null;
        $sap_loc_code = $_POST['sap_location']['from'] ?? null;

        $prepared_by = $_SESSION['username'];

        $prepared_by_signature_image = $userData['data']['e_signiture'] ?? null;
        
        $checked_by = null;
        $approved_by = null;
        $noted_by = null;
        $checked_by_id = null;
        $approved_by_id = null;
        $noted_by_id = null;
        $checked_at = null;
        $approved_at = null;
        $noted_at = null;

        $checked_status = 'Pending';
        $approved_status = 'Pending';
        $noted_status = 'Pending';

        $sql_insert_form = "
            INSERT INTO rts_forms
                (control_no, requestor_id, requestor_name, requestor_department, material_type, material_status, judgement, details, remark, return_date, department, model, sap_loc_code, prepared_by, checked_by, approved_by, noted_by, checked_status, approved_status, noted_status, checked_by_id, approved_by_id, noted_by_id, checked_at, approved_at, noted_at, prepared_by_signature_image)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ";

        $params_insert_form = [
            [$control_no, SQLSRV_PARAM_IN],
            [$requestor_id, SQLSRV_PARAM_IN],
            [$requestor_name, SQLSRV_PARAM_IN],
            [$requestor_department, SQLSRV_PARAM_IN],
            [$material_type, SQLSRV_PARAM_IN],
            [$material_status, SQLSRV_PARAM_IN],
            [$judgement, SQLSRV_PARAM_IN],
            [$details, SQLSRV_PARAM_IN],
            [$remark, SQLSRV_PARAM_IN],
            [$return_date, SQLSRV_PARAM_IN],
            [$department, SQLSRV_PARAM_IN],
            [$model, SQLSRV_PARAM_IN],
            [$sap_loc_code, SQLSRV_PARAM_IN],
            [$prepared_by, SQLSRV_PARAM_IN],
            [$checked_by, SQLSRV_PARAM_IN],
            [$approved_by, SQLSRV_PARAM_IN],
            [$noted_by, SQLSRV_PARAM_IN],
            [$checked_status, SQLSRV_PARAM_IN],
            [$approved_status, SQLSRV_PARAM_IN],
            [$noted_status, SQLSRV_PARAM_IN],
            [$checked_by_id, SQLSRV_PARAM_IN],
            [$approved_by_id, SQLSRV_PARAM_IN],
            [$noted_by_id, SQLSRV_PARAM_IN],
            [$checked_at, SQLSRV_PARAM_IN],
            [$approved_at, SQLSRV_PARAM_IN],
            [$noted_at, SQLSRV_PARAM_IN],
            [$prepared_by_signature_image, SQLSRV_PARAM_IN, SQLSRV_PHPTYPE_STREAM(SQLSRV_ENC_BINARY), SQLSRV_SQLTYPE_VARBINARY('max')]
        ];
        
        $stmt = sqlsrv_prepare($conn, $sql_insert_form, $params_insert_form);

        if ($stmt === false) {
             throw new Exception("SQL Prepare Error (rts_forms): " . print_r(sqlsrv_errors(), true));
        }

        if (!sqlsrv_execute($stmt)) {
            throw new Exception("SQL Insert Error (rts_forms): " . print_r(sqlsrv_errors(), true));
        }
        
        $inserted = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        if (!$inserted || !isset($inserted['id'])) {
            throw new Exception("Failed to retrieve inserted RTS form ID.");
        }
        $rts_form_id = $inserted['id'];

        $material_details = $_POST['material_details'] ?? [];

        $ref_no_arr = $material_details['ref_no'] ?? [];
        $sap_doc_arr = $material_details['sap_doc'] ?? [];
        $invoice_no_arr = $material_details['invoice_no'] ?? [];
        $supplier_arr = $material_details['supplier'] ?? [];
        $part_name_arr = $material_details['part_name'] ?? [];
        $part_number_arr = $material_details['part_number'] ?? [];
        $description_arr = $material_details['description'] ?? [];
        $qty_returned_arr = $material_details['qty_returned'] ?? [];
        $qty_received_arr = $material_details['qty_received'] ?? [];
        $amount_arr = $material_details['amount'] ?? [];
        $due_date_arr = $material_details['due_date'] ?? [];

        $received_by_arr = array_fill(0, count($ref_no_arr), null);

        $count_materials = count($ref_no_arr);
        $sql_insert_material = "
            INSERT INTO rts_materials
                (rts_form_id, ref_no, sap_doc, invoice_no, supplier, part_name, part_number, description, qty_returned, qty_received, amount, due_date, received_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ";

        for ($i = 0; $i < $count_materials; $i++) {
            $all_empty = empty($ref_no_arr[$i]) && empty($sap_doc_arr[$i])
                && empty($invoice_no_arr[$i]) && empty($supplier_arr[$i]) && empty($part_name_arr[$i]) 
                && empty($part_number_arr[$i]) && empty($description_arr[$i]) && empty($qty_returned_arr[$i]) 
                && empty($qty_received_arr[$i]) && empty($amount_arr[$i]) && empty($due_date_arr[$i]);

            if ($all_empty) {
                continue;
            }

            $due_date = !empty($due_date_arr[$i]) ? date('Y-m-d', strtotime($due_date_arr[$i])) : null;

            $qty_returned = isset($qty_returned_arr[$i]) && $qty_returned_arr[$i] !== '' ? (int)$qty_returned_arr[$i] : null;
            $qty_received = isset($qty_received_arr[$i]) && $qty_received_arr[$i] !== '' ? (int)$qty_received_arr[$i] : null;
            $amount = isset($amount_arr[$i]) && $amount_arr[$i] !== '' ? (int)$amount_arr[$i] : null;

            $params_material = [
                $rts_form_id,
                $ref_no_arr[$i],
                $sap_doc_arr[$i],
                $invoice_no_arr[$i],
                $supplier_arr[$i],
                $part_name_arr[$i],
                $part_number_arr[$i],
                $description_arr[$i],
                $qty_returned,
                $qty_received,
                $amount,
                $due_date,
                $received_by_arr[$i]
            ];

            $stmt_material = sqlsrv_query($conn, $sql_insert_material, $params_material);
            if ($stmt_material === false) {
                throw new Exception("SQL Insert Error (rts_materials) at index $i: " . print_r(sqlsrv_errors(), true));
            }
        }
        
        if (!sqlsrv_commit($conn)) {
            throw new Exception("Failed to commit database transaction: " . print_r(sqlsrv_errors(), true));
        }
        
        $checker_emails = [];
        $sql_checkers = "SELECT email FROM users WHERE role LIKE '%checker%'";
        $stmt_checkers = sqlsrv_query($conn, $sql_checkers);
        if ($stmt_checkers === false) {
            error_log("Failed to fetch checker emails: " . print_r(sqlsrv_errors(), true));
        } else {
            while ($row = sqlsrv_fetch_array($stmt_checkers, SQLSRV_FETCH_ASSOC)) {
                $checker_emails[] = $row['email'];
            }
        }
        
        // Check if any checker emails were found
        if (!empty($checker_emails)) {
            // --- Include the email script with the recipient emails ---
            include APP_ROOT . '/pages/scrap/send_email_rts.php';
            sendEmailRTS($checker_emails, $control_no); 
        } else {
             // Log this for debugging purposes
            error_log("No users with 'checker' role found to send an email to.");
        }

        echo json_encode([
            'status' => 'success',
            'control_no' => $control_no,
            'message' => 'RTS form submitted successfully and notification sent.'
        ]);
        exit();

    } catch (Exception $e) {
        if ($db && $db->link) {
            sqlsrv_rollback($db->link);
        }
        
        // Return a JSON error response.
        echo json_encode([
            'status' => 'error',
            'message' => 'An error occurred: ' . $e->getMessage()
        ]);
        exit();
    } finally {
        if ($db) {
            $db->close();
        }
    }
} else {

    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method.'
    ]);
    exit();
}