<?php
// includes/heartbeat.php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}

try {
    $conn = new Connection();
    $session_id = session_id();
    $user_id = $_SESSION['user_id'];
    
    // Check if session exists
    $check_sql = "SELECT session_id FROM active_sessions WHERE session_id = ?";
    $check_stmt = sqlsrv_query($conn->link, $check_sql, array($session_id));
    
    if ($check_stmt && sqlsrv_has_rows($check_stmt)) {
        // Update existing
        $update_sql = "UPDATE active_sessions SET last_activity = GETDATE() WHERE session_id = ?";
        $result = sqlsrv_query($conn->link, $update_sql, array($session_id));
    } else {
        // Insert new
        $insert_sql = "INSERT INTO active_sessions (session_id, user_id, last_activity) VALUES (?, ?, GETDATE())";
        $result = sqlsrv_query($conn->link, $insert_sql, array($session_id, $user_id));
    }
    
    // Clean up old sessions
    $cleanup_sql = "DELETE FROM active_sessions WHERE last_activity < DATEADD(minute, -30, GETDATE())";
    sqlsrv_query($conn->link, $cleanup_sql);
    
    $conn->close();
    
    echo json_encode(['status' => 'success', 'session_id' => substr($session_id, 0, 10) . '...']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>