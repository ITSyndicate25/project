<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../../login.php');
    exit();
}
?>



<?php include '../../includes/header.php'; ?>

<div class="wrapper">
    <?php include '../../includes/sidebar.php'; ?>
    <div class="main-panel">
        <?php include '../../includes/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="card-title m-0">User Management</h4>
                                <button class="btn btn-primary btn-round" id="addUserButton">
                                    <span class="d-none d-lg-inline">Add New User</span>
                                    <span class="d-lg-none"><i class="fa fa-plus"></i></span>
                                </button>
                            </div>
                            <div class="card-body">
                                <div id="loading" class="text-center">
                                    <i class="fa fa-spinner fa-spin fa-2x"></i>
                                    <p>Loading users...</p>
                                </div>
                                <div id="error-message" class="alert alert-danger" style="display: none;"></div>
                                <div class="table-responsive" id="users-table-container" style="display: none;">
                                <table id="users-table" class="table table-striped table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Department</th>
                                            <th>Category</th>
                                            <th>Date Created</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include '../../includes/footer.php'; ?>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Add User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="addUserForm">
                <div class="modal-body">
                    <input type="hidden" id="add_user_id" name="user_id">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="add_id_number">Employee ID Number</label>
                                <input type="text" class="form-control" id="add_id_number" name="id_number" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="add_username">Username</label>
                                <input type="text" class="form-control" id="add_username" name="username" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="add_password">Password</label>
                                <input type="password" class="form-control" id="add_password" name="password" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="add_requestor_name">Requestor Name</label>
                                <input type="text" class="form-control" id="add_requestor_name" name="requestor_name" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="add_department">Department</label>
                                <select class="form-control" id="add_department" name="department" required>
                                    <option value="">Select Department</option>
                                    <option value="Engineering">Engineering</option>
                                    <option value="Logistics">Logistics</option>
                                    <option value="LX">LX</option>
                                    <option value="INSTAX">INSTAX</option>
                                    <option value="PT">PT</option>
                                    <option value="LENS">LENS</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="add_email">Email address</label>
                                <input type="email" class="form-control" id="add_email" name="email" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="add_role">User Role</label>
                                <select class="form-control" id="add_role" name="role[]" multiple required>
                                    <option value="user">User</option>
                                    <option value="checker">Checker</option>
                                    <option value="approver">Approver</option>
                                    <option value="noter">Noter</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="add_category">Category</label>
                                <select class="form-control" id="add_category" name="category[]" multiple required>
                                    <option value="Good">Good</option>
                                    <option value="Material Defect">Material Defect</option>
                                    <option value="Human Error">Human Error</option>
                                    <option value="Others">Others</option>
                                    <option value="EOL">EOL</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="add_e_signiture">Signature</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="add_e_signiture" name="e_signiture" accept="image/*">
                                <label class="custom-file-label" for="add_e_signiture" id="file-label">Choose file...</label>
                            </div>
                            <small class="form-text text-muted">Upload an image file for the user's e-signature.</small>
                        </div>
                    </div>
                    <div id="add-user-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" id="addUserSubmitBtn">Add User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editUserForm">
                <div class="modal-body">
                    <input type="hidden" id="edit_user_id" name="user_id">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="edit_username">Username</label>
                                <input type="text" class="form-control" id="edit_username" name="username" required readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="edit_requestor_name">Requestor Name</label>
                                <input type="text" class="form-control" id="edit_requestor_name" name="requestor_name" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="edit_id_number">Employee ID Number</label>
                                <input type="text" class="form-control" id="edit_id_number" name="id_number" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="edit_email">Email address</label>
                                <input type="email" class="form-control" id="edit_email" name="email" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="edit_role">User Role</label>
                                <select class="form-control" id="edit_role" name="role[]" multiple required>
                                    <option value="user">User</option>
                                    <option value="checker">Checker</option>
                                    <option value="approver">Approver</option>
                                    <option value="noter">Noter</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="edit_category">Category</label>
                                <select class="form-control" id="edit_category" name="category[]" multiple required>
                                    <option value="Good">Good</option>
                                    <option value="Material Defect">Material Defect</option>
                                    <option value="Human Error">Human Error</option>
                                    <option value="Others">Others</option>
                                    <option value="EOL">EOL</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="edit_department">Department</label>
                                <select class="form-control" id="edit_department" name="department" required>
                                    <option value="">Select Department</option>
                                    <option value="Engineering">Engineering</option>
                                    <option value="Logistics">Logistics</option>
                                    <option value="LX">LX</option>
                                    <option value="INSTAX">INSTAX</option>
                                    <option value="PT">PT</option>
                                    <option value="LENS">LENS</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div id="edit-user-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" id="editUserSubmitBtn">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div class="modal fade" id="changePasswordModal" tabindex="-1" role="dialog" aria-labelledby="changePasswordModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="changePasswordModalLabel">Change User Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="changePasswordForm">
                <div class="modal-body">
                    <input type="hidden" id="change_password_user_id" name="user_id">
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_new_password">Confirm New Password</label>
                        <input type="password" class="form-control" id="confirm_new_password"
                            name="confirm_new_password" required>
                    </div>
                    <div id="change-password-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" id="changePasswordSubmitBtn">Change Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Verify Password Modal -->
<div class="modal fade" id="verifyPasswordModal" tabindex="-1" role="dialog" aria-labelledby="verifyPasswordModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="verifyPasswordModalLabel">Admin Password Verification</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="verifyPasswordForm">
                <div class="modal-body">
                    <p>Please enter your password to confirm this action.</p>
                    <div class="form-group">
                        <label for="admin_password">Admin Password</label>
                        <input type="password" class="form-control" id="admin_password" name="admin_password" required>
                    </div>
                    <div id="verify-password-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="verifyPasswordSubmitBtn">Verify and
                        Proceed</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get references to the file input and the label
        const fileInput = document.getElementById('add_e_signiture');
        const fileLabel = document.getElementById('file-label');

        fileInput.addEventListener('change', function(e) {
            const fileName = e.target.files[0].name;

            fileLabel.textContent = fileName;
        });
    });
    $(document).ready(function () {
        let userTable = null;
        let currentAction = '';
        let userToUpdate = {};
        let userToChangePassword = null;

        // Function to initialize the DataTable
        function initializeUserTable() {
            $('#loading').show();
            $('#users-table-container').hide();
            $('#error-message').hide();

            userTable = $('#users-table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "fetch_user.php",
                    "type": "GET",
                    "dataSrc": "data",
                    "error": function (xhr, error, thrown) {
                        $('#loading').hide();
                        $('#users-table-container').hide();
                        $('#error-message').text("Failed to load user data. Please check the server response and the console for details.").show();
                        console.error("AJAX error:", error, thrown);
                        console.log("Server response:", xhr.responseText);
                    }
                },
                "columns": [
                    { "data": "id" },
                    { "data": "username" },
                    { "data": "requestor_name" },
                    { "data": "email" },
                    {
                        "data": "role",
                        "render": function (data) {
                            const roles = data ? data.split(',').map(role => role.trim()) : [];
                            return roles.map(role => {
                                let badgeClass = 'badge-primary';
                                if (role === 'admin') {
                                    badgeClass = 'badge-danger';
                                } else if (role === 'checker') {
                                    badgeClass = 'badge-info';
                                } else if (role === 'approver') {
                                    badgeClass = 'badge-success';
                                } else if (role === 'noter') {
                                    badgeClass = 'badge-warning';
                                }
                                return `<span class="badge ${badgeClass} mr-1">${role.charAt(0).toUpperCase() + role.slice(1)}</span>`;
                            }).join('');
                        }
                    },
                    { "data": "department" },
                    {
                        "data": "category",
                        "render": function(data) {
                            if (data) {
                                const categories = data.split(',').map(cat => cat.trim());
                                return categories.map(cat => `<span class="badge badge-secondary mr-1">${cat}</span>`).join('');
                            }
                            return '';
                        }
                    },
                    { "data": "created_at" },
                    {
                        "data": null,
                        "orderable": false,
                        "searchable": false,
                        "render": function (data, type, row) {
                            return `
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        More
                                    </button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item edit-user" href="#" data-id="${row.id}">
                                            <i class="fa fa-edit text-info mr-2"></i> Update User
                                        </a>
                                        <a class="dropdown-item change-password" href="#" data-id="${row.id}">
                                            <i class="fa fa-key text-warning mr-2"></i> Change Password
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item delete-user" href="#" data-id="${row.id}">
                                            <i class="fa fa-trash text-danger mr-2"></i> Delete User
                                        </a>
                                    </div>
                                </div>
                            `;
                        }
                    }
                ],
                "dom": '<"row"<"col-md-12 text-center"B>>' +
                    '<"row"<"col-md-6"l><"col-md-6"f>>' +
                    '<"row"<"col-md-12"t>>' +
                    '<"row"<"col-md-5"i><"col-md-7"p>>',
                "buttons": [
                    'copy', 'csv', 'excel', 'pdf', 'print',
                    {
                        extend: 'colvis',
                        text: 'Column Visibility'
                    }
                ],
                "lengthMenu": [[10, 20, 30, -1], [10, 20, 30, "All"]],
                "pageLength": 10,
                "initComplete": function () {
                    $('#loading').hide();
                    $('#users-table-container').show();
                },
                "drawCallback": function () {
                    $('#loading').hide();
                    $('#users-table-container').show();
                }
            });
        }

        initializeUserTable();

        // --- Event Listeners and Functions ---
        
        // This is the new part. It listens for input in the ID Number field
        // and sets the Username field to the same value for the Add User modal.
        $('#add_id_number').on('input', function() {
            $('#add_username').val($(this).val());
        });

        $('#addUserButton').click(function () {
            $('#addUserForm')[0].reset();
            $('#add_role').val(null).trigger('change');
            $('#add_category').val(null).trigger('change');
            $('#addUserModal').modal('show');
        });

        // Handle delete button click using event delegation
        $('#users-table').on('click', '.delete-user', function () {
            const userId = $(this).data('id');
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'delete_user.php',
                        type: 'POST',
                        data: { user_id: userId },
                        dataType: 'json',
                        success: function (response) {
                            if (response.success) {
                                Swal.fire('Deleted!', 'The user has been deleted.', 'success');
                                userTable.ajax.reload();
                            } else {
                                Swal.fire('Failed!', response.message || 'There was an error deleting the user.', 'error');
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire('Error!', 'An error occurred while communicating with the server.', 'error');
                            console.error("AJAX Error:", status, error, xhr.responseText);
                        }
                    });
                }
            });
        });

        // Handle Add User Form Submission
        $('#addUserForm').submit(function (e) {
            e.preventDefault();
            const selectedRoles = $('#add_role').val();
            
            if (selectedRoles && selectedRoles.includes('admin')) {
                currentAction = 'add';
                $('#addUserModal').modal('hide');
                $('#verifyPasswordModal').modal('show');
                $('#admin_password').val('');
            } else {
                submitAddUserForm();
            }
        });

        // This is the new part for the Edit User modal.
        // It listens for input in the ID Number field and updates the Username field.
        $('#edit_id_number').on('input', function() {
            $('#edit_username').val($(this).val());
        });

        // Handle Edit button click using event delegation
        $('#users-table').on('click', '.edit-user', function () {
            const userId = $(this).data('id');
            $.ajax({
                url: 'get_user_update.php',
                type: 'GET',
                data: { user_id: userId },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        userToUpdate = response.data;
                        $('#edit_user_id').val(userToUpdate.id);
                        
                        // Set the ID Number and then update the Username field
                        $('#edit_id_number').val(userToUpdate.id_number);
                        $('#edit_username').val(userToUpdate.id_number);
                        
                        $('#edit_requestor_name').val(userToUpdate.requestor_name);
                        $('#edit_department').val(userToUpdate.department);
                        $('#edit_email').val(userToUpdate.email);
                        
                        // Parse and set the multiple categories for the edit modal
                        const categories = userToUpdate.category ? userToUpdate.category.split(',').map(cat => cat.trim()) : [];
                        $('#edit_category').val(categories).trigger('change');
                        
                        // Parse and set the multiple roles for the edit modal
                        const roles = userToUpdate.role ? userToUpdate.role.split(',').map(role => role.trim()) : [];
                        $('#edit_role').val(roles).trigger('change');

                        currentAction = 'edit';
                        $('#editUserModal').modal('show');
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function (xhr, status, error) {
                    Swal.fire('Error!', 'An error occurred fetching user data.', 'error');
                    console.error("AJAX Error:", status, error, xhr.responseText);
                }
            });
        });

        // Handle Edit User Form Submission
        $('#editUserForm').submit(function (e) {
            e.preventDefault();
            const newRoles = $('#edit_role').val();
            const oldRoles = userToUpdate.role ? userToUpdate.role.split(',').map(role => role.trim()) : [];
            const newIsAdmin = newRoles && newRoles.includes('admin');
            const oldIsAdmin = oldRoles && oldRoles.includes('admin');

            if (newIsAdmin && !oldIsAdmin) {
                currentAction = 'edit';
                $('#editUserModal').modal('hide');
                $('#verifyPasswordModal').modal('show');
                $('#admin_password').val('');
            } else {
                submitUpdateUserForm();
            }
        });

        // Handle Change Password Button Click
        $('#users-table').on('click', '.change-password', function () {
            userToChangePassword = $(this).data('id');
            $('#changePasswordForm')[0].reset();
            $('#change_password_user_id').val(userToChangePassword);
            $('#changePasswordModal').modal('show');
        });

        // Handle Change Password Form Submission
        $('#changePasswordForm').submit(function (e) {
            e.preventDefault();
            const newPassword = $('#new_password').val();
            const confirmNewPassword = $('#confirm_new_password').val();
            const submitBtn = $('#changePasswordSubmitBtn');

            if (newPassword !== confirmNewPassword) {
                Swal.fire('Error!', 'New password and confirmation do not match.', 'error');
                return;
            }

            currentAction = 'change_password';
            $('#changePasswordModal').modal('hide');
            $('#verifyPasswordModal').modal('show');
            $('#admin_password').val('');
        });

        // Handle Password Verification Form Submission
        $('#verifyPasswordForm').submit(function (e) {
            e.preventDefault();
            const adminPassword = $('#admin_password').val();
            const verifyBtn = $('#verifyPasswordSubmitBtn');
            verifyBtn.prop('disabled', true).text('Verifying...');

            $.ajax({
                url: 'verify_admin_password.php',
                type: 'POST',
                data: { admin_password: adminPassword },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        $('#verifyPasswordModal').modal('hide');
                        if (currentAction === 'add') {
                            submitAddUserForm();
                        } else if (currentAction === 'edit') {
                            submitUpdateUserForm();
                        } else if (currentAction === 'change_password') {
                            submitChangePasswordForm();
                        }
                    } else {
                        $('#verify-password-message').removeClass('alert-success').addClass('alert-danger').text(response.message).show();
                    }
                },
                error: function (xhr, status, error) {
                    $('#verify-password-message').removeClass('alert-success').addClass('alert-danger').text('An error occurred during verification.').show();
                    console.error("Verification AJAX Error:", status, error, xhr.responseText);
                },
                complete: function () {
                    verifyBtn.prop('disabled', false).text('Verify and Proceed');
                }
            });
        });

            function submitAddUserForm() {
            const form = $('#addUserForm');
            const submitBtn = $('#addUserSubmitBtn');
            submitBtn.prop('disabled', true).text('Adding...');

            // Create a new FormData object
            const formData = new FormData(form[0]);

            $.ajax({
                url: 'add_user.php',
                type: 'POST',
                data: formData, // Use the FormData object
                dataType: 'json',
                processData: false, 
                contentType: false, 
                success: function (response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'User Added!',
                            text: 'The new user has been added successfully.',
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            $('#addUserModal').modal('hide');
                            userTable.ajax.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: response.message || 'Error adding user.',
                        });
                    }
                },
                error: function (xhr, status, error) {
                    let errorMsg = 'An error occurred. Please try again.';
                    if (xhr.responseText) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            errorMsg = response.message || errorMsg;
                        } catch (e) {
                            console.error("Non-JSON response from add_user.php");
                        }
                    }
                    Swal.fire({
                        icon: 'error',
                        title: 'An Error Occurred',
                        text: errorMsg,
                    });
                    console.error("AJAX Error:", status, error, xhr.responseText);
                },
                complete: function () {
                    submitBtn.prop('disabled', false).text('Add User');
                }
            });
        }

        function submitUpdateUserForm() {
            const form = $('#editUserForm');
            const submitBtn = $('#editUserSubmitBtn');
            submitBtn.prop('disabled', true).text('Saving...');
            const formData = form.serialize();

            $.ajax({
                url: 'update_user.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'User Updated!',
                            text: 'The user data has been updated successfully.',
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            $('#editUserModal').modal('hide');
                            userTable.ajax.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: response.message || 'Error updating user.',
                        });
                    }
                },
                error: function (xhr, status, error) {
                    let errorMsg = 'An error occurred. Please try again.';
                    if (xhr.responseText) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            errorMsg = response.message || errorMsg;
                        } catch (e) {
                            console.error("Non-JSON response from update_user.php");
                        }
                    }
                    Swal.fire({
                        icon: 'error',
                        title: 'An Error Occurred',
                        text: errorMsg,
                    });
                    console.error("AJAX Error:", status, error, xhr.responseText);
                },
                complete: function () {
                    submitBtn.prop('disabled', false).text('Save Changes');
                }
            });
        }

        function submitChangePasswordForm() {
            const form = $('#changePasswordForm');
            const submitBtn = $('#changePasswordSubmitBtn');
            submitBtn.prop('disabled', true).text('Changing...');

            $.ajax({
                url: 'change_user_password.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Password Changed!',
                            text: 'The user\'s password has been updated successfully.',
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            $('#changePasswordModal').modal('hide');
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: response.message || 'Error changing password.',
                        });
                    }
                },
                error: function (xhr, status, error) {
                    let errorMsg = 'An error occurred. Please try again.';
                    if (xhr.responseText) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            errorMsg = response.message || errorMsg;
                        } catch (e) {
                            console.error("Non-JSON response from change_user_password.php");
                        }
                    }
                    Swal.fire({
                        icon: 'error',
                        title: 'An Error Occurred',
                        text: errorMsg,
                    });
                    console.error("AJAX Error:", status, error, xhr.responseText);
                },
                complete: function () {
                    submitBtn.prop('disabled', false).text('Change Password');
                }
            });
        }
    });
</script>