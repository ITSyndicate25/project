<?php
session_start();

require_once '../../config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

// Redirect if not logged in
if (empty($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit();
}

$user = null;
$error_message = '';

try {
    $db = new Connection();
    $conn = $db->link;

    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id, username, requestor_name, department, email, role FROM users WHERE user_id = ?";
    $params = [&$user_id];
    $stmt = sqlsrv_prepare($conn, $sql, $params);

    if ($stmt === false || !sqlsrv_execute($stmt)) {
        throw new Exception("Failed to execute query.");
    }

    if (sqlsrv_has_rows($stmt)) {
        $user = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    } else {
        $error_message = "User not found.";
    }
} catch (Exception $e) {
    $error_message = "Database error: " . $e->getMessage();
} finally {
    if (isset($db)) {
        $db->close();
    }
}

// Redirect to login on failure
if (!$user) {
    header('Location: ../../login.php');
    exit();
}

// Get the user's role from the session
$user_role_string = $_SESSION['user_role'] ?? 'user';
// Split the roles into an array for easy checking
$user_roles = explode(',', str_replace(' ', '', strtolower($user_role_string)));

// Determine the dashboard link based on the user's roles
if (in_array('admin', $user_roles)) {
    $dashboard_link = 'admin_dashboard.php';
} elseif (in_array('checker', $user_roles) || in_array('approver', $user_roles) || in_array('noter', $user_roles)) {
    $dashboard_link = 'approver_dashboard.php';
} else {
    $dashboard_link = 'user_dashboard.php';
}

include '../../includes/header.php';
?>

<body>
    <div class="wrapper">
        <?php include '../../includes/sidebar.php'; ?>
        <div class="main-panel">
            <?php include '../../includes/navbar.php'; ?>

            <div class="content">
                <div class="container-fluid">
                    <div class="row justify-content-center">
                        <div class="col-lg-6 col-md-8">
                            <div class="card shadow-sm border-0 rounded">
                                <div class="card-header bg-primary text-white text-center">
                                    <h4 class="mb-0">User Profile</h4>
                                </div>
                                <div class="card-body">
                                    <div class="text-center mb-4">
                                        <div class="profile-avatar rounded-circle bg-secondary d-inline-flex align-items-center justify-content-center" style="width:100px; height:100px; font-size: 2.5rem; color:#fff;">
                                            <?php 
                                            $initials = mb_strtoupper(substr($user['requestor_name'], 0, 2));
                                            echo htmlspecialchars($initials);
                                            ?>
                                        </div>
                                        <h5 class="mt-3 mb-1"><?php echo htmlspecialchars($user['requestor_name']); ?></h5>
                                        <small class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></small>
                                    </div>

                                    <dl class="row mb-0">
                                        <dt class="col-sm-4">Name:</dt>
                                        <dd class="col-sm-8"><?php echo htmlspecialchars($user['requestor_name']); ?></dd>

                                        <dt class="col-sm-4">Username:</dt>
                                        <dd class="col-sm-8"><?php echo htmlspecialchars($user['username']); ?></dd>

                                        <dt class="col-sm-4">Department:</dt>
                                        <dd class="col-sm-8"><?php echo htmlspecialchars($user['department']); ?></dd>

                                        <dt class="col-sm-4">Email Address:</dt>
                                        <dd class="col-sm-8"><?php echo htmlspecialchars($user['email']); ?></dd>

                                        <dt class="col-sm-4">Role:</dt>
                                        <dd class="col-sm-8"><?php echo htmlspecialchars(ucfirst($user['role'])); ?></dd>
                                    </dl>

                                    <div class="text-center mt-4">
                                        <a href="<?php echo $dashboard_link; ?>" class="btn btn-outline-secondary btn-sm mr-2">
                                            <i class="fas fa-tachometer-alt"></i> Dashboard
                                        </a>
                                        <!-- Placeholder for future profile update -->
                                        <button type="button" class="btn btn-primary btn-sm" disabled>
                                            <i class="fas fa-user-edit"></i> Update Profile (Disabled)
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php include '../../includes/footer.php'; ?>
        </div>
    </div>

    <?php if (!empty($error_message)) : ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '<?php echo htmlspecialchars($error_message, ENT_QUOTES); ?>',
                confirmButtonText: 'OK'
            });
        <?php endif; ?>
    </script>
</body>
</html>