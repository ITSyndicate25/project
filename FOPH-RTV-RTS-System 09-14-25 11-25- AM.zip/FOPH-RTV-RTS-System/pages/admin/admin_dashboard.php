<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

checkAdminAccess(); 

// Check if user is logged in and has approver role(s)
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

// Call the function to get all dashboard data
$dashboard_data = getDashboardData();

include INCLUDES_PATH . '/header.php';
?>

<style>
    /* Enhanced card styling */
    .card-stats {
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        overflow: hidden;
    }
    
    .card-stats:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
    }
    
    .card-stats .card-body {
        padding: 20px 15px;
    }
    
    .card-stats .icon-big {
        font-size: 3rem;
        margin-bottom: 10px;
        opacity: 0.8;
    }
    
    .card-stats .card-title {
        margin-bottom: 0;
        line-height: 1;
    }
    
    .card-stats .card-category {
        font-size: 0.875rem;
        text-transform: uppercase;
        font-weight: 500;
        letter-spacing: 0.5px;
        opacity: 0.8;
    }
    
    .card-stats .card-footer {
        padding: 10px 15px;
        background-color: rgba(0, 0, 0, 0.03);
    }
    
    .card-stats .card-footer hr {
        margin: 0 -15px 10px;
        border-top-color: rgba(0, 0, 0, 0.1);
    }
    
    .card-stats .stats {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 500;
    }
    
    /* Animated number counter effect */
    @keyframes countUp {
        from {
            opacity: 0;
            transform: scale(0.5);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
    
    .card-stats .card-title {
        animation: countUp 0.5s ease-out;
    }
</style>

<div class="wrapper">
    <?php include INCLUDES_PATH . '/sidebar.php'; ?>
    <div class="main-panel">
        <?php include INCLUDES_PATH . '/navbar.php'; ?>
        <div class="content">
            <!-- Welcome Section -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card card-stats">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Welcome, <?php echo htmlspecialchars(ucfirst($dashboard_data['admin_name'])); ?>!</h5>
                            <p class="card-category mb-0">Today is <?php echo $dashboard_data['today']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Overview Cards -->
            <div class="row">
                <!-- Total Users Card -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center icon-primary">
                                        <i class="nc-icon nc-single-02 text-primary"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers">
                                        <p class="card-category">Total Users</p>
                                        <p class="card-title"><?php echo $dashboard_data['total_users']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <a href="<?php echo BASE_URL; ?>/pages/admin/user_management.php" class="text-primary">
                                    <i class="fa fa-users"></i> Manage users
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Requests Card -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center icon-success">
                                        <i class="nc-icon nc-chart-bar-32 text-success"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers">
                                        <p class="card-category">Total Requests</p>
                                        <p class="card-title"><?php echo $dashboard_data['total_all_forms']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <i class="fa fa-list"></i>
                                <small>
                                    RTS: <?php echo $dashboard_data['total_rts']; ?> | 
                                    NG: <?php echo $dashboard_data['total_ng']; ?> | 
                                    C&S: <?php echo $dashboard_data['total_coil_solder']; ?>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Total Locations Card -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center icon-warning">
                                        <i class="nc-icon nc-pin-3 text-warning"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers">
                                        <p class="card-category">Total Locations</p>
                                        <p class="card-title"><?php echo $dashboard_data['total_locations']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <a href="<?php echo BASE_URL; ?>/pages/admin/masterlist.php" class="text-warning">
                                    <i class="fa fa-map-marker"></i> Manage SAP locations
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Active Sessions Card -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center icon-info">
                                        <i class="nc-icon nc-circle-10 text-info"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers">
                                        <p class="card-category">Active Users</p>
                                        <p class="card-title"><?php echo $dashboard_data['active_users']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <i class="fa fa-clock"></i> Last 24 hours
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Request Status Overview -->
            <div class="row">
            <!-- Pending Card -->
            <div class="col-lg-2 col-md-4 col-sm-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="icon-big text-center">
                                    <i class="nc-icon nc-time-alarm text-warning"></i>
                                </div>
                                <div class="numbers text-center">
                                    <p class="card-category mb-0">Pending</p>
                                    <p class="card-title text-warning" style="font-size: 2rem; font-weight: bold;">
                                        <?php echo $dashboard_data['system_pending']; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer" style="background-color: rgba(255, 193, 7, 0.1);">
                        <hr class="mb-2 mt-0">
                        <div class="stats text-center">
                            <i class="fa fa-clock text-warning"></i> Awaiting approval
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ongoing Card -->
            <div class="col-lg-2 col-md-4 col-sm-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="icon-big text-center">
                                    <i class="nc-icon nc-refresh-69 text-info"></i>
                                </div>
                                <div class="numbers text-center">
                                    <p class="card-category mb-0">Ongoing</p>
                                    <p class="card-title text-info" style="font-size: 2rem; font-weight: bold;">
                                        <?php echo $dashboard_data['system_ongoing']; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer" style="background-color: rgba(23, 162, 184, 0.1);">
                        <hr class="mb-2 mt-0">
                        <div class="stats text-center">
                            <i class="fa fa-spinner text-info"></i> In progress
                        </div>
                    </div>
                </div>
            </div>

            <!-- Completed Card -->
            <div class="col-lg-2 col-md-4 col-sm-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="icon-big text-center">
                                    <i class="nc-icon nc-check-2 text-success"></i>
                                </div>
                                <div class="numbers text-center">
                                    <p class="card-category mb-0">Completed</p>
                                    <p class="card-title text-success" style="font-size: 2rem; font-weight: bold;">
                                        <?php echo $dashboard_data['system_completed']; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer" style="background-color: rgba(40, 167, 69, 0.1);">
                        <hr class="mb-2 mt-0">
                        <div class="stats text-center">
                            <i class="fa fa-check-circle text-success"></i> Finished
                        </div>
                    </div>
                </div>
            </div>

            <!-- Disapproved Card -->
            <div class="col-lg-2 col-md-4 col-sm-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="icon-big text-center">
                                    <i class="nc-icon nc-simple-remove text-danger"></i>
                                </div>
                                <div class="numbers text-center">
                                    <p class="card-category mb-0">Disapproved</p>
                                    <p class="card-title text-danger" style="font-size: 2rem; font-weight: bold;">
                                        <?php echo $dashboard_data['system_disapproved']; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer" style="background-color: rgba(220, 53, 69, 0.1);">
                        <hr class="mb-2 mt-0">
                        <div class="stats text-center">
                            <i class="fa fa-times-circle text-danger"></i> Rejected
                        </div>
                    </div>
                </div>
            </div>

            <!-- Today's Requests Card -->
            <div class="col-lg-2 col-md-4 col-sm-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="icon-big text-center">
                                    <i class="nc-icon nc-calendar-60 text-primary"></i>
                                </div>
                                <div class="numbers text-center">
                                    <p class="card-category mb-0">Today's Requests</p>
                                    <p class="card-title text-primary" style="font-size: 2rem; font-weight: bold;">
                                        <?php echo $dashboard_data['today_requests']; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer" style="background-color: rgba(0, 123, 255, 0.1);">
                        <hr class="mb-2 mt-0">
                        <div class="stats text-center">
                            <i class="fa fa-calendar-day text-primary"></i> <?php echo date('M d, Y'); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- This Month Card -->
            <div class="col-lg-2 col-md-4 col-sm-6">
                <div class="card card-stats">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="icon-big text-center">
                                    <i class="nc-icon nc-chart-pie-36 text-secondary"></i>
                                </div>
                                <div class="numbers text-center">
                                    <p class="card-category mb-0">This Month</p>
                                    <p class="card-title text-secondary" style="font-size: 2rem; font-weight: bold;">
                                        <?php echo $dashboard_data['month_requests']; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer" style="background-color: rgba(108, 117, 125, 0.1);">
                        <hr class="mb-2 mt-0">
                        <div class="stats text-center">
                            <i class="fa fa-calendar-alt text-secondary"></i> <?php echo date('F Y'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

            <!-- Charts Row -->
            <div class="row">
                <!-- User Roles Chart -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">User Roles Distribution</h5>
                            <p class="card-category">System user breakdown</p>
                        </div>
                        <div class="card-body">
                            <canvas id="userRolesChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Request Status Chart -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Request Status Overview</h5>
                            <p class="card-category">Current system status</p>
                        </div>
                        <div class="card-body">
                            <canvas id="requestStatusChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Request Types Chart -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Request Types Distribution</h5>
                            <p class="card-category">Forms breakdown</p>
                        </div>
                        <div class="card-body">
                            <canvas id="requestTypesChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Monthly Trend Chart -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Monthly Request Trends</h5>
                            <p class="card-category">Last 6 months overview</p>
                        </div>
                        <div class="card-body">
                            <canvas id="monthlyTrendChart" height="100"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activity Tables -->
            <div class="row">
                <!-- Recent Users -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Recent Users</h5>
                            <p class="card-category">Latest registered users</p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead class="text-primary">
                                        <th>Username</th>
                                        <th>Role</th>
                                        <th>Registered</th>
                                        <th>Status</th>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($dashboard_data['recent_users'] as $user): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                                            <td>
                                                <?php 
                                                $roles = explode(',', $user['role']);
                                                foreach ($roles as $role): 
                                                ?>
                                                    <span class="badge badge-info"><?php echo ucfirst(trim($role)); ?></span>
                                                <?php endforeach; ?>
                                            </td>
                                            <td><?php echo $user['created_at']; ?></td>
                                            <td>
                                                <span class="badge badge-success">Active</span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Requests -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Recent Requests</h5>
                            <p class="card-category">Latest system activity</p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead class="text-primary">
                                        <th>Request ID</th>
                                        <th>Type</th>
                                        <th>Submitted By</th>
                                        <th>Status</th>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($dashboard_data['recent_requests'] as $request): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($request['control_no']); ?></td>
                                            <td>
                                                <?php 
                                                $badgeClass = 'badge-secondary';
                                                if ($request['form_type'] === 'RTS Form') $badgeClass = 'badge-primary';
                                                else if ($request['form_type'] === 'NG Form') $badgeClass = 'badge-warning';
                                                else if ($request['form_type'] === 'Coil and Solder Form') $badgeClass = 'badge-info';
                                                ?>
                                                <span class="badge <?php echo $badgeClass; ?>"><?php echo $request['form_type']; ?></span>
                                            </td>
                                            <td><?php echo htmlspecialchars($request['submitted_by']); ?></td>
                                            <td>
                                                <?php 
                                                $statusBadgeClass = 'badge-secondary';
                                                switch($request['material_status']) {
                                                    case 'Pending': $statusBadgeClass = 'badge-warning'; break;
                                                    case 'In-Progress': $statusBadgeClass = 'badge-info'; break;
                                                    case 'Completed': $statusBadgeClass = 'badge-success'; break;
                                                    case 'Disapproved':
                                                    case 'Canceled': $statusBadgeClass = 'badge-danger'; break;
                                                }
                                                ?>
                                                <span class="badge <?php echo $statusBadgeClass; ?>"><?php echo $request['material_status']; ?></span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include INCLUDES_PATH . '/footer.php'; ?>
    </div>
</div>

<script>
    // User Roles Chart
    const userRolesData = <?php echo json_encode($dashboard_data['user_roles']); ?>;
    const roleColors = {
        'admin': 'rgba(255, 99, 132, 0.8)',
        'user': 'rgba(54, 162, 235, 0.8)',
        'checker': 'rgba(255, 206, 86, 0.8)',
        'approver': 'rgba(75, 192, 192, 0.8)',
        'noter': 'rgba(153, 102, 255, 0.8)',
    };

    const roleLabels = Object.keys(userRolesData).map(role => role.charAt(0).toUpperCase() + role.slice(1));
    const roleValues = Object.values(userRolesData);
    const backgroundColors = Object.keys(userRolesData).map(role => roleColors[role] || 'rgba(128, 128, 128, 0.8)');

    const userRolesCtx = document.getElementById('userRolesChart').getContext('2d');
    new Chart(userRolesCtx, {
        type: 'pie',
        data: {
            labels: roleLabels,
            datasets: [{
                data: roleValues,
                backgroundColor: backgroundColors,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            }
        }
    });

    // Request Status Chart
    const statusCtx = document.getElementById('requestStatusChart').getContext('2d');
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Pending', 'Ongoing', 'Completed', 'Disapproved'],
            datasets: [{
                data: [
                    <?php echo $dashboard_data['system_pending']; ?>,
                    <?php echo $dashboard_data['system_ongoing']; ?>,
                    <?php echo $dashboard_data['system_completed']; ?>,
                    <?php echo $dashboard_data['system_disapproved']; ?>
                ],
                backgroundColor: [
                    'rgba(255, 193, 7, 0.8)',
                    'rgba(23, 162, 184, 0.8)',
                    'rgba(40, 167, 69, 0.8)',
                    'rgba(220, 53, 69, 0.8)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            }
        }
    });

    // Request Types Chart
    const typesCtx = document.getElementById('requestTypesChart').getContext('2d');
    new Chart(typesCtx, {
        type: 'bar',
        data: {
            labels: ['RTS', 'NG', 'Coil & Solder'],
            datasets: [{
                label: 'Total Requests',
                data: [
                    <?php echo $dashboard_data['total_rts']; ?>,
                    <?php echo $dashboard_data['total_ng']; ?>,
                    <?php echo $dashboard_data['total_coil_solder']; ?>
                ],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 206, 86, 0.8)',
                    'rgba(75, 192, 192, 0.8)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Monthly Trend Chart
    const monthlyData = <?php echo json_encode($dashboard_data['monthly_trend']); ?>;
    const monthlyCtx = document.getElementById('monthlyTrendChart').getContext('2d');
    new Chart(monthlyCtx, {
        type: 'line',
        data: {
            labels: monthlyData.labels,
            datasets: [{
                label: 'RTS Forms',
                data: monthlyData.rts,
                borderColor: 'rgba(54, 162, 235, 1)',
                backgroundColor: 'rgba(54, 162, 235, 0.1)',
                tension: 0.1
            }, {
                label: 'NG Forms',
                data: monthlyData.ng,
                borderColor: 'rgba(255, 206, 86, 1)',
                backgroundColor: 'rgba(255, 206, 86, 0.1)',
                tension: 0.1
            }, {
                label: 'Coil & Solder Forms',
                data: monthlyData.coil_solder,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.1)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>