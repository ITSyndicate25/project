<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';

require APP_ROOT . '/PHPMailer/src/PHPMailer.php';
require APP_ROOT . '/PHPMailer/src/SMTP.php';
require APP_ROOT . '/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function sendEmailRTS(array $recipientEmails, string $control_no) {
    
    // Check if the recipientEmails array is empty.
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return;
    }

    $message = "<p>Good Day,</p>";
    $message .= "<p>A new RTS form with control number <b>$control_no</b> has been submitted and requires your checking.</p>";
    $message .= "<p>Please login to the system to review this request.</p>";
    $message .= "<p>Thank you.</p>";
    $message .= "<br><p><i>This is an automated message. Please do not reply.</i></p>";

    $mail = new PHPMailer();
    
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.office365.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'foph.dc-noreply@007.fujifilm.com';
        $mail->Password = 'Fujifilm@4';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
        $mail->Port = 587;
        $mail->setFrom('foph.dc-noreply@fujifilm.com', 'No-Reply');

        // Loop through the array of recipient emails and add them
        foreach ($recipientEmails as $email) {
            $mail->addAddress($email);
        }

        $mail->isHTML(true);
        $mail->Subject = "RTS Checking Request Notification (Control No: $control_no)";
        $mail->Body = $message;

        ini_set('display_errors', 0); 
        ini_set('display_startup_errors', 0);
        error_reporting(E_ALL);
        
        if ($mail->send()) {
            // Email sent successfully
            error_log("RTS approval email sent successfully for Control No: $control_no");
        } else {
            // Email sending failed
            error_log("Email sending failed for Control No: $control_no. Error: " . $mail->ErrorInfo);
        }
    } catch (Exception $e) {
        error_log("Email sending exception for Control No: $control_no. Exception: " . $e->getMessage());
    }
}
?>