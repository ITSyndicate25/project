<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

$rts_id = $_GET['id'] ?? null;

// User role and ID from session for dynamic display
$user_role = $_SESSION['user_role'] ?? '';
$user_id = $_SESSION['user_id'] ?? null;

// The function to get all RTS details
$rts_data = getRTSDetails($rts_id);

$rts = $rts_data['rts'];
$items = $rts_data['items'];
$error_message = $rts_data['error_message'];

if ($error_message) {
    echo "<div class='alert alert-danger'>$error_message</div>";
    exit();
}

// Extract signatures if they exist
$prepared_by_signature_base64 = $rts['prepared_by_signature_base64'] ?? null;
$checked_by_signature_base64 = $rts['checked_by_signature_base64'] ?? null;
$approved_by_signature_base64 = $rts['approved_by_signature_base64'] ?? null;
$noted_by_signature_base64 = $rts['noted_by_signature_base64'] ?? null;

?>
<style>
    /* Container and Card Styling */
    .rts-container {
        padding: 2rem;
        background-color: #ffffff;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        max-width: 1200px;
        margin: auto;
    }

    /* Header Style */
    .card-header-custom {
        background-color: #fff;
        border-bottom: 3px solid #007bff;
        padding: 1rem 1.5rem;
        text-align: center;
        border-top-left-radius: 12px;
        border-top-right-radius: 12px;
    }

    .card-header-custom img {
        max-height: 50px;
        margin-bottom: 0.5rem;
    }

    .card-header-custom h3 {
        font-weight: 700;
        color: #212529;
        letter-spacing: 1px;
        text-transform: uppercase;
        font-size: 1.25rem;
    }

    /* Section Title */
    .section-title {
        color: #212529;
        font-weight: 700;
        font-size: 1.45rem;
        margin-bottom: 1.5rem;
        border-bottom: 2px solid #dee2e6;
        padding-bottom: 0.3rem;
    }

    /* Labels & Values */
    .form-label {
        font-weight: 600;
        color: #495057;
        font-size: 0.95rem;
        margin-bottom: 0.3rem;
        display: block;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .form-value {
        font-size: 1rem;
        color: #343a40;
        margin-bottom: 1rem;
        padding: 0.3rem 0.25rem;
        border-bottom: 1px solid #e9ecef;
        min-height: 1.6em;
        word-break: break-word;
    }

    /* Row Spacing */
    .row>[class*="col-"] {
        margin-bottom: 1.25rem;
    }

    /* * UPDATED: Approval Table Styling from rts_form.php
      */
    .approval-table-container {
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-top: 15px;
    }

    .approval-table-container table {
        width: 100%;
        border-collapse: collapse;
    }

    .approval-table-container th {
        background-color: #f8f9fa;
        color: #000000;
        font-weight: 700;
        padding: 10px;
        text-align: center;
    }

    .approval-table-container td {
        background-color: #ffffff;
        color: #000000;
        padding: 15px;
        vertical-align: middle;
        border: 1px solid #dee2e6;
        text-align: center;
    }

    /* Material Accordion */
    .accordion {
        margin-top: 1rem;
    }

    .collapsible-header {
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #e9f1ff;
        padding: 1rem 1.25rem;
        border-radius: 8px;
        font-weight: 700;
        color: #007bff;
        user-select: none;
        transition: background-color 0.3s ease;
        margin-bottom: 0.5rem;
    }

    .collapsible-header:hover {
        background-color: #d4e6ff;
    }

    .collapsible-header .icon {
        transition: transform 0.3s ease;
        font-size: 1.1rem;
    }

    .collapsible-header[aria-expanded="true"] .icon {
        transform: rotate(180deg);
    }

    /* Materials Table */
    .table-responsive {
        max-height: 470px;
        overflow-y: auto;
        border: 1px solid #dee2e6;
        border-radius: 8px;
    }

    .table.material-details {
        min-width: 1250px;
        border-collapse: separate;
        border-spacing: 0;
        font-size: 0.9rem;
    }

    .table.material-details th,
    .table.material-details td {
        padding: 0.6rem 0.8rem;
        text-align: left;
        border-bottom: 1px solid #e9ecef;
        vertical-align: middle;
        white-space: nowrap;
    }

    .table.material-details th {
        position: sticky;
        top: 0;
        background-color: #f8f9fa;
        font-weight: 700;
        color: #495057;
        border-bottom: 2px solid #007bff;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        z-index: 2;
        user-select: none;
    }

    /* Center numeric columns */
    .table.material-details td:nth-child(1),
    .table.material-details td:nth-child(9),
    .table.material-details td:nth-child(10),
    .table.material-details td:nth-child(11),
    .table.material-details td:nth-child(12) {
        text-align: center;
    }

    /* Zebra striping */
    .table.material-details tbody tr:nth-child(odd) {
        background-color: #fafbfc;
    }

    /* Responsive text wrap for long text columns */
    .table.material-details td {
        word-break: break-word;
        max-width: 130px;
    }

    /* No material found row */
    .table.material-details .no-data {
        text-align: center;
        color: #6c757d;
        font-style: italic;
    }

    /* Hide approval sections in print/PDF */
    @media print {
        .approval-details-section,
        .approval-alert,
        .modal-footer,
        #viewRTSModal .alert-info {
            display: none !important;
            visibility: hidden !important;
        }
    }
</style>

<div class="container py-4">
    <div class="rts-container shadow-sm" id="pdf-content">
        <div class="card-header-custom">
            <img src="<?php echo BASE_URL; ?>/assets/img/logo_black.png" alt="Company Logo">
            <h3>Return / Transfer Slip</h3>
        </div>

        <div class="card-body px-4 pt-4 pb-3">
            <?php if (isset($error_message)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error_message); ?></div>
            <?php elseif ($rts): ?>
                <div class="row">
                    <div class="col-md-4">
                        <label class="form-label">RTS Control No.</label>
                        <p class="form-value"><?= htmlspecialchars($rts['control_no'] ?? 'N/A') ?></p>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Submitted By</label>
                        <p class="form-value"><?= htmlspecialchars($rts['submitted_by'] ?? 'N/A') ?></p>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Date Submitted</label>
                        <p class="form-value">
                            <?= $rts['created_at'] instanceof DateTime ? $rts['created_at']->format('Y-m-d') : 'N/A' ?>
                        </p>
                    </div>
                </div>

                <h4 class="section-title mt-4">RTS Information</h4>
                <div class="row">
                    <div class="col-md-6 col-lg-4">
                        <label class="form-label">Material Type</label>
                        <p class="form-value"><?= htmlspecialchars($rts['material_type'] ?? 'N/A') ?></p>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <label class="form-label">Material Status</label>
                        <p class="form-value">
                            <?php
                            $status_value = strtolower($rts['material_status'] ?? '');
                            echo $status_value === 'defective' ? 'Material Defect' : htmlspecialchars($rts['material_status'] ?? 'N/A');
                            ?>
                        </p>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <label class="form-label">Judgement</label>
                        <p class="form-value"><?= htmlspecialchars($rts['judgement'] ?? 'N/A') ?></p>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <label class="form-label">Return Date</label>
                        <p class="form-value">
                            <?= ($rts['return_date'] instanceof DateTime) ? $rts['return_date']->format('Y-m-d') : 'N/A' ?>
                        </p>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <label class="form-label">Department</label>
                        <p class="form-value"><?= htmlspecialchars($rts['department'] ?? 'N/A') ?></p>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <label class="form-label">Model</label>
                        <p class="form-value"><?= htmlspecialchars($rts['model'] ?? 'N/A') ?></p>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">SAP Location Details</label>
                        <p class="form-value">
                            <?= htmlspecialchars($rts['sap_loc_code'] ?? 'N/A') ?> -
                            <?= htmlspecialchars($rts['LocationDescription'] ?? 'N/A') ?> -
                            <?= htmlspecialchars($rts['sap_department'] ?? 'N/A') ?>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Details (Others)</label>
                        <p class="form-value">
                            <?= nl2br(htmlspecialchars(empty($rts['details']) ? 'N/A' : $rts['details'])) ?>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Remarks</label>
                        <p class="form-value"><?= nl2br(htmlspecialchars(empty($rts['remark']) ? 'N/A' : $rts['remark'])) ?>
                        </p>
                    </div>
                </div>

                <h4 class="section-title mt-4">Approval Details</h4>
                <div class="approval-details-section">
                    <?php
                    $show_buttons = false;
                    $action_role = '';
                    $action_message = '';
                    
                    // The core fix: use the status fetched from the database, not the URL.
                    $current_status_from_db = $rts['material_status'] ?? 'N/A';

                    // If the request's status is already final, display the appropriate message and stop.
                    if ($current_status_from_db === 'Completed') {
                        $action_message = 'This request has been successfully completed and approved.';
                    } elseif ($current_status_from_db === 'Disapproved') {
                        $disapproved_by_role = $rts['disapproved_by_role'] ?? '';
                        $action_message = 'This request has been disapproved.';
                        if (!empty($disapproved_by_role)) {
                            $action_message .= ' ';
                        }
                    } else {
                        // If it's not a final status, proceed with the approval logic.
                        if (str_contains($user_role, 'checker') && ($rts['checked_status'] ?? '') === 'Pending') {
                            $show_buttons = true;
                            $action_role = 'checker';
                            $action_message = 'This request is pending your review as a Checker.';
                        } elseif (str_contains($user_role, 'approver') && ($rts['checked_status'] ?? '') === 'Approved' && ($rts['approved_status'] ?? '') === 'Pending') {
                            $show_buttons = true;
                            $action_role = 'approver';
                            $action_message = 'This request is pending your approval as an Approver.';
                        } elseif (str_contains($user_role, 'noter') && ($rts['checked_status'] ?? '') === 'Approved' && ($rts['approved_status'] ?? '') === 'Approved' && ($rts['noted_status'] ?? '') === 'Pending') {
                            $show_buttons = true;
                            $action_role = 'noter';
                            $action_message = 'This request is pending your notes as a Noter.';
                        } else {
                            // Default message for cases where the request is pending, but not for the current user's role
                            $action_message = 'This request is currently pending another user\'s review.';
                        }
                    }
                    ?>
                    <div class="alert alert-info mb-3 d-flex justify-content-between align-items-center approval-alert">
                        <span>
                            <strong>Status:</strong>
                            <?= htmlspecialchars($action_message) ?>
                        </span>
                        <?php if ($show_buttons): ?>
                            <div>
                                <button type="button" class="btn btn-success btn-sm me-2 approve-btn"
                                    data-rts-id="<?= $rts['id'] ?>" data-role="<?= htmlspecialchars($action_role) ?>">
                                    <i class="fa fa-check"></i> Approve
                                </button>
                                <button type="button" class="btn btn-danger btn-sm disapprove-btn" data-rts-id="<?= $rts['id'] ?>"
                                    data-role="<?= htmlspecialchars($action_role) ?>">
                                    <i class="fa fa-times"></i> Disapprove
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="approval-table-container">
                    <table class="table table-bordered table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Prepared By</th>
                                <th>Checked By</th>
                                <th>Approved By</th>
                                <th>Noted By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <?php if (!empty($prepared_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($prepared_by_signature_base64) ?>"
                                            alt="Prepared By Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                        <hr style="margin: 5px 0;">
                                    <?php endif; ?>
                                    <p><?= htmlspecialchars($rts['submitted_by'] ?? 'N/A') ?></p>
                                    <small class="text-muted-small">
                                        <?= $rts['created_at'] instanceof DateTime ? $rts['created_at']->format('M d, Y h:i:s A') : 'N/A' ?>
                                    </small>
                                </td>
                                <td>
                                    <?php if (($rts['checked_status'] ?? '') === 'Disapproved'): ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/not-approved.jpg'; ?>"
                                            alt="Disapproved Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                    <?php elseif (!empty($checked_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($checked_by_signature_base64) ?>"
                                            alt="Checked By Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                    <?php else: ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>"
                                            alt="Pending Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                    <?php endif; ?>
                                    <hr style="margin: 5px 0;">
                                    <p><?= htmlspecialchars($rts['checked_by_name'] ?? 'N/A') ?></p>
                                    <small class="text-muted-small">
                                        <?= ($rts['checked_at'] ?? null) instanceof DateTime ? $rts['checked_at']->format('M d, Y h:i:s A') : 'N/A' ?>
                                    </small>
                                </td>
                                <td>
                                    <?php if (($rts['approved_status'] ?? '') === 'Disapproved'): ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/not-approved.jpg'; ?>"
                                            alt="Disapproved Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                    <?php elseif (!empty($approved_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($approved_by_signature_base64) ?>"
                                            alt="Approved By Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                    <?php else: ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>"
                                            alt="Pending Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                    <?php endif; ?>
                                    <hr style="margin: 5px 0;">
                                    <p><?= htmlspecialchars($rts['approved_by_name'] ?? 'N/A') ?></p>
                                    <small class="text-muted-small">
                                        <?= ($rts['approved_at'] ?? null) instanceof DateTime ? $rts['approved_at']->format('M d, Y h:i:s A') : 'N/A' ?>
                                    </small>
                                </td>
                                <td>
                                    <?php if (($rts['noted_status'] ?? '') === 'Disapproved'): ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/not-approved.jpg'; ?>"
                                            alt="Disapproved Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                    <?php elseif (!empty($noted_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($noted_by_signature_base64) ?>"
                                            alt="Noted By Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                    <?php else: ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>"
                                            alt="Pending Signature"
                                            style="max-width: 150px; display: block; margin: 0 auto;">
                                    <?php endif; ?>
                                    <hr style="margin: 5px 0;">
                                    <p><?= htmlspecialchars($rts['noted_by_name'] ?? 'N/A') ?></p>
                                    <small class="text-muted-small">
                                        <?= ($rts['noted_at'] ?? null) instanceof DateTime ? $rts['noted_at']->format('M d, Y h:i:s A') : 'N/A' ?>
                                    </small>
                                </td>
                            </tr>
                            <?php if (!empty($rts['disapproval_reason'])): ?>
                            <tr>
                                <td colspan="4">
                                    <strong>Disapproval Reason:</strong> <?= htmlspecialchars($rts['disapproval_reason']) ?>
                                    <?php if (!empty($disapproved_by_role)): ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <h4 class="section-title mt-4">Material Details</h4>
                <div class="accordion" id="materialAccordion">
                    <div class="card border-0">
                        <div class="collapsible-header" id="headingMaterial" data-toggle="collapse"
                            data-target="#collapseMaterial" aria-expanded="true" aria-controls="collapseMaterial"
                            role="button" tabindex="0">
                            <span>Click to view all material details</span>
                            <i class="fas fa-chevron-down icon"></i>
                        </div>

                        <div id="collapseMaterial" class="collapse show" aria-labelledby="headingMaterial"
                            data-parent="#materialAccordion">
                            <div class="card-body px-0 pt-3 pb-0">
                                <div class="table-responsive">
                                    <table class="table material-details table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th style="width: 3%;">No.</th>
                                                <th style="width: 10%;">Ref. No</th>
                                                <th style="width: 10%;">SAP Mat Doc Ref</th>
                                                <th style="width: 10%;">Invoice No</th>
                                                <th style="width: 10%;">Supplier</th>
                                                <th style="width: 10%;">Part Number</th>
                                                <th style="width: 12%;">Part Name</th>
                                                <th style="width: 15%;">Description</th>
                                                <th style="width: 6%;">Qty Returned</th>
                                                <th style="width: 6%;">Qty Received</th>
                                                <th style="width: 8%;">Amount</th>
                                                <th style="width: 8%;">Due Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($items)): ?>
                                                <tr>
                                                    <td class="no-data" colspan="13">No material details found.</td>
                                                </tr>
                                            <?php else: ?>
                                                <?php $counter = 1; ?>
                                                <?php foreach ($items as $item): ?>
                                                    <tr>
                                                        <td><?= $counter++ ?></td>
                                                        <td><?= htmlspecialchars($item['ref_no'] ?? 'N/A') ?></td>
                                                        <td><?= htmlspecialchars($item['sap_doc'] ?? 'N/A') ?></td>
                                                        <td><?= htmlspecialchars($item['invoice_no'] ?? 'N/A') ?></td>
                                                        <td><?= htmlspecialchars($item['supplier'] ?? 'N/A') ?></td>
                                                        <td><?= htmlspecialchars($item['part_number'] ?? 'N/A') ?></td>
                                                        <td><?= htmlspecialchars($item['part_name'] ?? 'N/A') ?></td>
                                                        <td><?= htmlspecialchars($item['description'] ?? 'N/A') ?></td>
                                                        <td><?= is_numeric($item['qty_returned']) ? number_format($item['qty_returned']) : 'N/A' ?>
                                                        </td>
                                                        <td><?= is_numeric($item['qty_received']) ? number_format($item['qty_received']) : 'N/A' ?>
                                                        </td>
                                                        <td><?= is_numeric($item['amount']) ? number_format($item['amount'], 2) : 'N/A' ?>
                                                        </td>
                                                        <td><?= ($item['due_date'] instanceof DateTime) ? $item['due_date']->format('Y-m-d') : 'N/A' ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="downloadPdfBtn">Save as PDF</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Enable toggle on collapsible header click and keyboard accessible
    document.querySelectorAll('.collapsible-header').forEach(header => {
        header.addEventListener('click', () => {
            const expanded = header.getAttribute('aria-expanded') === 'true';
            header.setAttribute('aria-expanded', String(!expanded));
            const collapseEl = document.querySelector(header.dataset.target);
            if (collapseEl) {
                collapseEl.classList.toggle('show');
            }
        });
        header.addEventListener('keydown', e => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                header.click();
            }
        });
    });
</script>