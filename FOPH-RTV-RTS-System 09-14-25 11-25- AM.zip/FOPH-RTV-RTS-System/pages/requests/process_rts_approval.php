<?php
session_start();
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

include APP_ROOT . '/pages/includes/send_email_rts.php';

// Check for user ID and role in session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];
$username = $_SESSION['username'] ?? 'Unknown User';

// Check if request data is received
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['rts_id'], $_POST['action'], $_POST['role'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request data.']);
    exit();
}

$rts_id = $_POST['rts_id'];
$action = $_POST['action'];
$requested_role = $_POST['role'];
$reason = $_POST['reason'] ?? null;

// Determine the database field to update based on the role
$status_fields = ['checker' => 'checked_status', 'approver' => 'approved_status', 'noter' => 'noted_status'];
$by_fields = ['checker' => 'checked_by', 'approver' => 'approved_by', 'noter' => 'noted_by'];
$by_id_fields = ['checker' => 'checked_by_id', 'approver' => 'approved_by_id', 'noter' => 'noted_by_id'];
$at_fields = ['checker' => 'checked_at', 'approver' => 'approved_at', 'noter' => 'noted_at'];

$signature_fields = [
    'checker' => 'checked_by_signature_image',
    'approver' => 'approved_by_signature_image',
    'noter' => 'noted_by_signature_image'
];

$current_status_field = $status_fields[$requested_role] ?? null;
$current_by_field = $by_fields[$requested_role] ?? null;
$current_by_id_field = $by_id_fields[$requested_role] ?? null;
$current_at_field = $at_fields[$requested_role] ?? null;
$current_signature_field = $signature_fields[$requested_role] ?? null;

if (!$current_status_field || !$current_signature_field) {
    echo json_encode(['success' => false, 'message' => 'Invalid role specified for action.']);
    exit();
}

try {
    $db = new Connection();
    $conn = $db->link;
    sqlsrv_begin_transaction($conn);
    $new_status_to_return = 'pending';
    
    // Step 1: Get the current user's signature from the users table
    $user_data = getUserData($user_id);
    if (!$user_data['success'] || !isset($user_data['data']['e_signiture'])) {
        throw new Exception("User signature not found or user data is invalid.");
    }
    
    $e_signature_data = $user_data['data']['e_signiture'];
    
    if ($action === 'approve') {
        $sql_update = "
            UPDATE rts_forms
            SET
                $current_status_field = 'Approved',
                $current_by_field = ?,
                $current_by_id_field = ?,
                $current_at_field = GETDATE(),
                $current_signature_field = ?
        ";

        if ($requested_role === 'checker') {
            $sql_update .= ", material_status = 'In-Progress'";
            $new_status_to_return = 'in-progress';
        }
        
        $sql_update .= " WHERE id = ? AND $current_status_field = 'Pending'";
        
        $params = [
            [$username, SQLSRV_PARAM_IN],
            [$user_id, SQLSRV_PARAM_IN],
            [$e_signature_data, SQLSRV_PARAM_IN, SQLSRV_PHPTYPE_STREAM(SQLSRV_ENC_BINARY), SQLSRV_SQLTYPE_VARBINARY('max')],
            [$rts_id, SQLSRV_PARAM_IN]
        ];

        $stmt = sqlsrv_prepare($conn, $sql_update, $params);
        
        if ($stmt === false) {
            sqlsrv_rollback($conn);
            error_log("SQL Prepare Error (Approve): " . print_r(sqlsrv_errors(), true));
            throw new Exception("Failed to prepare update statement.");
        }
        
        if (!sqlsrv_execute($stmt) || sqlsrv_rows_affected($stmt) == 0) {
            sqlsrv_rollback($conn);
            error_log("SQL Error (Approve): " . print_r(sqlsrv_errors(), true));
            throw new Exception("Failed to approve the request. It may have already been processed.");
        }

        if ($requested_role === 'noter') {
            $sql_check_completion = "
                SELECT
                    checked_status,
                    approved_status,
                    noted_status
                FROM rts_forms
                WHERE id = ?
            ";
            $params_check = [$rts_id];
            $stmt_check = sqlsrv_query($conn, $sql_check_completion, $params_check);
            $row = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);

            if ($row && $row['checked_status'] === 'Approved' && $row['approved_status'] === 'Approved' && $row['noted_status'] === 'Approved') {
                $sql_complete = "UPDATE rts_forms SET material_status = 'Completed' WHERE id = ?";
                $params_complete = [$rts_id];
                $stmt_complete = sqlsrv_query($conn, $sql_complete, $params_complete);
                if ($stmt_complete === false) {
                    sqlsrv_rollback($conn);
                    throw new Exception("Failed to update status to completed.");
                }
                $new_status_to_return = 'completed';
            }
        }
        } elseif ($action === 'disapprove') {
            // First, save the current material status selection before it gets overwritten
            $sql_save_original = "UPDATE rts_forms SET original_material_status_selection = material_status WHERE id = ? AND original_material_status_selection IS NULL";
            $stmt_save = sqlsrv_query($conn, $sql_save_original, [$rts_id]);
            
            if ($stmt_save === false) {
                error_log("Failed to save original material status: " . print_r(sqlsrv_errors(), true));
            }
            
            // Now proceed with the disapproval
            $sql_update = "
                UPDATE rts_forms
                SET
                    material_status = 'Disapproved',
                    disapproved_by_role = ?,
                    $current_status_field = 'Disapproved',
                    $current_by_field = ?,
                    $current_by_id_field = ?,
                    $current_at_field = GETDATE(),
                    $current_signature_field = ?,
                    disapproval_reason = ?
                WHERE id = ? AND material_status <> 'Disapproved'
            ";
            
            $params = [
                [$requested_role, SQLSRV_PARAM_IN], 
                [$username, SQLSRV_PARAM_IN],
                [$user_id, SQLSRV_PARAM_IN],
                [$e_signature_data, SQLSRV_PARAM_IN, SQLSRV_PHPTYPE_STREAM(SQLSRV_ENC_BINARY), SQLSRV_SQLTYPE_VARBINARY('max')],
                [$reason, SQLSRV_PARAM_IN],
                [$rts_id, SQLSRV_PARAM_IN]
            ];

            $stmt = sqlsrv_prepare($conn, $sql_update, $params);
            if ($stmt === false) {
                sqlsrv_rollback($conn);
                error_log("SQL Prepare Error (Disapprove): " . print_r(sqlsrv_errors(), true));
                throw new Exception("Failed to prepare disapproval statement.");
            }
            
            if (!sqlsrv_execute($stmt) || sqlsrv_rows_affected($stmt) == 0) {
                sqlsrv_rollback($conn);
                error_log("SQL Error (Disapprove): " . print_r(sqlsrv_errors(), true));
                throw new Exception("Failed to disapprove the request. It may have already been processed or the signature could not be saved.");
            }
            $new_status_to_return = 'disapproved';
            
    } elseif ($action === 'cancel') {
        $sql_update = "
            UPDATE rts_forms
            SET
                material_status = 'Canceled',
                remark = remark + ?
            WHERE id = ?
        ";
        $params = [
            "\n[Canceled by $username] Reason: " . ($reason ?? 'No reason provided.'),
            $rts_id
        ];
        
        $stmt = sqlsrv_query($conn, $sql_update, $params);
        if ($stmt === false || sqlsrv_rows_affected($stmt) == 0) {
            sqlsrv_rollback($conn);
            error_log("SQL Error (Cancel): " . print_r(sqlsrv_errors(), true));
            throw new Exception("Failed to cancel the request. It may have already been processed.");
        }
        $new_status_to_return = 'canceled';
    } else {
        sqlsrv_rollback($conn);
        throw new Exception("Invalid action specified.");
    }

    // Step 2: Fetch the requestor's email and form details after successful transaction
    $sql_fetch_requestor = "
        SELECT 
            t1.control_no, 
            t2.email AS requestor_email,
            t1.disapproval_reason
        FROM rts_forms t1
        JOIN users t2 ON t1.requestor_id = t2.user_id
        WHERE t1.id = ?
    ";
    $params_fetch_requestor = [$rts_id];
    $stmt_fetch_requestor = sqlsrv_query($conn, $sql_fetch_requestor, $params_fetch_requestor);
    $requestor_data = sqlsrv_fetch_array($stmt_fetch_requestor, SQLSRV_FETCH_ASSOC);

    sqlsrv_commit($conn);
    
    // Step 3: Send the email notification
    if ($requestor_data) {
        $recipient_email = $requestor_data['requestor_email'];
        $control_no = $requestor_data['control_no'];
        $disapproval_reason_from_db = $requestor_data['disapproval_reason'] ?? null;
        
        // **FIX:** Ensure correct arguments are passed to the email function.
        // Pass the approver's name and the disapproval reason from the database.
        sendApprovalEmail([$recipient_email], $control_no, $action, $requested_role, $username, $disapproval_reason_from_db);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'RTS request processed successfully.',
        'new_status' => $new_status_to_return
    ]);

    $db->close();

} catch (Exception $e) {
    if (isset($conn) && $conn) {
        sqlsrv_rollback($conn);
    }
    error_log("General Error (Process RTS): " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An internal server error occurred: ' . $e->getMessage()]);
}
?>