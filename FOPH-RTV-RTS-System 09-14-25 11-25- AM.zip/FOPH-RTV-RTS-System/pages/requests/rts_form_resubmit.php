<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/includes/functions.php';
require_once APP_ROOT . '/assets/db/connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/pages/requests/disapproved_requests.php');
    exit();
}

$rts_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Get RTS details including disapproval information
$rtsData = getRTSDetailsForResubmission($rts_id, $user_id);

if (!$rtsData['success']) {
    $_SESSION['error_message'] = $rtsData['message'];
    header('Location: ' . BASE_URL . '/pages/requests/disapproved_requests.php');
    exit();
}

$rts = $rtsData['rts'];
$items = $rtsData['items'];
$departments = $rtsData['departments'];
$sap_locations = $rtsData['sap_locations'];
$signature_base64 = $rtsData['signature_base64'];
$original_material_statuses = $rtsData['original_material_statuses'] ?? []; // Added default empty array

// Keep the original control number
$control_no = $rts['control_no'];
?>

<style>
/* Copy all the styles from rts_form.php */
.form-group label,
.custom-control-label {
    color: #000000 !important;
}

.disapproval-alert {
    background-color: #fff3cd;
    border: 1px solid #ffeeba;
    color: #856404;
    padding: 15px;
    border-radius: 4px;
    margin-bottom: 20px;
}

.disapproval-alert h5 {
    margin-top: 0;
    color: #856404;
}

/* Rest of your CSS from rts_form.php */
.font-weight-bold {
    color: #000000 !important;
}
.form-group label {
    font-weight: bold;
}
.form-control {
    color: #000000;
    border: 1px solid #ced4da;
    border-radius: 4px;
}
.form-control::placeholder {
    color: #000000;
    opacity: 0.7;
}
.checkbox-column {
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.custom-control-input {
    margin-right: 8px;
}
.custom-control-label {
    font-size: 0.95rem;
}
.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
.modal-content {
    border-radius: 8px;
}
.approval-table-container {
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-top: 15px;
}
.approval-table-container table {
    width: 100%;
    border-collapse: collapse;
}
.approval-table-container th {
    background-color: #f8f9fa;
    color: #000000;
    font-weight: 700;
    padding: 10px;
    text-align: center;
}
.approval-table-container td {
    background-color: #ffffff;
    color: #000000;
    padding: 15px;
    vertical-align: middle;
    border: 1px solid #dee2e6;
    text-align: center;
}
.signature-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
.signature-container img {
    max-width: 100%;
    height: auto;
    border-radius: 5px;
    margin-bottom: 5px;
}
.signature-container span {
    font-weight: 400;
    color: #000000;
}
.card-header {
    background-color: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
}
.card-title {
    font-weight: bold;
    color: #000000;
}
.btn-primary {
    background-color: #007bff;
    border: none;
}
.btn-primary:hover {
    background-color: #0056b3;
}
</style>

<?php include INCLUDES_PATH . '/header.php'; ?>
<div class="wrapper">
    <?php include INCLUDES_PATH . '/sidebar.php'; ?>
    <div class="main-panel">
        <?php include INCLUDES_PATH . '/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="row rts-header align-items-center">
                                    <div class="col-lg-4 col-md-12 text-lg-left text-center">
                                        <img src="<?php echo BASE_URL; ?>/assets/img/logo_black.png" alt="Logo"
                                            class="img-fluid" style="max-width: 150px;">
                                    </div>
                                    <div class="col-lg-4 col-md-12 text-center">
                                        <h4 class="card-title">Return / Transfer Slip (Resubmission)</h4>
                                    </div>
                                    <div class="col-lg-4 col-md-12 text-lg-right text-center">
                                        <div class="form-group">
                                            <label for="control_no">Control No</label>
                                            <input type="text" id="control_no" name="control_no"
                                                value="<?= htmlspecialchars($control_no) ?>" class="form-control" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <!-- Disapproval Information Alert -->
                                <div class="disapproval-alert">
                                    <h5><i class="fa fa-exclamation-triangle"></i> Disapproval Information</h5>
                                    <p><strong>Disapproved by:</strong> <?= htmlspecialchars(ucfirst($rts['disapproved_by_role'])) ?></p>
                                    <p><strong>Reason:</strong> <?= htmlspecialchars($rts['disapproval_reason']) ?></p>
                                    <p class="mb-0"><small>Please review and update the form based on the disapproval reason before resubmitting.</small></p>
                                </div>

                                <form id="rtsResubmitForm" method="POST" action="process_rts_form_resubmit.php">
                                    <input type="hidden" name="original_id" value="<?php echo $rts_id; ?>">
                                    <input type="hidden" name="control_no" value="<?php echo htmlspecialchars($control_no); ?>">
                                    <input type="hidden" name="requestor_id" value="<?php echo $_SESSION['user_id']; ?>">
                                    <input type="hidden" name="requestor_name" value="<?php echo htmlspecialchars($_SESSION['username']); ?>">
                                    <input type="hidden" name="requestor_department" value="<?php echo htmlspecialchars($rts['requestor_department']); ?>">
                                    <input type="hidden" name="resubmission_count" value="<?php echo ($rts['resubmission_count'] ?? 0) + 1; ?>">
                                    
                                    <div class="row">
                                        <div class="col-lg-4 col-md-12 checkbox-column">
                                            <div class="form-group">
                                                <label>Material Type</label>
                                                <?php 
                                                $material_types = explode(', ', $rts['material_type']);
                                                ?>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="rawMaterial" name="material_type[]"
                                                        value="Raw Material" <?= in_array('Raw Material', $material_types) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="rawMaterial">Raw Material</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="packagingMaterial" name="material_type[]"
                                                        value="Packaging Material" <?= in_array('Packaging Material', $material_types) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="packagingMaterial">Packaging Material</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 checkbox-column">
                                            <div class="form-group">
                                                <label>Material Status</label>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="good" name="material_status[]" value="Good"
                                                        <?= in_array('Good', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="good">Good</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="materialDefect" name="material_status[]"
                                                        value="Material Defect"
                                                        <?= in_array('Material Defect', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="materialDefect">Material Defect</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="humanError" name="material_status[]"
                                                        value="Human Error"
                                                        <?= in_array('Human Error', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="humanError">Human Error</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="endOfLife" name="material_status[]" value="EOL"
                                                        <?= in_array('EOL', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="endOfLife">EOL</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="othersNoGood" name="material_status[]"
                                                        value="NG/Others"
                                                        <?= in_array('NG/Others', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="othersNoGood">NG/Others</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 checkbox-column">
                                            <div class="form-group">
                                                <label>Judgement</label>
                                                <?php 
                                                $judgements = explode(', ', $rts['judgement']);
                                                ?>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox"
                                                        id="scrapdisposal" name="judgement[]" value="Scrap/Disposal"
                                                        <?= in_array('Scrap/Disposal', $judgements) ? 'checked' : '' ?>
                                                        disabled>
                                                    <label class="custom-control-label" for="scrapdisposal">Scrap/Disposal</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox" id="rtv"
                                                        name="judgement[]" value="RTV"
                                                        <?= in_array('RTV', $judgements) ? 'checked' : '' ?>
                                                        disabled>
                                                    <label class="custom-control-label" for="rtv">RTV</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox" id="hold"
                                                        name="judgement[]" value="Hold"
                                                        <?= in_array('Hold', $judgements) ? 'checked' : '' ?>
                                                        disabled>
                                                    <label class="custom-control-label" for="hold">Hold</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox"
                                                        id="transfertogood" name="judgement[]"
                                                        value="Transfer to Good"
                                                        <?= in_array('Transfer to Good', $judgements) ? 'checked' : '' ?>
                                                        disabled>
                                                    <label class="custom-control-label" for="transfertogood">Transfer to Good</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- SAP Location Code -->
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>SAP Location Code</label>
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>From</th>
                                                            <th>To</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <select class="form-control" name="sap_location[from]">
                                                                    <option value="" disabled>Select From Location</option>
                                                                    <?php foreach ($sap_locations as $location): ?>
                                                                        <option value="<?php echo htmlspecialchars($location['LocationCode']); ?>"
                                                                            <?= $rts['sap_loc_code'] == $location['LocationCode'] ? 'selected' : '' ?>>
                                                                            <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                        </option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </td>
                                                            <td>
                                                                <select class="form-control" name="sap_location[to]">
                                                                    <option value="" disabled selected>Select To Location</option>
                                                                    <?php foreach ($sap_locations as $location): ?>
                                                                        <option value="<?php echo htmlspecialchars($location['LocationCode']); ?>">
                                                                            <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                        </option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Details and Remarks -->
                                    <div class="row mt-3">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                <label for="details">Details (Others)</label>
                                                <textarea class="form-control" id="details" name="details" rows="3"
                                                    placeholder="Enter additional details" <?= empty($rts['details']) && empty($original_material_statuses) ? 'disabled' : '' ?>><?= htmlspecialchars($rts['details'] ?? '') ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                <label for="remarks">Remarks</label>
                                                <textarea name="remark" id="remark" class="form-control"
                                                    placeholder="Enter remarks"><?= htmlspecialchars($rts['remark'] ?? '') ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Approval Details -->
                                    <div class="row mt-3">
                                        <div class="col-lg-12 col-md-12">
                                            <div class="form-group">
                                                <label>Approval Details</label>
                                                <div class="approval-table-container">
                                                    <table class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th style="text-align: center;">Prepared By</th>
                                                                <th style="text-align: center;">Checked By</th>
                                                                <th style="text-align: center;">Approved By</th>
                                                                <th style="text-align: center;">Noted By</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <?php if (!empty($signature_base64)): ?>
                                                                            <img src="<?php echo $signature_base64; ?>" alt="E-Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                        <?php endif; ?>
                                                                        <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                                                                    </div>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                    </div>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                    </div>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Return Date, Department, Model -->
                                    <div class="row">
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <label for="return_date">Return Date</label>
                                                <input type="date" class="form-control" id="return_date"
                                                    name="return_date" value="<?= $rts['return_date'] ? date('Y-m-d', strtotime($rts['return_date']->format('Y-m-d'))) : '' ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <label for="department">Department</label>
                                                <select class="form-control" id="department" name="department">
                                                    <?php foreach ($departments as $dept): ?>
                                                        <option value="<?= htmlspecialchars($dept) ?>" <?= $rts['department'] == $dept ? 'selected' : '' ?>>
                                                            <?= htmlspecialchars($dept) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <label for="model">Model</label>
                                                <input type="text" class="form-control" id="model" name="model"
                                                    placeholder="Enter Model" value="<?= htmlspecialchars($rts['model'] ?? '') ?>">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Material Details -->
                                    <div class="row mt-3">
                                        <div class="col-12 d-flex justify-content-between align-items-center">
                                            <label class="font-weight-bold">Material Details</label>
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                                data-target="#materialDetailsModal">Add/View Details</button>
                                        </div>
                                    </div>
                                    
                                    <!-- Material Details Modal -->
                                    <div class="modal fade" id="materialDetailsModal" tabindex="-1" role="dialog"
                                        aria-labelledby="materialDetailsModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-xl" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="materialDetailsModalLabel">Material Details</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="approval-table-container">
                                                        <table id="material_details_table" class="table table-bordered table-striped">
                                                            <thead>
                                                                <tr>
                                                                    <th>No.</th>
                                                                    <th>Ref. No</th>
                                                                    <th>SAP Mat Doc Ref</th>
                                                                    <th>Invoice No</th>
                                                                    <th>Supplier</th>
                                                                    <th>Part Number</th>
                                                                    <th>Part Name</th>
                                                                    <th>Description</th>
                                                                    <th>Qty Returned</th>
                                                                    <th>Qty Received</th>
                                                                    <th>Amount</th>
                                                                    <th>Due Date</th>
                                                                    <th>Actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <!-- Pre-populate with existing materials -->
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="modal-footer d-flex justify-content-between align-items-center">
                                                    <div class="d-flex align-items-center" style="column-gap:10px;">
                                                        <div class="input-group" style="width: 220px; min-width:160px;">
                                                            <input type="number" class="form-control form-control-sm"
                                                                id="numRowsInput" placeholder="Enter Number of Rows"
                                                                min="1" max="50">
                                                        </div>
                                                        <button type="button" class="btn btn-secondary btn-sm"
                                                            id="addRowsBtn" style="margin-left:8px;">Add Rows</button>
                                                    </div>
                                                    <button type="button" class="btn btn-primary" data-dismiss="modal">Done</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row mt-3">
                                        <div class="col-12 text-center">
                                            <button type="submit" class="btn btn-primary">Resubmit RTS Form</button>
                                            <a href="<?php echo BASE_URL; ?>/pages/requests/disapproved_requests.php" class="btn btn-secondary">Cancel</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include INCLUDES_PATH . '/footer.php'; ?>
    </div>
</div>

<script>
// Pre-populate existing materials
const existingMaterials = <?php echo json_encode($items); ?>;

$(document).ready(function () {
    // Populate material details table with existing data when modal is first shown
    $('#materialDetailsModal').one('shown.bs.modal', function () {
        if (existingMaterials && existingMaterials.length > 0) {
            existingMaterials.forEach((material, index) => {
                const rowNumber = index + 1;
                let dueDate = '';
                
                // Handle date conversion properly
                if (material.due_date) {
                    if (material.due_date.date) {
                        dueDate = material.due_date.date.split(' ')[0];
                    } else {
                        dueDate = material.due_date.split(' ')[0];
                    }
                }
                
                const rowHtml = `
                    <tr data-row-number="${rowNumber}">
                        <td>${rowNumber}</td>
                        <td><input type="text" class="form-control form-control-sm" name="material_details[ref_no][]" value="${material.ref_no || ''}" placeholder="..."></td>
                        <td><input type="text" class="form-control form-control-sm" name="material_details[sap_doc][]" value="${material.sap_doc || ''}" placeholder="..."></td>
                        <td><input type="text" class="form-control form-control-sm" name="material_details[invoice_no][]" value="${material.invoice_no || ''}" placeholder="..."></td>
                        <td><input type="text" class="form-control form-control-sm" name="material_details[supplier][]" value="${material.supplier || ''}" placeholder="..."></td>
                        <td><input type="text" class="form-control form-control-sm" name="material_details[part_number][]" value="${material.part_number || ''}" placeholder="..."></td>
                        <td><input type="text" class="form-control form-control-sm" name="material_details[part_name][]" value="${material.part_name || ''}" placeholder="..."></td>
                        <td><input type="text" class="form-control form-control-sm" name="material_details[description][]" value="${material.description || ''}" placeholder="..."></td>
                        <td><input type="number" class="form-control form-control-sm" name="material_details[qty_returned][]" value="${material.qty_returned || ''}" placeholder="..."></td>
                        <td><input type="number" class="form-control form-control-sm" name="material_details[qty_received][]" value="${material.qty_received || ''}" placeholder="..."></td>
                        <td><input type="number" class="form-control form-control-sm amount-input" name="material_details[amount][]" value="${material.amount || ''}" placeholder="..."></td>
                        <td><input type="date" class="form-control form-control-sm" name="material_details[due_date][]" value="${dueDate}"></td>
                        <td><button type="button" class="btn btn-danger btn-sm remove-row-btn">Remove</button></td>
                    </tr>`;
                
                $('#material_details_table tbody').append(rowHtml);
            });
        }
    });
    
    // Initialize with material status logic
    $('.material-status-checkbox:checked').trigger('change');
    
    let totalRows = 0;
    
    // Function to generate editable table rows
        // Function to generate editable table rows
    function generateTableRows(numberOfRows) {
        let rowsHtml = '';
        const startingIndex = $('#material_details_table tbody tr').length + 1;
        for (let i = 0; i < numberOfRows; i++) {
            const rowNumber = startingIndex + i;
            rowsHtml += `
                <tr data-row-number="${rowNumber}">
                    <td>${rowNumber}</td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[ref_no][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[sap_doc][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[invoice_no][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[supplier][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_number][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_name][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[description][]" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_returned][]" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_received][]" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm amount-input" name="material_details[amount][]" placeholder="..."></td>
                    <td><input type="date" class="form-control form-control-sm" name="material_details[due_date][]"></td>
                    <td><button type="button" class="btn btn-danger btn-sm remove-row-btn">Remove</button></td>
                </tr>`;
        }
        totalRows += numberOfRows;
        return rowsHtml;
    }
    
    // Handle the "Add Rows" button click
    $('#addRowsBtn').on('click', function () {
        const numRows = parseInt($('#numRowsInput').val());
        if (numRows > 0 && numRows <= 50) {
            $('#material_details_table tbody').append(generateTableRows(numRows));
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Invalid Input',
                text: 'Please enter a number between 1 and 50.'
            });
        }
    });
    
    // Remove a row and re-number
    $(document).on('click', '.remove-row-btn', function () {
        $(this).closest('tr').remove();
        $('#material_details_table tbody tr').each(function (index) {
            $(this).find('td:first').text(index + 1);
        });
    });
    
    // Handle material status and judgement checkboxes
    $('.material-status-checkbox, .judgement-checkbox').change(function () {
        const isChecked = $(this).is(':checked');
        const groupClass = $(this).hasClass('material-status-checkbox') ? '.material-status-checkbox' : '.judgement-checkbox';
        if (isChecked) {
            $(groupClass).not(this).prop('checked', false);
        }

        if ($(this).hasClass('material-status-checkbox')) {
            const checkedStatus = $(this).val();
            const $allStatusCheckboxes = $('.material-status-checkbox');
            const $allJudgementCheckboxes = $('.judgement-checkbox');
            const $detailsField = $('#details');

            $allJudgementCheckboxes.prop('checked', false).prop('disabled', true);
            $detailsField.prop('disabled', !isChecked);
            if (!isChecked) {
                $detailsField.val('');
            }

            if (isChecked) {
                $allStatusCheckboxes.not(this).prop('disabled', true);

                if (checkedStatus === 'NG/Others') {
                    $('#scrapdisposal').prop('disabled', false);
                    $('#hold').prop('disabled', false);
                } else if (checkedStatus === 'Good') {
                    $('#transfertogood').prop('disabled', false);
                } else {
                    $('#scrapdisposal').prop('disabled', false);
                    $('#hold').prop('disabled', false);
                }
            } else {
                $allStatusCheckboxes.prop('disabled', false);
            }
        }
    });
    
    // Handle form submission
    $('#rtsResubmitForm').on('submit', function (e) {
        e.preventDefault();
        
        let isValid = true;
        let errorMessages = [];

        // Validation checks
        if ($('input[name="material_type[]"]:checked').length === 0) {
            isValid = false;
            errorMessages.push('Please select at least one Material Type.');
        }
        if ($('input[name="material_status[]"]:checked').length === 0) {
            isValid = false;
            errorMessages.push('Please select at least one Material Status.');
        }
        const selectedStatus = $('input[name="material_status[]"]:checked').val();
        const hasJudgement = $('input[name="judgement[]"]:checked').length > 0;

        if (selectedStatus === 'NG/Others' && !hasJudgement) {
            isValid = false;
            errorMessages.push('Please select a judgement (Scrap/Disposal or Hold) for NG/Others.');
        } else if (selectedStatus !== 'Good' && selectedStatus !== 'NG/Others' && selectedStatus !== undefined && !hasJudgement) {
            isValid = false;
            errorMessages.push('Please select at least one Judgement.');
        }

        if ($('#return_date').val().trim() === '') {
            isValid = false;
            errorMessages.push('Please select a Return Date.');
        }
        if ($('#department').val().trim() === '') {
            isValid = false;
            errorMessages.push('Please select a Department.');
        }
        
        const sapFromLocation = $('select[name="sap_location[from]"]').val();
        const sapToLocation = $('select[name="sap_location[to]"]').val();
        if (!sapFromLocation || !sapToLocation) {
            isValid = false;
            errorMessages.push('Please select both a "From" and "To" SAP Location Code.');
        }
        
        let hasMaterialDetails = false;
        $('#material_details_table tbody tr').each(function () {
            const $rowInputs = $(this).find('input');
            let rowIsFilled = false;
            $rowInputs.each(function () {
                if ($(this).val().trim() !== '' && !$(this).prop('disabled')) {
                    rowIsFilled = true;
                    return false;
                }
            });
            if (rowIsFilled) {
                hasMaterialDetails = true;
                return false;
            }
        });
        if (!hasMaterialDetails) {
            isValid = false;
            errorMessages.push('Please enter details for at least one material.');
        }

        if (!isValid) {
            Swal.fire({
                icon: 'error',
                title: 'Validation Error',
                html: errorMessages.join('<br>')
            });
            return;
        }

        // Show confirmation
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to resubmit this form?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Resubmit!'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Resubmitting Form...',
                    text: 'Please wait, sending approval request...',
                    icon: 'info',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
                
                const form = $(this);
                $.ajax({
                    url: form.attr('action'),
                    type: form.attr('method'),
                    data: form.serialize(),
                    dataType: 'json',
                    success: function (response) {
                        Swal.close();
                        
                        if (response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'RTS Form Resubmitted Successfully!',
                                html: 'Your RTS Control Number: <strong>' + response.control_no + '</strong>',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.href = `<?php echo BASE_URL; ?>/pages/requests/pending_requests.php`;
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Resubmission Failed!',
                                text: response.message,
                                confirmButtonText: 'Try Again'
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.close();
                        Swal.fire({
                            icon: 'error',
                            title: 'An error occurred!',
                            text: 'Please try again. ' + xhr.responseText,
                            confirmButtonText: 'OK'
                        });
                    }
                });
            }
        });
    });
});
</script>
