<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';

require APP_ROOT . '/PHPMailer/src/PHPMailer.php';
require APP_ROOT . '/PHPMailer/src/SMTP.php';
require APP_ROOT . '/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

/**
 * Send email notification for new RTS submission
 * @param array $recipientEmails Array of recipient email addresses
 * @param string $control_no Control number of the RTS form
 * @return bool Success status
 */
function sendEmailRTS(array $recipientEmails, string $control_no) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $subject = "RTS Checking Request Notification (Control No: $control_no)";
    
    $message = "<p>Good Day,</p>";
    $message .= "<p>A new RTS form with control number <b>$control_no</b> has been submitted and requires your checking.</p>";
    $message .= "<p>Please login to the system to review this request.</p>";
    $message .= "<p>Thank you.</p>";
    $message .= "<br><p><i>This is an automated message. Please do not reply.</i></p>";

    return sendEmail($recipientEmails, $subject, $message, "RTS submission", $control_no);
}

/**
 * Send email notification for RTS resubmission
 * @param array $recipientEmails Array of recipient email addresses
 * @param string $control_no New control number of the resubmitted form
 * @param string $original_control_no Original control number
 * @return bool Success status
 */
function sendEmailRTSResubmission(array $recipientEmails, string $control_no, string $original_control_no) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $subject = "RTS Resubmission Notification (Control No: $control_no)";
    
    $message = "<p>Good Day,</p>";
    $message .= "<p>A previously disapproved RTS form has been <b>resubmitted</b> for your review.</p>";
    $message .= "<p><b>New Control Number:</b> $control_no</p>";
    $message .= "<p><b>Original Control Number:</b> $original_control_no</p>";
    $message .= "<p>The requestor has made corrections based on the disapproval feedback.</p>";
    $message .= "<p>Please login to the system to review this resubmission.</p>";
    $message .= "<p>Thank you.</p>";
    $message .= "<br><p><i>This is an automated message. Please do not reply.</i></p>";

    return sendEmail($recipientEmails, $subject, $message, "RTS resubmission", $control_no);
}

/**
 * Send approval/disapproval notification email
 * @param array 
 * @param string 
 * @param string 
 * @param string 
 * @param string 
 * @param string|null 
 * @return bool 
 */
function sendApprovalEmail(array $recipientEmails, string $control_no, string $action, string $role, string $approverName, ?string $reason = null) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No requestor email provided.");
        return false;
    }

    // Format the action and role
    $subject_status = ucfirst($action);
    $body_status = ucfirst($action) . "d";
    $approverName = ucfirst($approverName);
    $role = ucfirst($role);

    $subject = "RTS Request (Control No: $control_no) has been {$subject_status}d";

    $message = "<p>Good Day,</p>";
    $message .= "<p>Your RTS request with control number <b>$control_no</b> has been <b>$body_status</b> by <b>$approverName</b> ($role).</p>";
    
    if ($action === 'disapprove' && $reason) {
        $message .= "<p><b>Reason for disapproval:</b> <i>" . htmlspecialchars($reason) . "</i></p>";
        $message .= "<p>You may resubmit this request after addressing the feedback provided above.</p>";
    }
    
    $message .= "<p>Please login to the system for more details.</p>";
    $message .= "<p>Thank you.</p>";
    $message .= "<br><p><i>This is an automated message. Please do not reply.</i></p>";

    return sendEmail($recipientEmails, $subject, $message, "RTS $action notification", $control_no);
}

/**
 * Send notification when RTS is fully approved (all approvers have approved)
 * @param array $recipientEmails Array of recipient email addresses
 * @param string $control_no Control number of the RTS form
 * @return bool Success status
 */
function sendFullyApprovedEmail(array $recipientEmails, string $control_no) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $subject = "RTS Request (Control No: $control_no) - Fully Approved";
    
    $message = "<p>Good Day,</p>";
    $message .= "<p>Your RTS request with control number <b>$control_no</b> has been <b>fully approved</b> by all required approvers.</p>";
    $message .= "<p>The request is now ready for processing.</p>";
    $message .= "<p>Please login to the system to view the details and proceed with the next steps.</p>";
    $message .= "<p>Thank you.</p>";
    $message .= "<br><p><i>This is an automated message. Please do not reply.</i></p>";

    return sendEmail($recipientEmails, $subject, $message, "RTS fully approved notification", $control_no);
}

/**
 * Core email sending function using PHPMailer
 * @param array $recipientEmails Array of recipient email addresses
 * @param string $subject Email subject
 * @param string $body Email body (HTML)
 * @param string $type Type of email for logging purposes
 * @param string $control_no Control number for logging
 * @return bool Success status
 */
function sendEmail(array $recipientEmails, string $subject, string $body, string $type, string $control_no) {
    $mail = new PHPMailer();
    
    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.office365.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'foph.dc-noreply@007.fujifilm.com';
        $mail->Password = 'Fujifilm@4';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        // Set sender - ensure it matches the SMTP username
        $mail->setFrom('foph.dc-noreply@007.fujifilm.com', 'FOPH RTS System');
        
        // Add recipients
        foreach ($recipientEmails as $email) {
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $mail->addAddress($email);
            } else {
                error_log("Invalid email address skipped: $email");
            }
        }
        
        // If no valid recipients, abort
        if (empty($mail->getAllRecipientAddresses())) {
            error_log("No valid recipient addresses for $type (Control No: $control_no)");
            return false;
        }
        
        // Email content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>', '<br />', '</p>'], "\n", $body));
        
        // Disable error display for production
        ini_set('display_errors', 0);
        ini_set('display_startup_errors', 0);
        error_reporting(E_ALL);
        
        // Send email
        if ($mail->send()) {
            error_log("$type email sent successfully for Control No: $control_no to " . count($recipientEmails) . " recipient(s)");
            return true;
        } else {
            error_log("$type email failed for Control No: $control_no. Error: " . $mail->ErrorInfo);
            return false;
        }
        
    } catch (Exception $e) {
        error_log("$type email exception for Control No: $control_no. Exception: " . $e->getMessage());
        return false;
    }
}

/**
 * Get next approver emails based on current approval stage
 * @param string $current_stage Current approval stage (checker/approver/noter)
 * @return array Array of email addresses
 */
function getNextApproverEmails(string $current_stage) {
    try {
        $db = new Connection();
        $conn = $db->link;
        
        $next_role = '';
        switch ($current_stage) {
            case 'checker':
                $next_role = 'approver';
                break;
            case 'approver':
                $next_role = 'noter';
                break;
            default:
                return [];
        }
        
        $emails = [];
        $sql = "SELECT email FROM users WHERE role LIKE ?";
        $params = ["%$next_role%"];
        $stmt = sqlsrv_query($conn, $sql, $params);
        
        if ($stmt === false) {
            error_log("Failed to fetch $next_role emails: " . print_r(sqlsrv_errors(), true));
            return [];
        }
        
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            if (!empty($row['email'])) {
                $emails[] = $row['email'];
            }
        }
        
        return $emails;
        
    } catch (Exception $e) {
        error_log("Error fetching next approver emails: " . $e->getMessage());
        return [];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }
}

/**
 * Get requestor email by form ID
 * @param int $form_id RTS form ID
 * @return array Array containing requestor email
 */
function getRequestorEmail(int $form_id) {
    try {
        $db = new Connection();
        $conn = $db->link;
        
        $sql = "SELECT u.email 
                FROM rts_forms rf 
                JOIN users u ON rf.requestor_id = u.user_id 
                WHERE rf.id = ?";
        
        $stmt = sqlsrv_query($conn, $sql, [$form_id]);
        
        if ($stmt === false) {
            error_log("Failed to fetch requestor email: " . print_r(sqlsrv_errors(), true));
            return [];
        }
        
        if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            return !empty($row['email']) ? [$row['email']] : [];
        }
        
        return [];
        
    } catch (Exception $e) {
        error_log("Error fetching requestor email: " . $e->getMessage());
        return [];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }
}
?>