<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';

$error_message = '';
$login_success = false;

// If user is already logged in, redirect immediately
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $role = $_SESSION['user_role'] ?? 'user';
    // Check if the user has a "higher" role for redirection
    if (str_contains($role, 'admin')) {
        header('Location: pages/admin/admin_dashboard.php');
    } elseif (str_contains($role, 'approver') || str_contains($role, 'checker') || str_contains($role, 'noter')) {
        header('Location: pages/approver/approver_dashboard.php');
    } else {
        header('Location: pages/user/user_dashboard.php');
    }
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($username) && !empty($password)) {
        try {
            $conn = new Connection();
            // Fetching all necessary user data for session
            $sql = "SELECT user_id, username, password, role, department, category FROM users WHERE username = ?";
            $stmt = sqlsrv_prepare($conn->link, $sql, array(&$username));

            if (!$stmt || !sqlsrv_execute($stmt)) {
                throw new Exception('Database query error');
            }

            if (sqlsrv_has_rows($stmt)) {
                $user = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

                if (password_verify($password, $user['password'])) {
                    // Set session variables
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['user_role'] = $user['role']; // This is the string "checker,approver,noter"
                    $_SESSION['user_department'] = $user['department'];
                    $_SESSION['user_category'] = $user['category'];
                    
                    // Update last_login timestamp
                    $update_login_sql = "UPDATE users SET last_login = GETDATE() WHERE user_id = ?";
                    $update_params = array($user['user_id']);
                    $update_stmt = sqlsrv_prepare($conn->link, $update_login_sql, $update_params);
                    
                    if ($update_stmt) {
                        sqlsrv_execute($update_stmt);
                        sqlsrv_free_stmt($update_stmt);
                    }
                    
                    // Handle active session tracking
                    try {
                        $session_id = session_id();
                        
                        // First, remove any existing sessions for this user
                        $cleanup_user_sql = "DELETE FROM active_sessions WHERE user_id = ?";
                        sqlsrv_query($conn->link, $cleanup_user_sql, array($user['user_id']));
                        
                        // Clean up old sessions (older than 30 minutes)
                        $cleanup_sql = "DELETE FROM active_sessions WHERE last_activity < DATEADD(minute, -30, GETDATE())";
                        sqlsrv_query($conn->link, $cleanup_sql);
                        
                        // Insert new session record
                        $insert_session_sql = "INSERT INTO active_sessions (session_id, user_id, last_activity) VALUES (?, ?, GETDATE())";
                        $insert_session_params = array($session_id, $user['user_id']);
                        $insert_result = sqlsrv_query($conn->link, $insert_session_sql, $insert_session_params);
                        
                        if ($insert_result === false) {
                            error_log("Failed to insert active session: " . print_r(sqlsrv_errors(), true));
                        }
                    } catch (Exception $e) {
                        error_log("Active session tracking error: " . $e->getMessage());
                    }
                    
                    $login_success = true;
                } else {
                    $error_message = 'Invalid username or password';
                }
            } else {
                $error_message = 'Invalid username or password';
            }

        } catch (Exception $e) {
            $error_message = $e->getMessage();
        } finally {
            if (isset($conn)) {
                $conn->close();
            }
        }
    } else {
        $error_message = 'Please fill in all fields';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Login - Centralized RTV/RTS System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.5/dist/sweetalert2.min.css" />
    <style>
        /* CSS rules remain unchanged */
        body, html {
            height: 100%;
            margin: 0;
            background: #fafafa;
            font-family: 'Montserrat', sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            color: #4a4a4a;
        }
        .login-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #fefefe;
            padding: 20px;
            box-sizing: border-box;
        }
        .login-card {
            background: #fff;
            max-width: 420px;
            width: 100%;
            padding: 40px 30px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.07), 0 4px 8px rgba(0,0,0,0.08);
            border-radius: 12px;
            border: 1px solid #e6e4df;
            position: relative;
            transition: box-shadow 0.3s ease;
        }
        .login-card:hover {
            box-shadow: 0 6px 15px rgba(0,0,0,0.12), 0 10px 25px rgba(0,0,0,0.1);
        }
        .card-header {
            text-align: center;
            margin-bottom: 28px;
        }
        .logo-login {
            max-width: 130px;
            margin-bottom: 18px;
            filter: drop-shadow(0 1px 1px rgba(0,0,0,0.05));
        }
        .card-category {
            font-weight: 600;
            color: #616161;
            letter-spacing: 0.05em;
            font-size: 1.1rem;
            text-transform: uppercase;
            user-select: none;
        }
        form .form-group label {
            color: #6a6a6a;
            font-weight: 600;
            letter-spacing: 0.03em;
            margin-bottom: 8px;
        }
        .input-group-prepend {
            display: flex;
            align-items: center;
            background-color: #f7f7f5;
            border: 1px solid #dadcd9ff;
            border-right: none;
            border-radius: 6px 0 0 6px;
            padding: 0 12px;
        }
        .input-group-prepend i.fa {
            font-size: 1.25rem;
            color: #8d8d8d;
            line-height: 1.8;
        }
        .form-control {
            border: 1px solid #dcdcd9;
            border-left: none;
            border-radius: 0 6px 6px 0;
            background-color: #fefefe;
            color: #4a4a4a;
            box-shadow: inset 1px 1px 3px #f0f0ed;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            font-size: 1rem;
            height: 44px;
            padding: 0 12px;
        }
        .form-control:focus {
            border-color: #a3a39a;
            box-shadow: inset 1px 1px 6px #e5e5df;
            background-color: #fff;
            outline: none;
            color: #3c3c3c;
        }
        .input-group {
            box-shadow: inset 1px 1px 3px #f9f9f7, inset -1px -1px 3px #dbdbd8;
            border-radius: 6px;
            overflow: hidden;
            display: flex;
        }
        .btn-primary {
            background: #b2f59dff;
            border: 1px solid #b2f59dff;
            color: #2f2f2f;
            font-weight: 700;
            text-transform: uppercase;
            width: 100%;
            padding: 12px 0;
            border-radius: 10px;
            box-shadow: 0 3px 6px rgba(148,151,148,0.45);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            letter-spacing: 0.08em;
            font-size: 1.1rem;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
        }
        .btn-primary:hover, .btn-primary:focus {
            background: #8b8f8c;
            color: #f9f9f7;
            border-color: #7a7e7b;
            box-shadow: 0 6px 12px rgba(122,126,123,0.6);
            outline: none;
        }
        .btn-round {
            border-radius: 30px !important;
        }
        .btn-lg {
            font-size: 1.15rem;
        }
        .text-center {
            margin-top: 25px;
        }
        /* SweetAlert2 neutral style */
        .swal2-popup {
            background: #fff !important;
            color: #4a4a4a !important;
            box-shadow: 0 0 15px rgba(157, 157, 157, 0.2) !important;
            border-radius: 12px !important;
            font-family: 'Montserrat', sans-serif !important;
        }
        .swal2-confirm {
            background-color: #aeb3b0 !important;
            color: #2f2f2f !important;
            font-weight: 700 !important;
            text-transform: uppercase !important;
            border-radius: 10px !important;
        }
        .swal2-confirm:hover {
            background-color: #8b8f8c !important;
            color: #f9f9f7 !important;
        }
        /* Responsive */
        @media (max-width: 480px) {
            .login-card {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="card login-card paper-theme" role="main" aria-label="Login form">
            <div class="card-header">
                <img src="assets/img/logo_black.png" alt="Company Logo" class="logo-login" />
                <p class="card-category">Centralized RTV/RTS System</p>
            </div>
            <div class="card-body">
                <form method="POST" action="" aria-describedby="login-instructions">
                    <p id="login-instructions" class="sr-only">Please enter your username and password to login.</p>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <div class="input-group">
                            <div class="input-group-prepend" aria-hidden="true">
                                <i class="fa fa-user"></i>
                            </div>
                            <input type="text" id="username" name="username" class="form-control" required autocomplete="username" aria-required="true" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-group">
                            <div class="input-group-prepend" aria-hidden="true">
                                <i class="fa fa-lock"></i>
                            </div>
                            <input type="password" id="password" name="password" class="form-control" required autocomplete="current-password" aria-required="true" />
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-round btn-lg" aria-label="Login button">
                            <i class="fa fa-sign-in-alt" aria-hidden="true"></i> Login
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="assets/js/core/jquery.min.js"></script>
    <script src="assets/js/core/popper.min.js"></script>
    <script src="assets/js/core/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.5/dist/sweetalert2.all.min.js"></script>
    <script>
        <?php if (!empty($error_message)): ?>
        Swal.fire({
            icon: 'error',
            title: 'Login Failed',
            text: '<?php echo htmlspecialchars($error_message, ENT_QUOTES); ?>',
            confirmButtonColor: '#8b8f8c',
        });
        <?php endif; ?>

        <?php if ($login_success): ?>
        const role = '<?php echo htmlspecialchars($_SESSION['user_role'] ?? 'user', ENT_QUOTES); ?>';
        let dashboard_url = '';

        if (role.includes('admin')) {
            dashboard_url = 'pages/admin/admin_dashboard.php';
        } else if (role.includes('approver') || role.includes('checker') || role.includes('noter')) {
            dashboard_url = 'pages/approver/approver_dashboard.php';
        } else {
            dashboard_url = 'pages/user/user_dashboard.php';
        }

        Swal.fire({
            icon: 'success',
            title: 'Login Successful!',
            text: 'You will be redirected to the dashboard shortly.',
            timer: 1100,
            timerProgressBar: true,
            showConfirmButton: false,
            didClose: () => {
                window.location.href = dashboard_url;
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>