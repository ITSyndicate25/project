<?php
class Connection
{
    public $link;
    public $centralizedLink;
    private $closed = false;

    public function __construct()
    {
        $conn_array = array(
            "UID" => "foph",
            "PWD" => "fophfoph",
            "Database" => "dbfophcrtvsproject",
            "CharacterSet" => "UTF-8"
        );

        $this->link = sqlsrv_connect('192.168.132.170', $conn_array);

        if ($this->link === false) {
            die('Could not connect to dbfophcrtvsproject: ' . print_r(sqlsrv_errors(), true));
        }
    }

    public function insertImage() {
        $connArray2 = array (
        "UID" => "foph",
            "PWD" => "fophfoph",
            "Database" => "dbfophcrtvsproject",
            );

        $this->link = sqlsrv_connect('192.168.132.170', $connArray2);
    
        if ($this->link === false) {
            die('Could not connect to the second database: ' . print_r(sqlsrv_errors(), true));
        }
    }

    public function close()
    {
        if ($this->closed) {
            return; // Already closed
        }
        
        if ($this->link && is_resource($this->link)) {
            sqlsrv_close($this->link);
            $this->link = null;
        }
        
        if ($this->centralizedLink && is_resource($this->centralizedLink)) {
            sqlsrv_close($this->centralizedLink);
            $this->centralizedLink = null;
        }
        
        $this->closed = true;
    }

    public function query($sql)
    {
        if ($this->closed || !$this->link) {
            throw new Exception("Database connection is closed");
        }
        return sqlsrv_query($this->link, $sql);
    }
    
    public function __destruct()
    {
        $this->close();
    }
}
?>