<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once INCLUDES_PATH . '/functions.php';
?>

<div class="sidebar" data-color="white" data-active-color="danger">
    <div class="logo">
        <a href="#" class="simple-text logo-normal">
            <div class="logo-image-small">
                <img src="<?php echo BASE_URL; ?>/assets/img/logo_sidebar.png" alt="Logo">
            </div>
        </a>
        <a href="#" class="simple-text logo-small"></a>
    </div>

    <div class="sidebar-wrapper">
        <ul class="nav" id="sidebarNav">
            <li class="<?php echo isActive(['admin_dashboard.php', 'user_dashboard.php', 'approver_dashboard.php', 'index.php']); ?>">
                <a
                    href="<?php
                        if (isset($_SESSION['user_role'])) {
                            if (str_contains($_SESSION['user_role'], 'admin')) {
                                echo BASE_URL . '/pages/admin/admin_dashboard.php';
                            } elseif (str_contains($_SESSION['user_role'], 'approver') || str_contains($_SESSION['user_role'], 'checker') || str_contains($_SESSION['user_role'], 'noter')) {
                                echo BASE_URL . '/pages/approver/approver_dashboard.php';
                            } else {
                                echo BASE_URL . '/pages/user/user_dashboard.php';
                            }
                        } else {
                            echo BASE_URL . '/pages/user/user_dashboard.php';
                        }
                    ?>">
                    <i class="nc-icon nc-bank"></i>
                    <p style="color: black;">Dashboard</p>
                </a>
            </li>

            <?php if (isset($_SESSION['user_id']) && isset($_SESSION['user_role'])) { ?>
                <?php
                $user_department = $_SESSION['department'] ?? getUserDepartment($_SESSION['user_id']);
                // Check if the user is a 'user' or 'admin' and has scrap permission.
                if ((str_contains($_SESSION['user_role'], 'user') || str_contains($_SESSION['user_role'], 'admin')) && checkScrapPermission($user_department, $_SESSION['user_role'])) { ?>
                    <li class="<?php echo isActive(['scrap_dashboard.php', 'rts_form.php']); ?>">
                        <a href="<?php echo BASE_URL; ?>/pages/scrap/scrap_dashboard.php">
                            <i class="nc-icon nc-book-bookmark"></i>
                            <p style="color: black;">Scrap Forms</p>
                        </a>
                    </li>
                <?php } ?>

                <?php
                if (str_contains($_SESSION['user_role'], 'admin') || str_contains($_SESSION['user_role'], 'user') || str_contains($_SESSION['user_role'], 'approver') || str_contains($_SESSION['user_role'], 'checker') || str_contains($_SESSION['user_role'], 'noter')) { ?>
                  <li class="nav-item has-dropdown <?php echo isActive(['pending_requests.php', 'ongoing_requests.php', 'to_review_requests.php', 'completed_requests.php', 'disapproved_requests.php']); ?>">
                    <a href="#myRequestsSubmenu" data-toggle="collapse" class="nav-link collapsed">
                        <i class="nc-icon nc-single-copy-04"></i>
                        <p style="color: black;">
                            <?php
                            if (str_contains($_SESSION['user_role'], 'admin')) {
                                echo 'Requests';
                            } elseif (str_contains($_SESSION['user_role'], 'approver') || str_contains($_SESSION['user_role'], 'checker') || str_contains($_SESSION['user_role'], 'noter')) {
                                echo 'For Approval';
                            } else {
                                echo 'My Requests';
                            }
                            ?>
                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse <?php echo (isActive(['pending_requests.php', 'ongoing_requests.php', 'to_review_requests.php', 'completed_requests.php', 'disapproved_requests.php']) == 'active') ? 'show' : ''; ?>" id="myRequestsSubmenu">
                        <ul class="nav">
                            <?php if (str_contains($_SESSION['user_role'], 'admin') || str_contains($_SESSION['user_role'], 'user') || str_contains($_SESSION['user_role'], 'checker')) { ?>
                                <li class="<?php echo isActive('pending_requests.php'); ?>">
                                    <a href="<?php echo BASE_URL; ?>/pages/requests/pending_requests.php">
                                        <i class="fas fa-hourglass-half"></i>
                                        <span class="sidebar-normal">Pending</span>
                                    </a>
                                </li>
                            <?php } ?>
                            <li class="<?php echo isActive('ongoing_requests.php'); ?>">
                                <a href="<?php echo BASE_URL; ?>/pages/requests/ongoing_requests.php">
                                    <i class="fas fa-sync-alt"></i>
                                    <span class="sidebar-normal">Ongoing</span>
                                </a>
                            </li>
                            <li class="<?php echo isActive('completed_requests.php'); ?>">
                                <a href="<?php echo BASE_URL; ?>/pages/requests/completed_requests.php">
                                    <i class="nc-icon nc-check-2"></i>
                                    <span class="sidebar-normal">Completed</span>
                                </a>
                            </li>
                            <li class="<?php echo isActive('disapproved_requests.php'); ?>">
                                    <a href="<?php echo BASE_URL; ?>/pages/requests/disapproved_requests.php">
                                        <i class="nc-icon nc-simple-remove"></i>
                                        <span class="sidebar-normal">Disapproved</span>
                                    </a>
                                </li>
                        </ul>
                    </div>
                </li>
                <?php } ?>

                <?php
                
                if (str_contains($_SESSION['user_role'], 'admin')) { ?>
                    <li class="<?php echo isActive('user_management.php'); ?>">
                        <a href="<?php echo BASE_URL; ?>/pages/admin/user_management.php">
                            <i class="nc-icon nc-settings-gear-65"></i>
                            <p style="color: black;">User Management</p>
                        </a>
                    </li>
                    <li class="<?php echo isActive('masterlist.php'); ?>">
                        <a href="<?php echo BASE_URL; ?>/pages/admin/masterlist.php">
                            <i class="nc-icon nc-paper"></i>
                            <p style="color: black;">SAP Masterlist</p>
                        </a>
                    </li>
                <?php } ?>
            <?php } ?>
        </ul>
    </div>
</div>