<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';

require APP_ROOT . '/PHPMailer/src/PHPMailer.php';
require APP_ROOT . '/PHPMailer/src/SMTP.php';
require APP_ROOT . '/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Global connection for reuse
$global_db_connection = null;

/**
 * REQUIREMENT: Send email notification for new RTS submission to checker role
 */
function sendEmailRTS(array $recipientEmails, string $control_no) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $subject = "Pending Approval Request - $control_no";
    
    $message = "<p>Good Day,</p>";
    $message .= "<p>You have a pending approval request for the following RTS Form:</p>";
    $message .= "<p><b>Control Number:</b> $control_no<br>";
    $message .= "<b>Request Status:</b> For Checking</p>";
    $message .= "<p>Please review the request and take appropriate action whenever you can.</p>";
    $message .= "<p>Thank you!</p>";
    $message .= "<br><p><i>This is an automatically generated email. Please do not reply to this message.</i></p>";

    return sendEmailFast($recipientEmails, $subject, $message, "RTS submission", $control_no);
}

/**
 * REQUIREMENT: Send email notification for RTS resubmission to checker role (fallback)
 */
function sendEmailRTSResubmission(array $recipientEmails, string $control_no, string $original_control_no = '') {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $subject = "Pending Approval Request - $control_no (Resubmission)";
    
    $message = "<p>Good Day,</p>";
    $message .= "<p>You have a pending approval request for the following RTS Form:</p>";
    $message .= "<p><b>Control Number:</b> $control_no<br>";
    $message .= "<b>Request Status:</b> For Checking (Resubmitted)</p>";
    $message .= "<p>The requestor has made corrections based on previous feedback and resubmitted the form.</p>";
    $message .= "<p>Please review the request and take appropriate action whenever you can.</p>";
    $message .= "<p>Thank you!</p>";
    $message .= "<br><p><i>This is an automatically generated email. Please do not reply to this message.</i></p>";

    return sendEmailFast($recipientEmails, $subject, $message, "RTS resubmission", $control_no);
}

/**
 * REQUIREMENT: Send resubmission notification to the specific approver who originally disapproved
 */
function sendResubmissionToApproverEmail(array $recipientEmails, string $control_no, array $disapproval_info) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $approver_name = $disapproval_info['approver_name'] ?? 'Unknown Approver';
    $disapproval_role = ucfirst($disapproval_info['role'] ?? 'approver');
    $disapproval_reason = $disapproval_info['reason'] ?? 'No reason provided';
    
    $subject = "Request Resubmitted - $control_no";
    
    $message = "<p>Good Day $approver_name,</p>";
    $message .= "<p>A request that you previously disapproved has been resubmitted with corrections:</p>";
    $message .= "<p><b>Control Number:</b> $control_no<br>";
    $message .= "<b>Your Previous Role:</b> $disapproval_role<br>";
    $message .= "<b>Previous Disapproval Reason:</b><br><i>" . htmlspecialchars($disapproval_reason) . "</i><br>";
    $message .= "<b>Request Status:</b> Resubmitted for Review</p>";
    $message .= "<p>The requestor has made corrections based on your feedback. Please review the updated request and take appropriate action.</p>";
    $message .= "<p>Thank you!</p>";
    $message .= "<br><p><i>This is an automatically generated email. Please do not reply to this message.</i></p>";

    return sendEmailFast($recipientEmails, $subject, $message, "RTS resubmission to original approver", $control_no);
}

/**
 * Send approval request notification email (general purpose)
 */
function sendApprovalRequestEmail(array $recipientEmails, string $control_no, string $requestor_name, string $date_submitted, string $status) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $subject = "Pending Approval Request - $control_no";
    
    $message = "<p>Good Day,</p>";
    $message .= "<p>You have a pending approval request for the following RTS Form:</p>";
    $message .= "<p><b>Control Number:</b> $control_no<br>";
    $message .= "<b>Date Submitted:</b> $date_submitted<br>";
    $message .= "<b>Requestor:</b> $requestor_name<br>";
    $message .= "<b>Request Status:</b> $status</p>";
    $message .= "<p>Please review the request and take appropriate action whenever you can.</p>";
    $message .= "<p>Thank you!</p>";
    $message .= "<br><p><i>This is an automatically generated email. Please do not reply to this message.</i></p>";

    return sendEmailFast($recipientEmails, $subject, $message, "Approval request notification", $control_no);
}

/**
 * REQUIREMENT: Send approval notification email to original preparer (user) at every stage
 */
function sendUserApprovalNotificationEmail(array $recipientEmails, string $control_no, string $requestor_name, string $date_submitted, string $approved_by_role, string $approved_by_name, string $next_step = '') {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $subject = "Request Approved - $control_no";
    
    $message = "<p>Good Day $requestor_name,</p>";
    $message .= "<p>Your RTS request has been approved with the following details:</p>";
    $message .= "<p><b>Control Number:</b> $control_no<br>";
    $message .= "<b>Date Submitted:</b> $date_submitted<br>";
    $message .= "<b>Requestor:</b> $requestor_name<br>";
    $message .= "<b>Approved By:</b> $approved_by_name (" . ucfirst($approved_by_role) . ")<br>";
    
    if (!empty($next_step)) {
        $message .= "<b>Request Status:</b> $next_step</p>";
        $message .= "<p>Your request is now proceeding to the next approval stage.</p>";
    } else {
        $message .= "<b>Request Status:</b> Approved</p>";
        $message .= "<p>Your request has been processed successfully.</p>";
    }
    
    $message .= "<p>Thank you!</p>";
    $message .= "<br><p><i>This is an automatically generated email. Please do not reply to this message.</i></p>";

    return sendEmailFast($recipientEmails, $subject, $message, "User approval notification", $control_no);
}

/**
 * REQUIREMENT: Send disapproval notification email to original preparer (user) at every stage
 */
function sendUserDisapprovalNotificationEmail(array $recipientEmails, string $control_no, string $requestor_name, string $date_submitted, string $reason, string $disapproved_by_role, string $disapproved_by_name) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $subject = "Request Disapproved - $control_no";
    
    $message = "<p>Good Day $requestor_name,</p>";
    $message .= "<p>Your RTS request has been disapproved with the following details:</p>";
    $message .= "<p><b>Control Number:</b> $control_no<br>";
    $message .= "<b>Date Submitted:</b> $date_submitted<br>";
    $message .= "<b>Requestor:</b> $requestor_name<br>";
    $message .= "<b>Request Status:</b> Disapproved<br>";
    $message .= "<b>Disapproved By:</b> $disapproved_by_name (" . ucfirst($disapproved_by_role) . ")</p>";
    $message .= "<p><b>Reason for Disapproval:</b><br><i>" . htmlspecialchars($reason) . "</i></p>";
    $message .= "<p>You may resubmit this request after addressing the feedback provided above.</p>";
    $message .= "<p>Thank you!</p>";
    $message .= "<br><p><i>This is an automatically generated email. Please do not reply to this message.</i></p>";

    return sendEmailFast($recipientEmails, $subject, $message, "User disapproval notification", $control_no);
}

/**
 * REQUIREMENT: Send fully approved notification email to original preparer (user) when fully approved
 */
function sendUserFullyApprovedEmail(array $recipientEmails, string $control_no, string $requestor_name, string $date_submitted) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No recipient emails provided.");
        return false;
    }

    $subject = "Request Fully Approved - $control_no";
    
    $message = "<p>Good Day $requestor_name,</p>";
    $message .= "<p>Congratulations! Your RTS request has been fully approved with the following details:</p>";
    $message .= "<p><b>Control Number:</b> $control_no<br>";
    $message .= "<b>Date Submitted:</b> $date_submitted<br>";
    $message .= "<b>Requestor:</b> $requestor_name<br>";
    $message .= "<b>Request Status:</b> <strong style='color: green;'>Fully Approved</strong></p>";
    $message .= "<p>Your request has been successfully processed and completed. All required approvals (Checker, Approver, and Noter) have been obtained.</p>";
    $message .= "<p>You may now proceed with your material return to supplier process.</p>";
    $message .= "<p>Thank you!</p>";
    $message .= "<br><p><i>This is an automatically generated email. Please do not reply to this message.</i></p>";

    return sendEmailFast($recipientEmails, $subject, $message, "User full approval notification", $control_no);
}

/**
 * Core email sending function with connection pooling and instance reuse
 */
function sendEmailFast(array $recipientEmails, string $subject, string $body, string $type, string $control_no) {
    static $mail_instance = null;
    static $smtp_connected = false;
    
    try {
        // Reuse PHPMailer instance for better performance
        if ($mail_instance === null) {
            $mail_instance = new PHPMailer(true);
            
            // SMTP Configuration - Optimized for speed
            $mail_instance->isSMTP();
            $mail_instance->Host = 'smtp.office365.com';
            $mail_instance->SMTPAuth = true;
            $mail_instance->Username = 'foph.dc-noreply@007.fujifilm.com';
            $mail_instance->Password = 'Fujifilm@4';
            $mail_instance->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail_instance->Port = 587;
            
            // Performance optimizations
            $mail_instance->SMTPKeepAlive = true;
            $mail_instance->Timeout = 8; 
            $mail_instance->SMTPDebug = 0;
            $mail_instance->Debugoutput = function($str, $level) {}; // Silent debug
            
            $mail_instance->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            
            // Set sender once
            $mail_instance->setFrom('foph.dc-noreply@007.fujifilm.com', 'FOPH RTV & RTS System');
        }
        
        // Clear previous recipients but keep connection
        $mail_instance->clearAddresses();
        
        // Validate and add recipients (limit to 15 for performance)
        $valid_emails = [];
        foreach (array_slice($recipientEmails, 0, 15) as $email) {
            $email = trim($email);
            if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $valid_emails[] = $email;
                $mail_instance->addAddress($email);
            }
        }
        
        if (empty($valid_emails)) {
            error_log("No valid recipient addresses for $type (Control No: $control_no)");
            return false;
        }
        
        // Set content
        $mail_instance->isHTML(true);
        $mail_instance->Subject = $subject;
        $mail_instance->Body = $body;
        
        $start_time = microtime(true);
        $result = $mail_instance->send();
        $end_time = microtime(true);
        
        if ($result) {
            $duration = round(($end_time - $start_time), 2);
            error_log("$type email sent successfully for Control No: $control_no to " . count($valid_emails) . " recipient(s) in {$duration}s");
            return true;
        } else {
            error_log("$type email failed for Control No: $control_no. Error: " . $mail_instance->ErrorInfo);
            return false;
        }
        
    } catch (Exception $e) {
        error_log("$type email exception for Control No: $control_no. Exception: " . $e->getMessage());
        
        // Reset mail instance on critical errors
        if (strpos($e->getMessage(), 'SMTP') !== false) {
            $mail_instance = null;
            $smtp_connected = false;
        }
        
        return false;
    }
}

/**
 * Get next approver emails based on current stage
 */
function getNextApproverEmails(string $current_stage) {
    global $global_db_connection;
    
    try {
        $next_role = '';
        switch ($current_stage) {
            case 'checker':
                $next_role = 'approver';
                break;
            case 'approver':
                $next_role = 'noter';
                break;
            default:
                return [];
        }
        
        // Reuse connection if available
        if (!$global_db_connection) {
            $db = new Connection();
            $global_db_connection = $db->link;
        }
        
        $conn = $global_db_connection;
        
        $sql = "SELECT TOP 10 email FROM users WHERE role = ? AND is_active = 1 AND email IS NOT NULL AND email != ''";
        $params = [$next_role];
        $stmt = sqlsrv_query($conn, $sql, $params);
        
        if ($stmt === false) {
            error_log("Failed to fetch $next_role emails: " . print_r(sqlsrv_errors(), true));
            return [];
        }
        
        $emails = [];
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $email = trim($row['email']);
            if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emails[] = $email;
            }
        }
        
        return $emails;
        
    } catch (Exception $e) {
        error_log("Error fetching next approver emails: " . $e->getMessage());
        return [];
    }
}

/**
 * Get requestor email by form ID
 */
function getRequestorEmail(int $form_id) {
    try {
        $db = new Connection();
        $conn = $db->link;
        
        $sql = "SELECT u.email 
                FROM rts_forms rf 
                JOIN users u ON rf.requestor_id = u.user_id 
                WHERE rf.id = ?";
        
        $stmt = sqlsrv_query($conn, $sql, [$form_id]);
        
        if ($stmt === false) {
            error_log("Failed to fetch requestor email: " . print_r(sqlsrv_errors(), true));
            return [];
        }
        
        if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $email = trim($row['email']);
            return !empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL) ? [$email] : [];
        }
        
        return [];
        
    } catch (Exception $e) {
        error_log("Error fetching requestor email: " . $e->getMessage());
        return [];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }
}

/**
 * Get next step description for approval process
 */
function getNextApprovalStep(string $current_role) {
    switch ($current_role) {
        case 'checker':
            return 'For Approval';
        case 'approver':
            return 'For Noting';
        case 'noter':
            return 'Fully Approved';
        default:
            return 'In Process';
    }
}

/**
 * Get checker emails using optimized query
 */
function getCheckerEmailsForNotification() {
    try {
        $db = new Connection();
        $conn = $db->link;
        
        $sql = "SELECT DISTINCT TOP 20 email 
                FROM users 
                WHERE role = 'checker' 
                AND is_active = 1 
                AND email IS NOT NULL 
                AND email != ''
                ORDER BY email";
        
        $stmt = sqlsrv_query($conn, $sql);
        if ($stmt === false) {
            error_log("Failed to fetch checker emails: " . print_r(sqlsrv_errors(), true));
            return [];
        }
        
        $checker_emails = [];
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $email = trim($row['email']);
            if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $checker_emails[] = $email;
            }
        }
        
        return $checker_emails;
        
    } catch (Exception $e) {
        error_log("Error fetching checker emails: " . $e->getMessage());
        return [];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }
}

/**
 * Get approver emails by role
 */
function getApproverEmailsByRole(string $role) {
    try {
        $db = new Connection();
        $conn = $db->link;
        
        $sql = "SELECT DISTINCT TOP 10 email 
                FROM users 
                WHERE role = ? 
                AND is_active = 1 
                AND email IS NOT NULL 
                AND email != ''
                ORDER BY email";
        
        $stmt = sqlsrv_query($conn, $sql, [$role]);
        if ($stmt === false) {
            error_log("Failed to fetch $role emails: " . print_r(sqlsrv_errors(), true));
            return [];
        }
        
        $emails = [];
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $email = trim($row['email']);
            if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emails[] = $email;
            }
        }
        
        return $emails;
        
    } catch (Exception $e) {
        error_log("Error fetching $role emails: " . $e->getMessage());
        return [];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }
}

/**
 * Send notification to next stage approvers
 */
function sendNotificationToNextApprovers(string $control_no, string $current_role, string $requestor_name, string $date_submitted) {
    $next_approver_emails = getNextApproverEmails($current_role);
    
    if (!empty($next_approver_emails)) {
        $next_step_name = getNextApprovalStep($current_role);
        $status = "For " . ucfirst(str_replace('For ', '', $next_step_name));
        
        return sendApprovalRequestEmail(
            $next_approver_emails, 
            $control_no, 
            $requestor_name, 
            $date_submitted, 
            $status
        );
    }
    
    return false;
}

/**
 * Force close SMTP connection (use sparingly)
 */
function forceCloseSMTPConnection() {
    static $mail_instance = null;
    if ($mail_instance !== null) {
        try {
            $mail_instance->smtpClose();
        } catch (Exception $e) {
            // Ignore close errors
        }
        $mail_instance = null;
    }
}

// ===========================================
// LEGACY FUNCTION ALIASES FOR BACKWARD COMPATIBILITY
// ===========================================

/**
 * @deprecated Use sendUserDisapprovalNotificationEmail() instead
 */
function sendDisapprovalEmail($recipientEmails, $control_no, $requestor_name, $date_submitted, $reason, $disapproved_by_role, $disapproved_by_name) {
    return sendUserDisapprovalNotificationEmail($recipientEmails, $control_no, $requestor_name, $date_submitted, $reason, $disapproved_by_role, $disapproved_by_name);
}

/**
 * @deprecated Use sendUserFullyApprovedEmail() instead
 */
function sendFullyApprovedEmail($recipientEmails, $control_no, $requestor_name, $date_submitted) {
    return sendUserFullyApprovedEmail($recipientEmails, $control_no, $requestor_name, $date_submitted);
}

/**
 * @deprecated Use sendEmailFast() instead
 */
function sendEmail($recipientEmails, $subject, $body, $type, $control_no) {
    return sendEmailFast($recipientEmails, $subject, $body, $type, $control_no);
}

// Cleanup function for long-running scripts
register_shutdown_function('forceCloseSMTPConnection');
?>