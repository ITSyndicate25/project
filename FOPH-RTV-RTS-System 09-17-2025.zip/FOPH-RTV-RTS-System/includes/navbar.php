<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
    <style>
        .dropdown-menu {
            background-color: white;
            border: 1px solid rgba(0, 0, 0, 0.15);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .dropdown-item {
            color: #333;
        }
        .dropdown-item:hover {
            background-color: #f1f1f1;
        }
    </style>

    <div class="container-fluid">
        <div class="navbar-wrapper">
            <div class="navbar-toggle">
                <button type="button" class="navbar-toggler">
                    <span class="navbar-toggler-bar bar1"></span>
                    <span class="navbar-toggler-bar bar2"></span>
                    <span class="navbar-toggler-bar bar3"></span>
                </button>
            </div>
            <a class="navbar-brand" href="javascript:void(0);">Dashboard</a>
        </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form>
                <div class="input-group no-border">
                    <input type="text" id="searchInput" class="form-control" placeholder="Search...">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <i class="nc-icon nc-zoom-split"></i>
                        </div>
                    </div>
                </div>
            </form>
            <ul class="navbar-nav">
                <li class="nav-item btn-rotate dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="nc-icon nc-settings-gear-65"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                        <?php
                        // Check if the user is logged in
                        if (isset($_SESSION['user_role'])) {
                            $user_role = $_SESSION['user_role'];
                            $profile_url = '';

                            // Handle multiple roles by checking for specific roles in order of priority
                            if ($user_role === 'admin' || strpos($user_role, 'admin') !== false) {
                                $profile_url = BASE_URL . '/pages/admin/profile.php';
                            } elseif ($user_role === 'approver' || strpos($user_role, 'approver') !== false) {
                                $profile_url = BASE_URL . '/pages/approver/profile.php';
                            } else {
                                // Default to user profile if other roles are not found
                                $profile_url = BASE_URL . '/pages/user/profile.php';
                            }
                        } else {
                            // Default URL for guests or unauthenticated users
                            $profile_url = BASE_URL . '/pages/user/profile.php';
                        }
                        ?>
                        <a class="dropdown-item" href="<?php echo htmlspecialchars($profile_url); ?>">Profile</a>
                        <a class="dropdown-item" href="#" id="logoutLink">Logout</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>

<script>
    (function() {
        document.querySelectorAll('.navbar-toggler').forEach(button => {
            button.addEventListener('click', function() {
                this.classList.toggle('active');
            });
        });

        const logoutLink = document.getElementById('logoutLink');
        const searchInput = document.getElementById('searchInput');
        const sidebarNav = document.getElementById('sidebarNav');

        if (logoutLink) {
            logoutLink.addEventListener('click', function(e) {
                e.preventDefault();
                let timerInterval;
                const timerDuration = 5;

                Swal.fire({
                    title: 'You\'ll be logged out in ' + timerDuration + ' seconds',
                    html: 'You will be logged out automatically. <br/>You can cancel this action by clicking the cancel button.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Log Out Now',
                    cancelButtonText: 'Cancel',
                    timer: timerDuration * 1000,
                    timerProgressBar: true,
                    didOpen: () => {
                        const b = Swal.getHtmlContainer().querySelector('b');
                        timerInterval = setInterval(() => {
                            const timeLeft = Math.ceil(Swal.getTimerLeft() / 1000);
                            Swal.update({
                                title: `You'll be logged out in ${timeLeft} seconds`,
                            });
                        }, 1000);
                    },
                    willClose: () => {
                        clearInterval(timerInterval);
                    }
                }).then((result) => {
                    if (result.dismiss === Swal.DismissReason.timer || result.isConfirmed) {
                        window.location.href = "<?php echo BASE_URL; ?>/logout.php";
                    }
                });
            });
        }

        if (searchInput && sidebarNav) {
            const sidebarItems = sidebarNav.querySelectorAll('li');

            searchInput.addEventListener('input', function() {
                const searchText = this.value.toLowerCase();
                sidebarItems.forEach(item => {
                    const itemText = item.textContent.toLowerCase();
                    if (itemText.includes(searchText)) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        }
    })();
</script>