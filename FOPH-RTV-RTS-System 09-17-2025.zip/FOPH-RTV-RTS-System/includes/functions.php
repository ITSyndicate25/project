<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';

// Function to ensure the user is an admin; redirects if not.
function checkAdminAccess() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
        header('Location: ' . BASE_URL . '/login.php');
        exit();
    }
}

/**
 * Checks if a given page is active for sidebar highlighting.
 * @param string|array 
 * @return string 
 */
function isActive($pages) {
    // Get the current page filename without any query string
    $currentPage = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

    // Convert a single string to an array for consistent handling
    if (!is_array($pages)) {
        $pages = [$pages];
    }

    // Check if the current page is in the provided list of pages
    if (in_array($currentPage, $pages)) {
        return 'active';
    }

    return '';
}
// Scrapping rts form permission based on department and role
function checkScrapPermission($user_department, $user_role) {
    $allowed_departments = [
        'Engineering',
        'Logistics',
        'LX',
        'INSTAX',
        'PT',
        'LENS',
    ];
    
    // Admin can always access, or user must be in an allowed department
    return ($user_role === 'admin') || in_array($user_department, $allowed_departments);
}

// Function to get user department by user ID
function getUserDepartment($user_id) {
    try {
        $db = new Connection();
        $conn = $db->link;
        
        $sql = "SELECT department FROM users WHERE user_id = ?";
        $stmt = sqlsrv_prepare($conn, $sql, array(&$user_id));
        
        if ($stmt && sqlsrv_execute($stmt)) {
            if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                $db->close();
                return $row['department'];
            }
        }
        
        $db->close();
        return null;
    } catch (Exception $e) {
        error_log("Error getting user department: " . $e->getMessage());
        return null;
    }
}

/**
 * Adds a new user to the database, with an optional e-signature.
 * @param string 
 * @param string 
 * @param array|string 
 * @param string 
 * @param string 
 * @param string 
 * @param array|string 
 * @param array|null 
 * @return array
 */
function addUser($username, $password, $role, $requestor_name, $department, $id_number, $email, $category, $e_signature = null) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    // Sanitize and Validate Inputs (rest of this section remains the same as before)
    $username = trim($username);
    $requestor_name = trim($requestor_name);
    $department = trim($department);
    $id_number = trim($id_number);

    $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'Invalid email format.'];
    }

    $role = is_array($role) ? implode(',', $role) : trim($role);
    $category = is_array($category) ? implode(',', $category) : trim($category);
    
    if (empty($username) || empty($password) || empty($role) || empty($requestor_name) || empty($department) || empty($id_number) || empty($email) || empty($category)) {
        return ['success' => false, 'message' => 'All fields are required.'];
    }
    
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    if ($password_hash === false) {
        error_log("Failed to create password hash for user: $username");
        return ['success' => false, 'message' => 'An internal error occurred. Please try again.'];
    }

    $conn = new Connection();
    $connLink = $conn->link;

    // Check if username or email already exists
    $sqlCheck = "SELECT COUNT(*) AS count FROM users WHERE username = ? OR email = ?";
    $paramsCheck = array($username, $email);
    $stmtCheck = sqlsrv_prepare($connLink, $sqlCheck, $paramsCheck);

    if (!$stmtCheck || !sqlsrv_execute($stmtCheck)) {
        $errors = sqlsrv_errors();
        error_log("Database error during uniqueness check: " . print_r($errors, true));
        $conn->close();
        return ['success' => false, 'message' => 'Database error. Please try again later.'];
    }

    $row = sqlsrv_fetch_array($stmtCheck, SQLSRV_FETCH_ASSOC);
    if ($row && $row['count'] > 0) {
        $conn->close();
        return ['success' => false, 'message' => 'Username or Email already exists.'];
    }

    // Insert user into database (without signature first)
    $createdAt = date('Y-m-d H:i:s');
    $sqlInsert = "INSERT INTO users (username, password, requestor_name, department, id_number, email, category, role, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $paramsInsert = array($username, $password_hash, $requestor_name, $department, $id_number, $email, $category, $role, $createdAt);

    $stmtInsert = sqlsrv_prepare($connLink, $sqlInsert, $paramsInsert);
    if (!$stmtInsert || !sqlsrv_execute($stmtInsert)) {
        $errors = sqlsrv_errors();
        error_log("Failed to add user to database: " . print_r($errors, true));
        $conn->close();
        return ['success' => false, 'message' => 'Failed to add user due to a database error.'];
    }

    // Get the newly created user_id to link the signature
    $sqlGetId = "SELECT user_id FROM users WHERE username = ?";
    $stmtGetId = sqlsrv_query($connLink, $sqlGetId, [$username]);
    if ($stmtGetId === false) {
        $errors = sqlsrv_errors();
        error_log("Failed to get new user ID: " . print_r($errors, true));
        $conn->close();
        return ['success' => false, 'message' => 'User created, but failed to find ID to add signature.'];
    }
    $newUserId = sqlsrv_fetch_array($stmtGetId, SQLSRV_FETCH_ASSOC)['user_id'];


    // Handle image upload if a file was provided
    if ($e_signature && $e_signature['error'] === UPLOAD_ERR_OK) {
        $imageData = file_get_contents($e_signature['tmp_name']);
        if ($imageData !== false) {
            $updateQuery = "UPDATE users SET e_signiture = ? WHERE user_id = ?";
            
            // Corrected code: Use the older, more compatible constants
            $updateParams = array(
                array($imageData, SQLSRV_PARAM_IN, SQLSRV_PHPTYPE_STREAM(SQLSRV_ENC_BINARY), SQLSRV_SQLTYPE_IMAGE), // Use SQLSRV_SQLTYPE_IMAGE
                array($newUserId, SQLSRV_PARAM_IN)
            );
            
            $updateStmt = sqlsrv_prepare($connLink, $updateQuery, $updateParams);

            if (!$updateStmt || !sqlsrv_execute($updateStmt)) {
                $errors = sqlsrv_errors();
                error_log("❌ Failed to update e_signiture for user $newUserId: " . print_r($errors, true));
                // Do not return an error to the user for signature failure, as the user was already created successfully
            }
        }
    }

    $conn->close();
    return ['success' => true, 'message' => 'User added successfully.'];
}


/**
 * Fetches user data for DataTables server-side processing.
 * @param array 
 * @return array 
 */
function getUsersForDataTable($params) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    $db = new Connection();
    $connLink = $db->link;

    $draw = isset($params['draw']) ? intval($params['draw']) : 0;
    $start = isset($params['start']) ? intval($params['start']) : 0;
    $length = isset($params['length']) ? intval($params['length']) : 10;
    $search_value = isset($params['search']['value']) ? $params['search']['value'] : '';

    $order_column_index = isset($params['order'][0]['column']) ? intval($params['order'][0]['column']) : 0;
    $order_dir = isset($params['order'][0]['dir']) ? $params['order'][0]['dir'] : 'asc';
    // Add 'category' to the columns array to match the JavaScript
    $columns = ['user_id', 'username', 'requestor_name', 'email', 'role', 'department', 'category', 'created_at'];

    // Ensure the index is within the bounds of the new array
    if ($order_column_index >= count($columns)) {
        $order_column_index = 0; // Fallback to the first column
    }
    
    $order_by = $columns[$order_column_index];
    $order_by_sql = "ORDER BY " . $order_by . " " . strtoupper($order_dir);

    $where_clause = '';
    $query_params = [];
    if (!empty($search_value)) {
        // Add 'category' to the search criteria
        $where_clause = "WHERE username LIKE ? OR email LIKE ? OR requestor_name LIKE ? OR department LIKE ? OR category LIKE ?";
        $query_params[] = "%" . $search_value . "%";
        $query_params[] = "%" . $search_value . "%";
        $query_params[] = "%" . $search_value . "%";
        $query_params[] = "%" . $search_value . "%";
        $query_params[] = "%" . $search_value . "%";
    }

    // Get total count of all users
    $count_sql = "SELECT COUNT(*) FROM users";
    $count_result = sqlsrv_query($connLink, $count_sql);
    $total_records = sqlsrv_fetch_array($count_result)[0];

    // Get filtered count of users
    $filtered_count_sql = "SELECT COUNT(*) FROM users " . $where_clause;
    $filtered_count_result = sqlsrv_query($connLink, $filtered_count_sql, $query_params);
    $total_filtered_records = sqlsrv_fetch_array($filtered_count_result)[0];

    // Select users with filtering and ordering, including 'category'
    $sql = "SELECT user_id, username, requestor_name, email, role, department, category, created_at FROM users " . $where_clause . " " . $order_by_sql;

    if ($length != -1) {
        $sql .= " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
        $query_params[] = $start;
        $query_params[] = $length;
    }

    $result = sqlsrv_query($connLink, $sql, $query_params);
    if ($result === false) {
        $errors = sqlsrv_errors();
        $db->close();
        return ['error' => 'SQL Server query error: ' . print_r($errors, true)];
    }

    $users = [];
    while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
        $users[] = [
            'id' => $row['user_id'],
            'username' => $row['username'],
            'requestor_name' => $row['requestor_name'],
            'email' => $row['email'],
            'role' => $row['role'],
            'department' => $row['department'],
            // Add 'category' to the returned array
            'category' => $row['category'],
            'created_at' => ($row['created_at'] instanceof DateTime) ? $row['created_at']->format('Y-m-d H:i:s') : $row['created_at']
        ];
    }
    
    $db->close();

    return [
        'draw' => $draw,
        'recordsTotal' => $total_records,
        'recordsFiltered' => $total_filtered_records,
        'data' => $users
    ];
}

/**
 * Fetches a single user's data from the database.
 * @param int  
 * @return array 
 */
function getUserData($userId) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    if (empty($userId)) {
        return ['success' => false, 'message' => 'User ID is required.'];
    }

    $db = new Connection();
    $connLink = $db->link;

    try {
        $sql = "SELECT user_id, username, requestor_name, department, id_number, email, role, category, e_signiture FROM users WHERE user_id = ?";
        $params = [intval($userId)];
        $stmt = sqlsrv_query($connLink, $sql, $params);

        if ($stmt === false) {
            throw new Exception("SQL Server query error: " . print_r(sqlsrv_errors(), true));
        }

        if (sqlsrv_has_rows($stmt)) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

            // The data is already a string when fetched, so no need for stream_get_contents()
            $e_signature_data = null;
            if (isset($row['e_signiture']) && $row['e_signiture'] !== null) {
                // The data is already a binary string. Just assign it.
                $e_signature_data = $row['e_signiture'];
            }
            
            return [
                'success' => true,
                'data' => [
                    'id' => $row['user_id'],
                    'username' => $row['username'],
                    'requestor_name' => $row['requestor_name'],
                    'department' => $row['department'],
                    'id_number' => $row['id_number'],
                    'email' => $row['email'],
                    'role' => $row['role'],
                    'category' => $row['category'],
                    'e_signiture' => $e_signature_data, // Pass the binary string directly
                ]
            ];
        } else {
            return ['success' => false, 'message' => 'User not found.'];
        }

    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }
}


/**
 * Updates an existing user's information in the database.
 *
 * @param int 
 * @param string 
 * @param string 
 * @param string 
 * @param string  
 * @param string 
 * @param string  
 * @return array 
 */
function updateUser($user_id, $username, $requestor_name, $department, $param_email, $param_role, $param_category) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    // Basic validation
    if (empty($user_id) || empty($username) || empty($requestor_name) || empty($department) || empty($param_email) || empty($param_role)) {
        return ['success' => false, 'message' => 'All fields are required.'];
    }

    $db = new Connection();
    $connLink = $db->link;

    try {
        // Check if the email already exists for another user
        $email_check_sql = "SELECT user_id FROM users WHERE email = ? AND user_id != ?";
        $email_check_stmt = sqlsrv_query($connLink, $email_check_sql, [$param_email, $user_id]);
        $existing_user_with_email = sqlsrv_fetch_array($email_check_stmt, SQLSRV_FETCH_ASSOC);
        if ($existing_user_with_email) {
            $db->close();
            return ['success' => false, 'message' => 'This email is already in use by another user.'];
        }

        // SQL query to update the user
        $sql = "UPDATE users SET username = ?, requestor_name = ?, department = ?, email = ?, role = ?, category = ? WHERE user_id = ?";
        $params = [$username, $requestor_name, $department, $param_email, $param_role, $param_category, $user_id];
        $stmt = sqlsrv_query($connLink, $sql, $params);

        if ($stmt === false) {
            throw new Exception("SQL Server query error: " . print_r(sqlsrv_errors(), true));
        }

        $rows_affected = sqlsrv_rows_affected($stmt);
        if ($rows_affected > 0) {
            return ['success' => true, 'message' => 'User updated successfully.'];
        } else {
            return ['success' => false, 'message' => 'No changes were made or user not found.'];
        }

    } catch (Exception $e) {
        http_response_code(500);
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        $db->close();
    }
}

/**
 * Changes a user's password in the database.
 * @param int 
 * @param string 
 * @return array
 */
function changePassword($userIdToChange, $newPassword) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';
    
    // Check if the user ID or new password is empty
    if (empty($userIdToChange) || empty($newPassword)) {
        return ['success' => false, 'message' => 'User ID and new password are required.'];
    }

    $db = new Connection();
    $connLink = $db->link;
    
    try {
        // Hash the new password securely using the same method as addUser
        $hashed_password = password_hash($newPassword, PASSWORD_DEFAULT);
        if ($hashed_password === false) {
            return ['success' => false, 'message' => 'Failed to create password hash.'];
        }
        
        $sql = "UPDATE users SET password = ?, updated_at = GETDATE() WHERE user_id = ?";
        $params = [$hashed_password, intval($userIdToChange)];
        $stmt = sqlsrv_prepare($connLink, $sql, $params);
        
        if ($stmt && sqlsrv_execute($stmt)) {
            $rows_affected = sqlsrv_rows_affected($stmt);
            if ($rows_affected > 0) {
                return ['success' => true, 'message' => 'Password updated successfully.'];
            } else {
                return ['success' => false, 'message' => 'User not found or password is the same.'];
            }
        } else {
            $errors = sqlsrv_errors();
            $msg = 'Failed to change password.';
            if ($errors) {
                $msg .= " DB Error: " . print_r($errors, true);
            }
            return ['success' => false, 'message' => $msg];
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        $db->close();
    }
}

/**
 * Deletes a user from the database.
 * @param int 
 * @param int 
 * @return array 
 */
function deleteUser($userIdToDelete, $currentUserId) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    if (empty($userIdToDelete) || $userIdToDelete === null) {
        return ['success' => false, 'message' => 'User ID is required.'];
    }

    // Prevent a user from deleting their own account
    if ($currentUserId == $userIdToDelete) {
        return ['success' => false, 'message' => 'You cannot delete your own account.'];
    }

    $db = new Connection();
    $connLink = $db->link;

    try {
        $sql = "DELETE FROM users WHERE user_id = ?";
        $params = [intval($userIdToDelete)];
        $stmt = sqlsrv_query($connLink, $sql, $params);

        if ($stmt === false) {
            throw new Exception("SQL Server query error: " . print_r(sqlsrv_errors(), true));
        }

        $rows_affected = sqlsrv_rows_affected($stmt);
        if ($rows_affected > 0) {
            return ['success' => true, 'message' => 'User deleted successfully.'];
        } else {
            return ['success' => false, 'message' => 'User not found or already deleted.'];
        }

    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        $db->close();
    }
}

/**
 * Verifies if the provided password matches the one stored for the given user ID.
 * @param int $userId 
 * @param string $password 
 * @return array 
 */
function verifyAdminPassword($userId, $password) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    if (empty($password)) {
        return ['success' => false, 'message' => 'Password is required.'];
    }

    $db = new Connection();
    $connLink = $db->link;

    try {
        $sql = "SELECT password FROM users WHERE user_id = ?";
        $params = [$userId];
        $stmt = sqlsrv_query($connLink, $sql, $params);

        if ($stmt === false) {
            throw new Exception("SQL Server query error: " . print_r(sqlsrv_errors(), true));
        }

        $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

        if ($row && password_verify($password, $row['password'])) {
            return ['success' => true, 'message' => 'Password verified successfully.'];
        } else {
            return ['success' => false, 'message' => 'Incorrect password.'];
        }

    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        $db->close();
    }
}

/**
 * Function to get all dashboard data for admin
 * @return array 
 */
function getDashboardData() {
    $data = [
        // User statistics
        'total_users' => 0,
        'user_roles' => [],
        'active_users' => 0,
        'recent_users' => [],
        
        // Form statistics
        'total_rts' => 0,
        'total_ng' => 0,
        'total_coil_solder' => 0,
        'total_all_forms' => 0,
        
        // System-wide status counts
        'system_pending' => 0,
        'system_ongoing' => 0,
        'system_completed' => 0,
        'system_disapproved' => 0,
        
        // Time-based statistics
        'today_requests' => 0,
        'month_requests' => 0,
        'monthly_trend' => ['labels' => [], 'rts' => [], 'ng' => [], 'coil_solder' => []],
        
        // Other data
        'admin_name' => 'Admin', // Will be replaced with requestor_name
        'today' => date('F j, Y'),
        'total_locations' => 0,
        'recent_requests' => []
    ];

    try {
        $db = new Connection();
        $conn = $db->link;

        // First, clean up old sessions
        $cleanup_sql = "DELETE FROM active_sessions WHERE last_activity < DATEADD(minute, -30, GETDATE())";
        sqlsrv_query($conn, $cleanup_sql);

        // Get total users
        $sql_total_users = "SELECT COUNT(*) AS total FROM users";
        $stmt_total_users = sqlsrv_query($conn, $sql_total_users);
        if ($stmt_total_users && sqlsrv_fetch($stmt_total_users)) {
            $data['total_users'] = sqlsrv_get_field($stmt_total_users, 0);
        }

        // Get active users (from active sessions within last 30 minutes)
        $sql_active = "SELECT COUNT(DISTINCT user_id) AS total FROM active_sessions WHERE last_activity >= DATEADD(minute, -30, GETDATE())";
        $stmt_active = sqlsrv_query($conn, $sql_active);
        if ($stmt_active && sqlsrv_fetch($stmt_active)) {
            $data['active_users'] = sqlsrv_get_field($stmt_active, 0);
        } else {
            $data['active_users'] = 0;
        }

        // Get user roles distribution
        $sql_roles = "SELECT role FROM users";
        $stmt_roles = sqlsrv_query($conn, $sql_roles);
        $role_counts = [];
        if ($stmt_roles) {
            while ($row = sqlsrv_fetch_array($stmt_roles, SQLSRV_FETCH_ASSOC)) {
                $roles = explode(',', $row['role']);
                foreach ($roles as $role) {
                    $role = trim($role);
                    if (!empty($role)) {
                        $role_counts[$role] = ($role_counts[$role] ?? 0) + 1;
                    }
                }
            }
            $data['user_roles'] = $role_counts;
        }

        // Check if workflow_status column exists, if not use material_status
        $check_column_sql = "
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME = 'rts_forms' AND COLUMN_NAME = 'workflow_status'
        ";
        $check_stmt = sqlsrv_query($conn, $check_column_sql);
        $has_workflow_status = sqlsrv_has_rows($check_stmt);
        
        $status_column = $has_workflow_status ? 'workflow_status' : 'material_status';

        // Get form counts and status distribution for RTS using appropriate status column
        $sql_rts_stats = "
            SELECT 
                COUNT(*) AS total,
                SUM(CASE WHEN $status_column = 'Pending' THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN $status_column = 'In-Progress' THEN 1 ELSE 0 END) AS ongoing,
                SUM(CASE WHEN $status_column = 'Completed' THEN 1 ELSE 0 END) AS completed,
                SUM(CASE WHEN $status_column IN ('Disapproved', 'Canceled') THEN 1 ELSE 0 END) AS disapproved,
                SUM(CASE WHEN CAST(created_at AS DATE) = CAST(GETDATE() AS DATE) THEN 1 ELSE 0 END) AS today,
                SUM(CASE WHEN MONTH(created_at) = MONTH(GETDATE()) AND YEAR(created_at) = YEAR(GETDATE()) THEN 1 ELSE 0 END) AS this_month
            FROM rts_forms";
        
        $stmt_rts = sqlsrv_query($conn, $sql_rts_stats);
        if ($stmt_rts && $row = sqlsrv_fetch_array($stmt_rts, SQLSRV_FETCH_ASSOC)) {
            $data['total_rts'] = $row['total'] ?? 0;
            $data['system_pending'] = $row['pending'] ?? 0;
            $data['system_ongoing'] = $row['ongoing'] ?? 0;
            $data['system_completed'] = $row['completed'] ?? 0;
            $data['system_disapproved'] = $row['disapproved'] ?? 0;
            $data['today_requests'] = $row['today'] ?? 0;
            $data['month_requests'] = $row['this_month'] ?? 0;
        }

        // Since you don't have NG and Coil/Solder forms yet, we'll set these to 0
        $data['total_ng'] = 0;
        $data['total_coil_solder'] = 0;

        // Calculate total forms
        $data['total_all_forms'] = $data['total_rts'] + $data['total_ng'] + $data['total_coil_solder'];

        // Get total locations
        $sql_locations = "SELECT COUNT(*) AS total FROM sap_loc_code";
        $stmt_locations = sqlsrv_query($conn, $sql_locations);
        if ($stmt_locations && sqlsrv_fetch($stmt_locations)) {
            $data['total_locations'] = sqlsrv_get_field($stmt_locations, 0);
        }

        // Get recent users (last 5)
        $sql_recent_users = "
            SELECT TOP 5 username, requestor_name, role, created_at 
            FROM users 
            ORDER BY created_at DESC";
        $stmt_recent_users = sqlsrv_query($conn, $sql_recent_users);
        if ($stmt_recent_users) {
            while ($row = sqlsrv_fetch_array($stmt_recent_users, SQLSRV_FETCH_ASSOC)) {
                if ($row['created_at'] instanceof DateTime) {
                    $row['created_at'] = $row['created_at']->format('Y-m-d H:i');
                }
                $data['recent_users'][] = $row;
            }
        }

        // Get recent requests (last 5 from RTS forms only for now) using appropriate status column
        $sql_recent_requests = "
            SELECT TOP 5 
                rf.control_no,
                'RTS Form' as form_type,
                $status_column as workflow_status,
                rf.material_status,
                u.requestor_name as submitted_by
            FROM rts_forms rf
            LEFT JOIN users u ON rf.requestor_id = u.user_id
            ORDER BY rf.created_at DESC";
        
        $stmt_recent_requests = sqlsrv_query($conn, $sql_recent_requests);
        if ($stmt_recent_requests) {
            while ($row = sqlsrv_fetch_array($stmt_recent_requests, SQLSRV_FETCH_ASSOC)) {
                $data['recent_requests'][] = $row;
            }
        }

        // Get monthly trend data (last 6 months)
        for ($i = 5; $i >= 0; $i--) {
            $month = date('F', strtotime("-$i months"));
            $month_num = date('n', strtotime("-$i months"));
            $year = date('Y', strtotime("-$i months"));
            
            $data['monthly_trend']['labels'][] = $month;
            
            // Get RTS count for this month
            $sql_month_rts = "
                SELECT COUNT(*) as count 
                FROM rts_forms 
                WHERE MONTH(created_at) = ? AND YEAR(created_at) = ?";
            $stmt_month_rts = sqlsrv_query($conn, $sql_month_rts, [$month_num, $year]);
            if ($stmt_month_rts && sqlsrv_fetch($stmt_month_rts)) {
                $data['monthly_trend']['rts'][] = sqlsrv_get_field($stmt_month_rts, 0);
            } else {
                $data['monthly_trend']['rts'][] = 0;
            }
            
            // Set NG and Coil/Solder to 0 since you don't have data
            $data['monthly_trend']['ng'][] = 0;
            $data['monthly_trend']['coil_solder'][] = 0;
        }

        // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        // FETCH REQUESTOR NAME FOR ADMIN (CURRENT USER)
        // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (isset($_SESSION['user_id'])) {
            $sql_admin = "SELECT requestor_name FROM users WHERE user_id = ?";
            $stmt_admin = sqlsrv_query($conn, $sql_admin, [$_SESSION['user_id']]);
            if ($stmt_admin && sqlsrv_fetch($stmt_admin)) {
                $data['admin_name'] = sqlsrv_get_field($stmt_admin, 0) ?: 'Admin';
            }
        }

        $db->close();
    } catch (Exception $e) {
        error_log("Database connection error in getDashboardData: " . $e->getMessage());
    }

    return $data;
}

/**
 * Function to get dashboard data for a specific user.
 * @param int $user_id
 * @return array
 */
function getUserDashboardData($user_id) {
    $data = [
        // Individual form counts
        'total_rts' => 0,
        'total_ng' => 0,
        'total_coil_solder' => 0,
        'total_all_forms' => 0,
        
        // Status counts across all forms
        'pending_all' => 0,
        'ongoing_all' => 0,
        'completed_all' => 0,
        'disapproved_all' => 0,
        
        // Breakdown by form type and status
        'pending_rts' => 0,
        'pending_ng' => 0,
        'pending_coil_solder' => 0,
        
        'ongoing_rts' => 0,
        'ongoing_ng' => 0,
        'ongoing_coil_solder' => 0,
        
        'completed_rts' => 0,
        'completed_ng' => 0,
        'completed_coil_solder' => 0,
        
        'disapproved_rts' => 0,
        'disapproved_ng' => 0,
        'disapproved_coil_solder' => 0,
        
        // New fields for additional stats
        'today_requests' => 0,
        'month_requests' => 0,
        
        'today' => date('F j, Y'),
        'requestor_name' => 'User' // Will be replaced below
    ];

    try {
        $db = new Connection();
        $conn = $db->link;

        // Get current date info
        $today = date('Y-m-d');
        $current_month = date('m');
        $current_year = date('Y');

        // First check if workflow_status column exists, if not, use material_status
        $check_column_sql = "
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME = 'rts_forms' AND COLUMN_NAME = 'workflow_status'
        ";
        $check_stmt = sqlsrv_query($conn, $check_column_sql);
        $has_workflow_status = sqlsrv_has_rows($check_stmt);
        
        $status_column = $has_workflow_status ? 'workflow_status' : 'material_status';

        // Get counts for RTS forms using appropriate status column
        $sql_rts = "
            SELECT 
                COUNT(*) AS total,
                SUM(CASE WHEN $status_column = 'Pending' THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN $status_column = 'In-Progress' THEN 1 ELSE 0 END) AS ongoing,
                SUM(CASE WHEN $status_column = 'Completed' THEN 1 ELSE 0 END) AS completed,
                SUM(CASE WHEN $status_column IN ('Disapproved', 'Canceled') THEN 1 ELSE 0 END) AS disapproved,
                SUM(CASE WHEN CAST(created_at AS DATE) = ? THEN 1 ELSE 0 END) AS today_count,
                SUM(CASE WHEN MONTH(created_at) = ? AND YEAR(created_at) = ? THEN 1 ELSE 0 END) AS month_count
            FROM rts_forms 
            WHERE requestor_id = ?";
        
        $stmt_rts = sqlsrv_query($conn, $sql_rts, [$today, $current_month, $current_year, $user_id]);
        if ($stmt_rts && $row = sqlsrv_fetch_array($stmt_rts, SQLSRV_FETCH_ASSOC)) {
            $data['total_rts'] = $row['total'] ?? 0;
            $data['pending_rts'] = $row['pending'] ?? 0;
            $data['ongoing_rts'] = $row['ongoing'] ?? 0;
            $data['completed_rts'] = $row['completed'] ?? 0;
            $data['disapproved_rts'] = $row['disapproved'] ?? 0;
            $data['today_requests'] += $row['today_count'] ?? 0;
            $data['month_requests'] += $row['month_count'] ?? 0;
        }

        // For NG and Coil/Solder forms, check if tables exist
        $tables_to_check = [
            'ng_forms' => ['ng', 'total_ng', 'pending_ng', 'ongoing_ng', 'completed_ng', 'disapproved_ng'],
            'coil_solder_forms' => ['coil_solder', 'total_coil_solder', 'pending_coil_solder', 'ongoing_coil_solder', 'completed_coil_solder', 'disapproved_coil_solder']
        ];

        foreach ($tables_to_check as $table_name => $field_names) {
            $check_table_query = "SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = ?";
            $check_table_stmt = sqlsrv_query($conn, $check_table_query, [$table_name]);
            
            if ($check_table_stmt && sqlsrv_has_rows($check_table_stmt)) {
                // Check if this table has workflow_status column
                $check_column_sql = "
                    SELECT COLUMN_NAME 
                    FROM INFORMATION_SCHEMA.COLUMNS 
                    WHERE TABLE_NAME = ? AND COLUMN_NAME = 'workflow_status'
                ";
                $check_column_stmt = sqlsrv_query($conn, $check_column_sql, [$table_name]);
                $table_has_workflow_status = sqlsrv_has_rows($check_column_stmt);
                
                $table_status_column = $table_has_workflow_status ? 'workflow_status' : 'material_status';
                
                $sql_form = "
                    SELECT 
                        COUNT(*) AS total,
                        SUM(CASE WHEN $table_status_column = 'Pending' THEN 1 ELSE 0 END) AS pending,
                        SUM(CASE WHEN $table_status_column = 'In-Progress' THEN 1 ELSE 0 END) AS ongoing,
                        SUM(CASE WHEN $table_status_column = 'Completed' THEN 1 ELSE 0 END) AS completed,
                        SUM(CASE WHEN $table_status_column IN ('Disapproved', 'Canceled') THEN 1 ELSE 0 END) AS disapproved,
                        SUM(CASE WHEN CAST(created_at AS DATE) = ? THEN 1 ELSE 0 END) AS today_count,
                        SUM(CASE WHEN MONTH(created_at) = ? AND YEAR(created_at) = ? THEN 1 ELSE 0 END) AS month_count
                    FROM $table_name 
                    WHERE requestor_id = ?";
                
                $stmt_form = sqlsrv_query($conn, $sql_form, [$today, $current_month, $current_year, $user_id]);
                if ($stmt_form && $row = sqlsrv_fetch_array($stmt_form, SQLSRV_FETCH_ASSOC)) {
                    $data[$field_names[1]] = $row['total'] ?? 0;
                    $data[$field_names[2]] = $row['pending'] ?? 0;
                    $data[$field_names[3]] = $row['ongoing'] ?? 0;
                    $data[$field_names[4]] = $row['completed'] ?? 0;
                    $data[$field_names[5]] = $row['disapproved'] ?? 0;
                    $data['today_requests'] += $row['today_count'] ?? 0;
                    $data['month_requests'] += $row['month_count'] ?? 0;
                }
            }
        }

        // Calculate totals across all forms
        $data['total_all_forms'] = $data['total_rts'] + $data['total_ng'] + $data['total_coil_solder'];
        $data['pending_all'] = $data['pending_rts'] + $data['pending_ng'] + $data['pending_coil_solder'];
        $data['ongoing_all'] = $data['ongoing_rts'] + $data['ongoing_ng'] + $data['ongoing_coil_solder'];
        $data['completed_all'] = $data['completed_rts'] + $data['completed_ng'] + $data['completed_coil_solder'];
        $data['disapproved_all'] = $data['disapproved_rts'] + $data['disapproved_ng'] + $data['disapproved_coil_solder'];

        // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        // FETCH REQUESTOR NAME FROM USERS TABLE
        // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        $sql_user = "SELECT requestor_name FROM users WHERE user_id = ?";
        $stmt_user = sqlsrv_query($conn, $sql_user, [$user_id]);
        if ($stmt_user && sqlsrv_fetch($stmt_user)) {
            $data['requestor_name'] = sqlsrv_get_field($stmt_user, 0) ?: 'User';
        } else {
            $data['requestor_name'] = 'User'; // fallback if not found
        }

        $db->close();
    } catch (Exception $e) {
        error_log("Database connection error in getUserDashboardData: " . $e->getMessage());
    }

    return $data;
}

/**
 * Function to get dashboard data for approvers (checker, approver, noter).
 * @param int $user_id
 * @param array $user_roles
 * @return array
 */
function getApproverDashboardData($user_id, $user_roles) {
    $data = [
        // Pending counts
        'pending_checking' => 0,
        'pending_approval' => 0,
        'pending_noting' => 0,
        
        // Monthly statistics
        'total_processed' => 0,
        'total_disapproved' => 0,
        'monthly_checked' => 0,
        'monthly_approved' => 0,
        'monthly_noted' => 0,
        'today_actions' => 0,
        'avg_processing_time' => '0',
        
        // Form type distribution
        'form_types' => [
            'rts' => 0,
            'ng' => 0,
            'coil_solder' => 0
        ],
        
        // Monthly trend data
        'monthly_trend' => [
            'labels' => [],
            'checked' => [],
            'approved' => [],
            'noted' => []
        ],
        
        // Basic info
        'today' => date('F j, Y'),
        'username' => $_SESSION['username'] ?? 'User',
        'requestor_name' => 'User' // Default fallback
    ];

    try {
        $db = new Connection();
        $conn = $db->link;

        // Get current month for monthly stats
        $current_month = date('m');
        $current_year = date('Y');
        $today = date('Y-m-d');

        // Debug: Log user roles
        error_log("User roles in getApproverDashboardData: " . implode(', ', $user_roles));

        // If user is a checker - count pending for checking (using workflow_status)
        if (in_array('checker', $user_roles)) {
            $sql_pending_check = "SELECT COUNT(*) as count FROM rts_forms 
                                 WHERE checked_status = 'Pending' 
                                 AND workflow_status NOT IN ('Completed', 'Disapproved', 'Canceled')";
            $stmt = sqlsrv_query($conn, $sql_pending_check);
            if ($stmt) {
                $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
                $data['pending_checking'] = $row['count'] ?? 0;
            }
            
            // Get monthly checked count
            $sql_monthly_checked = "SELECT COUNT(*) as count FROM rts_forms 
                                   WHERE checked_by_id = ? 
                                   AND MONTH(checked_at) = ? 
                                   AND YEAR(checked_at) = ?";
            $stmt = sqlsrv_query($conn, $sql_monthly_checked, [$user_id, $current_month, $current_year]);
            if ($stmt) {
                $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
                $data['monthly_checked'] = $row['count'] ?? 0;
            }
        }

        // If user is an approver - count pending for approval (using workflow_status)
        if (in_array('approver', $user_roles)) {
            $sql_pending_approve = "SELECT COUNT(*) as count FROM rts_forms 
                                   WHERE approved_status = 'Pending' 
                                   AND checked_status = 'Approved' 
                                   AND workflow_status NOT IN ('Completed', 'Disapproved', 'Canceled')";
            $stmt = sqlsrv_query($conn, $sql_pending_approve);
            if ($stmt) {
                $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
                $data['pending_approval'] = $row['count'] ?? 0;
            }
            
            // Get monthly approved count
            $sql_monthly_approved = "SELECT COUNT(*) as count FROM rts_forms 
                                    WHERE approved_by_id = ? 
                                    AND MONTH(approved_at) = ? 
                                    AND YEAR(approved_at) = ?";
            $stmt = sqlsrv_query($conn, $sql_monthly_approved, [$user_id, $current_month, $current_year]);
            if ($stmt) {
                $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
                $data['monthly_approved'] = $row['count'] ?? 0;
            }
        }

        // If user is a noter - count pending for noting (using workflow_status)
        if (in_array('noter', $user_roles)) {
            $sql_pending_note = "SELECT COUNT(*) as count FROM rts_forms 
                                WHERE noted_status = 'Pending' 
                                AND approved_status = 'Approved' 
                                AND workflow_status NOT IN ('Completed', 'Disapproved', 'Canceled')";
            $stmt = sqlsrv_query($conn, $sql_pending_note);
            if ($stmt) {
                $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
                $data['pending_noting'] = $row['count'] ?? 0;
            }
            
            // Get monthly noted count
            $sql_monthly_noted = "SELECT COUNT(*) as count FROM rts_forms 
                                 WHERE noted_by_id = ? 
                                 AND MONTH(noted_at) = ? 
                                 AND YEAR(noted_at) = ?";
            $stmt = sqlsrv_query($conn, $sql_monthly_noted, [$user_id, $current_month, $current_year]);
            if ($stmt) {
                $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
                $data['monthly_noted'] = $row['count'] ?? 0;
            }
        }

        // Get total processed this month (where user took action)
        $sql_processed = "
            SELECT COUNT(DISTINCT id) as count FROM rts_forms 
            WHERE (
                (checked_by_id = ? AND MONTH(checked_at) = ? AND YEAR(checked_at) = ?) OR
                (approved_by_id = ? AND MONTH(approved_at) = ? AND YEAR(approved_at) = ?) OR
                (noted_by_id = ? AND MONTH(noted_at) = ? AND YEAR(noted_at) = ?)
            )";
        
        $params_processed = [
            $user_id, $current_month, $current_year,
            $user_id, $current_month, $current_year,
            $user_id, $current_month, $current_year
        ];
        
        $stmt = sqlsrv_query($conn, $sql_processed, $params_processed);
        if ($stmt) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $data['total_processed'] = $row['count'] ?? 0;
        }

        // Get today's actions
        $sql_today = "
            SELECT COUNT(DISTINCT id) as count FROM rts_forms 
            WHERE (
                (checked_by_id = ? AND CAST(checked_at AS DATE) = ?) OR
                (approved_by_id = ? AND CAST(approved_at AS DATE) = ?) OR
                (noted_by_id = ? AND CAST(noted_at AS DATE) = ?)
            )";
        
        $params_today = [$user_id, $today, $user_id, $today, $user_id, $today];
        
        $stmt = sqlsrv_query($conn, $sql_today, $params_today);
        if ($stmt) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $data['today_actions'] = $row['count'] ?? 0;
        }

        // Get total disapproved this month by this user (using workflow_status)
        $sql_disapproved = "
            SELECT COUNT(*) as count FROM rts_forms 
            WHERE workflow_status = 'Disapproved' 
            AND MONTH(created_at) = ? 
            AND YEAR(created_at) = ?
            AND (
                (disapproved_by_role = 'checker' AND checked_by_id = ?) OR
                (disapproved_by_role = 'approver' AND approved_by_id = ?) OR
                (disapproved_by_role = 'noter' AND noted_by_id = ?)
            )";
        
        $params_disapproved = [$current_month, $current_year, $user_id, $user_id, $user_id];
        
        $stmt = sqlsrv_query($conn, $sql_disapproved, $params_disapproved);
        if ($stmt) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $data['total_disapproved'] = $row['count'] ?? 0;
        }

        // Get average processing time (in hours) using workflow_status
        $sql_avg_time = "
            SELECT AVG(DATEDIFF(hour, created_at, 
                CASE 
                    WHEN workflow_status = 'Completed' THEN 
                        CASE 
                            WHEN noted_at IS NOT NULL THEN noted_at
                            WHEN approved_at IS NOT NULL THEN approved_at
                            WHEN checked_at IS NOT NULL THEN checked_at
                            ELSE created_at
                        END
                    ELSE GETDATE()
                END
            )) as avg_hours
            FROM rts_forms
            WHERE (checked_by_id = ? OR approved_by_id = ? OR noted_by_id = ?)
            AND workflow_status = 'Completed'";
        
        $stmt = sqlsrv_query($conn, $sql_avg_time, [$user_id, $user_id, $user_id]);
        if ($stmt) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $avg_hours = $row['avg_hours'] ?? 0;
            $data['avg_processing_time'] = round($avg_hours, 1) . 'h';
        }

        // Get form types distribution for processed forms
        $sql_form_types = "
            SELECT COUNT(*) as rts_count
            FROM rts_forms
            WHERE (checked_by_id = ? OR approved_by_id = ? OR noted_by_id = ?)";
        
        $stmt = sqlsrv_query($conn, $sql_form_types, [$user_id, $user_id, $user_id]);
        if ($stmt) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $data['form_types']['rts'] = $row['rts_count'] ?? 0;
        }
        
        // Since NG and Coil/Solder forms don't exist yet
        $data['form_types']['ng'] = 0;
        $data['form_types']['coil_solder'] = 0;

        // Get monthly trend data (last 6 months)
        for ($i = 5; $i >= 0; $i--) {
            $month = date('F', strtotime("-$i months"));
            $month_num = date('n', strtotime("-$i months"));
            $year = date('Y', strtotime("-$i months"));
            
            $data['monthly_trend']['labels'][] = $month;
            
            // Get counts for each role
            if (in_array('checker', $user_roles)) {
                $sql_trend = "SELECT COUNT(*) as count FROM rts_forms 
                             WHERE checked_by_id = ? 
                             AND MONTH(checked_at) = ? 
                             AND YEAR(checked_at) = ?";
                $stmt = sqlsrv_query($conn, $sql_trend, [$user_id, $month_num, $year]);
                if ($stmt && sqlsrv_fetch($stmt)) {
                    $data['monthly_trend']['checked'][] = sqlsrv_get_field($stmt, 0);
                } else {
                    $data['monthly_trend']['checked'][] = 0;
                }
            } else {
                $data['monthly_trend']['checked'][] = 0;
            }
            
            if (in_array('approver', $user_roles)) {
                $sql_trend = "SELECT COUNT(*) as count FROM rts_forms 
                             WHERE approved_by_id = ? 
                             AND MONTH(approved_at) = ? 
                             AND YEAR(approved_at) = ?";
                $stmt = sqlsrv_query($conn, $sql_trend, [$user_id, $month_num, $year]);
                if ($stmt && sqlsrv_fetch($stmt)) {
                    $data['monthly_trend']['approved'][] = sqlsrv_get_field($stmt, 0);
                } else {
                    $data['monthly_trend']['approved'][] = 0;
                }
            } else {
                $data['monthly_trend']['approved'][] = 0;
            }
            
            if (in_array('noter', $user_roles)) {
                $sql_trend = "SELECT COUNT(*) as count FROM rts_forms 
                             WHERE noted_by_id = ? 
                             AND MONTH(noted_at) = ? 
                             AND YEAR(noted_at) = ?";
                $stmt = sqlsrv_query($conn, $sql_trend, [$user_id, $month_num, $year]);
                if ($stmt && sqlsrv_fetch($stmt)) {
                    $data['monthly_trend']['noted'][] = sqlsrv_get_field($stmt, 0);
                } else {
                    $data['monthly_trend']['noted'][] = 0;
                }
            } else {
                $data['monthly_trend']['noted'][] = 0;
            }
        }

        // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        // FETCH REQUESTOR NAME FROM USERS TABLE
        // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        $sql_user = "SELECT requestor_name FROM users WHERE user_id = ?";
        $stmt_user = sqlsrv_query($conn, $sql_user, [$user_id]);
        if ($stmt_user && sqlsrv_fetch($stmt_user)) {
            $data['requestor_name'] = sqlsrv_get_field($stmt_user, 0) ?: 'User';
        } else {
            $data['requestor_name'] = 'User'; // fallback if not found
        }

        // Debug: Log all counts
        error_log("Approver Dashboard data: " . json_encode($data));

        $db->close();
    } catch (Exception $e) {
        error_log("Database connection error in getApproverDashboardData: " . $e->getMessage());
    }

    return $data;
}
    

// Function to generate a new RTS Control Number
function generateRTSNumber() {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    $db = new Connection();
    $conn = $db->link;

    try {
        // Start a transaction to prevent race conditions
        sqlsrv_begin_transaction($conn);

        // Define current date components
        $currentYear = date('Y');
        $currentMonth = date('m');

        // Check if a sequence record exists for the current month and year
        $sql_select = "SELECT current_sequence FROM dbo.rts_sequence WITH (UPDLOCK) WHERE current_year = ? AND current_month = ?";
        $params_select = [$currentYear, $currentMonth];
        $stmt_select = sqlsrv_query($conn, $sql_select, $params_select);

        if ($stmt_select === false) {
            throw new Exception("Failed to query sequence record: " . print_r(sqlsrv_errors(), true));
        }

        $row = sqlsrv_fetch_array($stmt_select, SQLSRV_FETCH_ASSOC);

        if (!$row) {
            // No record found for the current month/year, so insert a new one
            $sequenceNumber = 1;
            $sql_insert = "INSERT INTO dbo.rts_sequence (current_year, current_month, current_sequence) VALUES (?, ?, ?)";
            $params_insert = [$currentYear, $currentMonth, $sequenceNumber];
            $stmt_insert = sqlsrv_query($conn, $sql_insert, $params_insert);
            if ($stmt_insert === false) {
                throw new Exception("Failed to insert new sequence record: " . print_r(sqlsrv_errors(), true));
            }
        } else {
            // Record exists, so just increment the sequence number
            $sequenceNumber = (int)$row['current_sequence'] + 1;
            $sql_update = "UPDATE dbo.rts_sequence SET current_sequence = ? WHERE current_year = ? AND current_month = ?";
            $params_update = [$sequenceNumber, $currentYear, $currentMonth];
            $stmt_update = sqlsrv_query($conn, $sql_update, $params_update);
            if ($stmt_update === false) {
                throw new Exception("Failed to update sequence: " . print_r(sqlsrv_errors(), true));
            }
        }

        // Commit the transaction to save changes
        sqlsrv_commit($conn);

        // Format and return the new control number
        $formattedSeq = str_pad($sequenceNumber, 4, '0', STR_PAD_LEFT);
        $controlNumber = "RTS-{$currentYear}-{$currentMonth}-{$formattedSeq}";

        return $controlNumber;

    } catch (Exception $e) {
        // Rollback on error
        sqlsrv_rollback($conn);
        error_log("Error in generateRTSNumber: " . $e->getMessage());
        return false;
    } finally {
        $db->close();
    }
}

// Function to fetch SAP Location Codes for DataTables
function getSapLocCodes($params) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    $db = new Connection();
    $connLink = $db->link;

    // Get DataTables parameters
    $draw = isset($params['draw']) ? intval($params['draw']) : 0;
    $start = isset($params['start']) ? intval($params['start']) : 0;
    $length = isset($params['length']) ? intval($params['length']) : 10;
    $search_value = isset($params['search']['value']) ? $params['search']['value'] : '';

    // Define columns that can be ordered by - ADD 'Department'
    $columns = ['LocationCode', 'LocationCode', 'LocationDescription', 'Department'];

    $order_column_index = isset($params['order'][0]['column']) ? intval($params['order'][0]['column']) : 0;
    $order_dir = isset($params['order'][0]['dir']) && in_array(strtolower($params['order'][0]['dir']), ['asc', 'desc']) ? $params['order'][0]['dir'] : 'asc';
    
    // Default to ordering by the first data column if the counter column is selected
    if ($order_column_index === 0) {
        $order_by = 'LocationCode';
    } else {
        $order_by = $columns[$order_column_index];
    }
    
    $order_by_sql = "ORDER BY " . $order_by . " " . strtoupper($order_dir);

    // Build the WHERE clause for searching - ADD Department to search fields
    $where_clause = '';
    $query_params = [];
    if (!empty($search_value)) {
        $where_clause = "WHERE LocationCode LIKE ? OR LocationDescription LIKE ? OR Department LIKE ?";
        $query_params[] = "%{$search_value}%";
        $query_params[] = "%{$search_value}%";
        $query_params[] = "%{$search_value}%";
    }

    // Get total count of all records
    $count_sql = "SELECT COUNT(*) AS total FROM sap_loc_code";
    $count_stmt = sqlsrv_query($connLink, $count_sql);
    $total_records = 0;
    if ($count_stmt !== false) {
        $row = sqlsrv_fetch_array($count_stmt, SQLSRV_FETCH_ASSOC);
        $total_records = $row['total'] ?? 0;
    }

    // Get filtered count of records
    $filtered_count_sql = "SELECT COUNT(*) AS total FROM sap_loc_code " . $where_clause;
    $filtered_stmt = sqlsrv_query($connLink, $filtered_count_sql, $query_params);
    $total_filtered_records = 0;
    if ($filtered_stmt !== false) {
        $row = sqlsrv_fetch_array($filtered_stmt, SQLSRV_FETCH_ASSOC);
        $total_filtered_records = $row['total'] ?? 0;
    }

    // Select the necessary columns from the database with pagination - ADD 'Department'
    $sql = "SELECT LocationCode, LocationDescription, Department FROM sap_loc_code " . $where_clause . " " . $order_by_sql;

    if ($length != -1) {
        $sql .= " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
        $query_params[] = $start;
        $query_params[] = $length;
    }

    $stmt = sqlsrv_query($connLink, $sql, $query_params);
    if ($stmt === false) {
        $errors = sqlsrv_errors();
        $db->close();
        return ['status' => 'error', 'message' => 'SQL Server query error: ' . print_r($errors, true)];
    }

    $data = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $data[] = [
            'id' => $row['LocationCode'],
            'location_code' => $row['LocationCode'],
            'location_name' => $row['LocationDescription'],
            'department' => $row['Department'] // Add the new field
        ];
    }

    $db->close();

    // Return the DataTables-specific response format
    return [
        'draw' => $draw,
        'recordsTotal' => $total_records,
        'recordsFiltered' => $total_filtered_records,
        'data' => $data,
        'status' => 'success'
    ];
}


/**
 * Enhanced SAP Location parsing function 
 */
function parseSAPLocationData($rts_data) {
    // First try to get from separate columns (new structure)
    if (!empty($rts_data['sap_from_location']) || !empty($rts_data['sap_to_location'])) {
        return [
            'from' => [
                'code' => $rts_data['sap_from_location'] ?? 'N/A',
                'description' => $rts_data['sap_from_description'] ?? '',
                'department' => $rts_data['sap_from_department'] ?? ''
            ],
            'to' => [
                'code' => $rts_data['sap_to_location'] ?? 'N/A',
                'description' => $rts_data['sap_to_description'] ?? '',
                'department' => $rts_data['sap_to_department'] ?? ''
            ]
        ];
    }
    
    // Fallback to parsing the old sap_loc_code format
    $sap_loc_code = $rts_data['sap_loc_code'] ?? '';
    
    if (empty($sap_loc_code)) {
        return [
            'from' => ['code' => 'N/A', 'description' => '', 'department' => ''],
            'to' => ['code' => 'N/A', 'description' => '', 'department' => '']
        ];
    }
    
    // Check if it contains the arrow separator (simple format)
    if (strpos($sap_loc_code, '→') !== false) {
        $parts = explode('→', $sap_loc_code);
        return [
            'from' => [
                'code' => trim($parts[0] ?? 'N/A'),
                'description' => '',
                'department' => ''
            ],
            'to' => [
                'code' => trim($parts[1] ?? 'N/A'),
                'description' => '',
                'department' => ''
            ]
        ];
    }
    
    // Fallback for old single location format
    return [
        'from' => ['code' => trim($sap_loc_code), 'description' => '', 'department' => ''],
        'to' => ['code' => 'N/A', 'description' => '', 'department' => '']
    ];
}

/**
 * Adds a new SAP location code to the database.
 * @param string 
 * @param string 
 * @param string 
 * @return array 
 */
function addSapLocCode($location_code, $location_name, $department) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    // Basic validation
    if (empty($location_code) || empty($location_name) || empty($department)) {
        return ['success' => false, 'message' => 'Location Code, Location Name, and Department are all required.'];
    }

    $db = new Connection();
    $connLink = $db->link;

    try {
        // Check if the location code already exists
        $check_sql = "SELECT LocationCode FROM sap_loc_code WHERE LocationCode = ?";
        $check_stmt = sqlsrv_query($connLink, $check_sql, [$location_code]);
        if ($check_stmt === false) {
            throw new Exception("SQL Server check query error: " . print_r(sqlsrv_errors(), true));
        }
        if (sqlsrv_has_rows($check_stmt)) {
            $db->close();
            return ['success' => false, 'message' => 'This Location Code already exists.'];
        }

        // Insert the new record, including the Department column
        $insert_sql = "INSERT INTO sap_loc_code (LocationCode, LocationDescription, Department) VALUES (?, ?, ?)";
        $params = [$location_code, $location_name, $department];
        $stmt = sqlsrv_query($connLink, $insert_sql, $params);

        if ($stmt === false) {
            throw new Exception("SQL Server insert query error: " . print_r(sqlsrv_errors(), true));
        }

        if (sqlsrv_rows_affected($stmt) > 0) {
            return ['success' => true, 'message' => 'Location Code added successfully.'];
        } else {
            return ['success' => false, 'message' => 'Failed to add the location code. No rows were affected.'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        $db->close();
    }
}

/**
 * Updates an existing SAP location code record in the database.
 * @param string 
 * @param string 
 * @param string 
 * @param string  
 * @return array 
 */
function updateSapLocCode($original_location_code, $new_location_code, $location_name, $department) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    // Basic validation
    if (empty($original_location_code) || empty($new_location_code) || empty($location_name) || empty($department)) {
        return ['success' => false, 'message' => 'All fields are required.'];
    }

    $db = new Connection();
    $connLink = $db->link;

    try {
        // Prepare the SQL update statement
        $sql = "UPDATE sap_loc_code SET LocationCode = ?, LocationDescription = ?, Department = ? WHERE LocationCode = ?";
        $params = [$new_location_code, $location_name, $department, $original_location_code];
        $stmt = sqlsrv_query($connLink, $sql, $params);

        if ($stmt === false) {
            throw new Exception("SQL Server update query error: " . print_r(sqlsrv_errors(), true));
        }

        if (sqlsrv_rows_affected($stmt) > 0) {
            return ['success' => true, 'message' => 'Location Code updated successfully.'];
        } else {
            return ['success' => false, 'message' => 'Failed to update the location code or no changes were made.'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        $db->close();
    }
}

/**
 * Deletes an SAP location code record from the database.
 * @param string 
 * @return array 
 */
function deleteSapLocCode($location_code) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

    $db = new Connection();
    $connLink = $db->link;

    try {
        $sql = "DELETE FROM sap_loc_code WHERE LocationCode = ?";
        $params = [$location_code];
        $stmt = sqlsrv_query($connLink, $sql, $params);

        if ($stmt === false) {
            throw new Exception("SQL Server delete query error: " . print_r(sqlsrv_errors(), true));
        }

        if (sqlsrv_rows_affected($stmt) > 0) {
            return ['success' => true, 'message' => 'Location Code deleted successfully.'];
        } else {
            return ['success' => false, 'message' => 'Failed to delete the location code or no record found.'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        $db->close();
    }
}

function getRTSDetails($rts_id) {
    // Variable initialization
    $rts = null;
    $items = [];
    $error_message = null;

    if (!$rts_id) {
        $error_message = "RTS request ID not specified.";
        return ['rts' => null, 'items' => [], 'error_message' => $error_message];
    }

    try {
        $db = new Connection();
        $conn = $db->link;

        // Fetch the RTS form details - Make sure workflow_status is included
        $sql = "SELECT
                    rts_forms.*,
                    submitted_user.requestor_name AS submitted_by,
                    checked_user.requestor_name AS checked_by_name,
                    approved_user.requestor_name AS approved_by_name,
                    noted_user.requestor_name AS noted_by_name,
                    sap_codes.LocationDescription,
                    sap_codes.Department AS sap_department
                FROM rts_forms
                LEFT JOIN users AS submitted_user ON rts_forms.requestor_id = submitted_user.user_id
                LEFT JOIN users AS checked_user ON rts_forms.checked_by_id = checked_user.user_id
                LEFT JOIN users AS approved_user ON rts_forms.approved_by_id = approved_user.user_id
                LEFT JOIN users AS noted_user ON rts_forms.noted_by_id = noted_user.user_id
                LEFT JOIN sap_loc_code AS sap_codes ON rts_forms.sap_loc_code = sap_codes.LocationCode
                WHERE rts_forms.id = ?";

        $stmt = sqlsrv_query($conn, $sql, [$rts_id], [
            "Scrollable" => SQLSRV_CURSOR_FORWARD,
            "ReturnDatesAsStrings" => false
        ]);

        if ($stmt === false) {
            throw new Exception("Database query for form failed: " . print_r(sqlsrv_errors(), true));
        }

        if (sqlsrv_has_rows($stmt)) {
            $rts = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            
            // Debug: Log the workflow_status to verify it's being fetched
            error_log("Debug - RTS ID: $rts_id, Workflow Status: " . ($rts['workflow_status'] ?? 'NULL'));

            // Convert signature images to Base64
            $rts['prepared_by_signature_base64'] = convertSignatureToBase64($rts['prepared_by_signature_image'] ?? null);
            $rts['checked_by_signature_base64'] = convertSignatureToBase64($rts['checked_by_signature_image'] ?? null);
            $rts['approved_by_signature_base64'] = convertSignatureToBase64($rts['approved_by_signature_image'] ?? null);
            $rts['noted_by_signature_base64'] = convertSignatureToBase64($rts['noted_by_signature_image'] ?? null);

            // Fetch the materials for the RTS form
            $sql_items = "SELECT * FROM rts_materials WHERE rts_form_id = ?";
            $stmt_items = sqlsrv_query($conn, $sql_items, [$rts_id]);

            if ($stmt_items === false) {
                throw new Exception("Database query for items failed: " . print_r(sqlsrv_errors(), true));
            }

            while ($row = sqlsrv_fetch_array($stmt_items, SQLSRV_FETCH_ASSOC)) {
                $items[] = $row;
            }
        } else {
            $error_message = "RTS request not found.";
        }

    } catch (Exception $e) {
        $error_message = "An error occurred: " . $e->getMessage();
        error_log("Error in getRTSDetails: " . $e->getMessage());
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }

    // Return all data in a single array
    return [
        'rts' => $rts,
        'items' => $items,
        'error_message' => $error_message
    ];
}

/**
 * Function to convert binary signature data to a Base64 string.
 * @param mixed 
 * @return string|null 
 */
function convertSignatureToBase64($signature_data) {
    if (empty($signature_data)) {
        return null;
    }

    $image_data = false;
    if (is_resource($signature_data)) {
        $image_data = stream_get_contents($signature_data);
        if ($image_data !== false && is_resource($signature_data)) {
            fclose($signature_data);
        }
    } elseif (is_string($signature_data)) {
        $image_data = $signature_data;
    }

    return $image_data ? 'data:image/png;base64,' . base64_encode($image_data) : null;
}

/**
 * Initializes and validates user session and fetches necessary data for the scrap rts form.
 * @param int $userId 
 * @return array 
 */
function initializeScrapRTSPageData($userId)
{
    // Check if a user ID is provided.
    if (!isset($userId)) {
        return [
            'success' => false,
            'message' => 'User not authenticated.',
            'redirect' => BASE_URL . '/login.php'
        ];
    }

    $userData = getUserData($userId);

    if (!$userData['success']) {
        // User data not found, provide a default or handle the error.
        return [
            'success' => false,
            'message' => 'User data not found.',
            'userData' => [
                'requestor_name' => 'User Not Found',
                'department' => '',
                'role' => '',
                'e_signiture' => null
            ]
        ];
    }

    $data = $userData['data'];

    // Check for scrap permission.
    if (!checkScrapPermission($data['department'], $data['role'])) {
        return [
            'success' => false,
            'message' => 'User does not have permission to access this page.',
            'redirect' => BASE_URL . '/pages/scrap/scrap_dashboard.php'
        ];
    }

    // Process user signature.
    $signature_base64 = '';
    if (!empty($data['e_signiture'])) {
        $user_signature_data = is_resource($data['e_signiture']) ?
            stream_get_contents($data['e_signiture']) : $data['e_signiture'];
        $signature_base64 = 'data:image/jpeg;base64,' . base64_encode($user_signature_data);
    }

    // Fetch departments and SAP locations from the database.
    $formOptions = getScrapRTSFormOptions();

    // Prepare all data to be returned.
    return array_merge([
        'success' => true,
        'userData' => [
            'requestor_name' => htmlspecialchars($data['requestor_name'] ?? $data['username']),
            'department' => $data['department'],
            'role' => $data['role'],
            'signature_base64' => $signature_base64,
        ],
        'control_no' => 'Will be generated upon submission',
    ], $formOptions);
}

/**
 * Fetches departments and SAP locations from the database.
 * @return array 
 */
function getScrapRTSFormOptions()
{
    $departments = [];
    $sap_locations = [];
    $errorMessage = null;

    try {
        $db = new Connection();
        $conn = $db->link;

        // Fetch departments.
        $sql_departments = "SELECT DISTINCT department FROM users";
        $stmt_departments = sqlsrv_query($conn, $sql_departments);
        if ($stmt_departments === false) {
            throw new Exception("SQL Server query error (departments): " . print_r(sqlsrv_errors(), true));
        }
        while ($row = sqlsrv_fetch_array($stmt_departments, SQLSRV_FETCH_ASSOC)) {
            $departments[] = $row['department'];
        }

        // Fetch SAP locations.
        $sql_locations = "SELECT LocationCode, LocationDescription, Department FROM sap_loc_code ORDER BY LocationCode";
        $stmt_locations = sqlsrv_query($conn, $sql_locations);
        if ($stmt_locations === false) {
            throw new Exception("SQL Server query error (locations): " . print_r(sqlsrv_errors(), true));
        }
        while ($row = sqlsrv_fetch_array($stmt_locations, SQLSRV_FETCH_ASSOC)) {
            $sap_locations[] = $row;
        }

    } catch (Exception $e) {
        error_log("Database fetch error in getScrapFormOptions: " . $e->getMessage());
        $errorMessage = $e->getMessage();
        $departments = ['Error fetching departments'];
        $sap_locations = [['LocationCode' => 'Error', 'LocationDescription' => 'Error', 'Department' => 'Error']];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }

    return [
        'departments' => $departments,
        'sap_locations' => $sap_locations,
        'errorMessage' => $errorMessage
    ];
}

/**
 * Get RTS details for resubmission including original material status 
 */
function getRTSDetailsForResubmission($rts_id, $user_id) {
    try {
        $db = new Connection();
        $conn = $db->link;

        // First verify the form is disapproved and belongs to the user
        $sql_check = "SELECT * FROM rts_forms WHERE id = ? AND requestor_id = ? AND workflow_status = 'Disapproved'";
        $stmt_check = sqlsrv_query($conn, $sql_check, [$rts_id, $user_id]);
        
        if (!$stmt_check || !sqlsrv_has_rows($stmt_check)) {
            return ['success' => false, 'message' => 'Invalid request or permission denied.'];
        }

        // Get full RTS details
        $rtsData = getRTSDetails($rts_id);
        if ($rtsData['error_message']) {
            return ['success' => false, 'message' => $rtsData['error_message']];
        }

        // Get user signature
        $userData = getUserData($user_id);
        $signature_base64 = '';
        if ($userData['success'] && !empty($userData['data']['e_signiture'])) {
            $user_signature_data = is_resource($userData['data']['e_signiture']) ?
                stream_get_contents($userData['data']['e_signiture']) : $userData['data']['e_signiture'];
            $signature_base64 = 'data:image/jpeg;base64,' . base64_encode($user_signature_data);
        }

        // Get form options
        $formOptions = getScrapRTSFormOptions();
        
        // Get original material status
        $original_material_statuses = getRTSOriginalMaterialStatus($rts_id);

        return [
            'success' => true,
            'rts' => $rtsData['rts'],
            'items' => $rtsData['items'],
            'signature_base64' => $signature_base64,
            'departments' => $formOptions['departments'],
            'sap_locations' => $formOptions['sap_locations'],
            'original_material_statuses' => $original_material_statuses
        ];

    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }
}

/**
 * Get original material status from RTS form 
 */
function getRTSOriginalMaterialStatus($rts_id) {
    try {
        $db = new Connection();
        $conn = $db->link;
        
        // First check if we have stored the original selection
        $sql = "SELECT original_material_status_selection, material_status, judgement, details FROM rts_forms WHERE id = ?";
        $stmt = sqlsrv_query($conn, $sql, [$rts_id]);
        
        if ($stmt && sqlsrv_fetch($stmt)) {
            $original_selection = sqlsrv_get_field($stmt, 0);
            $material_status = sqlsrv_get_field($stmt, 1);
            
            // If we have the original selection stored, use it
            if ($original_selection) {
                return explode(', ', $original_selection);
            }
            
            // Otherwise, use the current material_status
            if ($material_status) {
                return explode(', ', $material_status);
            }
            
            // Fallback to inferring from judgement
            $judgement = sqlsrv_get_field($stmt, 2);
            $details = sqlsrv_get_field($stmt, 3);
            
            if (strpos($judgement, 'Transfer to Good') !== false) {
                return ['Good'];
            } elseif (strpos($judgement, 'Scrap/Disposal') !== false || strpos($judgement, 'Hold') !== false) {
                // Try to infer from details field if it contains status info
                if (strpos($details, 'Material Defect') !== false) {
                    return ['Material Defect'];
                } elseif (strpos($details, 'Human Error') !== false) {
                    return ['Human Error'];
                } elseif (strpos($details, 'EOL') !== false) {
                    return ['EOL'];
                } else {
                    return ['NG/Others'];
                }
            }
        }
        
        return [];
        
    } catch (Exception $e) {
        return [];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }
}

/**
 * Verify user has permission to resubmit a form
 */
function verifyResubmissionPermission($form_id, $user_id) {
    try {
        $db = new Connection();
        $conn = $db->link;
        
        $sql = "SELECT requestor_id, workflow_status FROM rts_forms WHERE id = ?";
        $stmt = sqlsrv_query($conn, $sql, [$form_id]);
        
        if (!$stmt || !sqlsrv_has_rows($stmt)) {
            return ['success' => false, 'message' => 'Form not found.'];
        }
        
        $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        
        if ($row['requestor_id'] != $user_id) {
            return ['success' => false, 'message' => 'You do not have permission to resubmit this form.'];
        }
        
        if ($row['workflow_status'] != 'Disapproved') {
            return ['success' => false, 'message' => 'Only disapproved forms can be resubmitted.'];
        }
        
        return ['success' => true];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
    } finally {
        if (isset($db)) {
            $db->close();
        }
    }
}

?>