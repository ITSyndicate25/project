<?php
// logout.php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/assets/db/connection.php';

// Clean up active session before destroying PHP session
if (isset($_SESSION['user_id'])) {
    try {
        $conn = new Connection();
        $session_id = session_id();
        
        // Remove from active_sessions
        $delete_sql = "DELETE FROM active_sessions WHERE session_id = ? OR user_id = ?";
        $delete_params = array($session_id, $_SESSION['user_id']);
        $result = sqlsrv_query($conn->link, $delete_sql, $delete_params);
        
        if ($result === false) {
            error_log("Failed to delete active session on logout: " . print_r(sqlsrv_errors(), true));
        }
        
        $conn->close();
    } catch (Exception $e) {
        error_log("Logout cleanup error: " . $e->getMessage());
    }
}

// Clear all session variables
$_SESSION = array();

// Destroy the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy the session
session_destroy();

// Redirect to login page
header('Location: login.php');
exit();
?>