<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id']) || $_SESSION['user_role'] !== 'user') {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

// Get dashboard data for the logged-in user
$user_id = $_SESSION['user_id'];
$dashboard_data = getUserDashboardData($user_id);
$username = htmlspecialchars(ucfirst($dashboard_data['requestor_name']));
$today = $dashboard_data['today'];
$user_role = $_SESSION['user_role'] ?? 'user';
?>

<?php include INCLUDES_PATH . '/header.php'; ?>

<style>
    .card-stats {
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        overflow: hidden;
    }
    
    .card-stats:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
    }
    
    .card-stats .card-body {
        padding: 20px 15px;
    }
    
    .card-stats .icon-big {
        font-size: 3rem;
        margin-bottom: 10px;
        opacity: 0.8;
    }
    
    .card-stats .card-category {
        font-size: 0.875rem;
        text-transform: uppercase;
        font-weight: 500;
        letter-spacing: 0.5px;
        opacity: 0.8;
    }
    
    .card-stats .card-footer {
        padding: 10px 15px;
        background-color: rgba(0, 0, 0, 0.03);
    }
    
    .card-stats .card-footer hr {
        margin: 0 -15px 10px;
        border-top-color: rgba(0, 0, 0, 0.1);
    }
    
    .card-stats .stats {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 500;
    }
    
    /* Animated number counter effect */
    @keyframes countUp {
        from {
            opacity: 0;
            transform: scale(0.5);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
    
    .card-stats .card-title {
        animation: countUp 0.5s ease-out;
    }
    
    /* Centered numbers styling */
    .numbers {
        text-align: center;
    }
    
    /* Loading skeleton animation */
    @keyframes loading {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }
    
    .skeleton {
        background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
        background-size: 200% 100%;
        animation: loading 1.5s infinite;
    }
</style>

<div class="wrapper">
    <?php include INCLUDES_PATH . '/sidebar.php'; ?>
    <div class="main-panel">
        <?php include INCLUDES_PATH . '/navbar.php'; ?>
        <div class="content">
            <!-- Welcome Section with Role Label -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card card-stats">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Welcome, <?php echo htmlspecialchars(ucfirst($dashboard_data['requestor_name'])); ?>!</h5>
                            <p class="card-category mb-0">Today is <?php echo $today; ?></p>
                            <p class="card-category mb-0">
                                <i class="nc-icon nc-badge"></i> Your role: 
                                <span class="badge badge-primary"><?php echo ucfirst($user_role); ?></span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Statistics Cards Row -->
            <div class="row">
                <!-- Total Requests Card -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-paper text-primary"></i>
                                    </div>
                                    <div class="numbers">
                                        <p class="card-category mb-0">Total Requests</p>
                                        <p class="card-title text-primary">
                                            <?php echo $dashboard_data['total_all_forms']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(0, 123, 255, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <i class="fa fa-list-alt text-primary"></i>
                                <small>
                                    RTS: <?php echo $dashboard_data['total_rts']; ?> | 
                                    NG: <?php echo $dashboard_data['total_ng']; ?> | 
                                    C&S: <?php echo $dashboard_data['total_coil_solder']; ?>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pending Approvals Card -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-time-alarm text-warning"></i>
                                    </div>
                                    <div class="numbers">
                                        <p class="card-category mb-0">Pending Approvals</p>
                                        <p class="card-title text-warning">
                                            <?php echo $dashboard_data['pending_all']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(255, 193, 7, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <?php if ($dashboard_data['pending_all'] > 0): ?>
                                    <a href="<?php echo BASE_URL; ?>/pages/requests/pending_requests.php" class="text-warning">
                                        <i class="fa fa-clock"></i> View pending requests
                                    </a>
                                <?php else: ?>
                                    <i class="fa fa-check text-success"></i>
                                    <span class="text-success">All clear</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Ongoing Requests Card -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-settings text-info"></i>
                                    </div>
                                    <div class="numbers">
                                        <p class="card-category mb-0">Ongoing Requests</p>
                                        <p class="card-title text-info">
                                            <?php echo $dashboard_data['ongoing_all']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(23, 162, 184, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <?php if ($dashboard_data['ongoing_all'] > 0): ?>
                                    <a href="<?php echo BASE_URL; ?>/pages/requests/ongoing_requests.php" class="text-info">
                                        <i class="fa fa-sync-alt"></i> View ongoing requests
                                    </a>
                                <?php else: ?>
                                    <i class="fa fa-check text-success"></i>
                                    <span class="text-success">No ongoing requests</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Completed Requests Card -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-check-2 text-success"></i>
                                    </div>
                                    <div class="numbers">
                                        <p class="card-category mb-0">Completed</p>
                                        <p class="card-title text-success">
                                            <?php echo $dashboard_data['completed_all']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(40, 167, 69, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <?php if ($dashboard_data['completed_all'] > 0): ?>
                                    <a href="<?php echo BASE_URL; ?>/pages/requests/completed_requests.php" class="text-success">
                                        <i class="fa fa-trophy"></i> View completed
                                    </a>
                                <?php else: ?>
                                    <i class="fa fa-info-circle text-secondary"></i>
                                    <span class="text-secondary">No completed requests yet</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Second Row - Disapproved and Summary Cards -->
            <div class="row">
                <!-- Disapproved Requests Card -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-simple-remove text-danger"></i>
                                    </div>
                                    <div class="numbers">
                                        <p class="card-category mb-0">Disapproved</p>
                                        <p class="card-title text-danger">
                                            <?php echo $dashboard_data['disapproved_all']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(220, 53, 69, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <?php if ($dashboard_data['disapproved_all'] > 0): ?>
                                    <a href="<?php echo BASE_URL; ?>/pages/requests/disapproved_requests.php" class="text-danger">
                                        <i class="fa fa-times-circle"></i> View disapproved
                                    </a>
                                <?php else: ?>
                                    <i class="fa fa-thumbs-up text-success"></i>
                                    <span class="text-success">No disapproved requests</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Today's Requests -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-calendar-60 text-primary"></i>
                                    </div>
                                    <div class="numbers">
                                        <p class="card-category mb-0">Today's Requests</p>
                                        <p class="card-title text-primary">
                                            <?php echo $dashboard_data['today_requests'] ?? 0; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(0, 123, 255, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <i class="fa fa-calendar-day text-primary"></i> <?php echo date('M d, Y'); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- This Month's Requests -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-chart-pie-36 text-secondary"></i>
                                    </div>
                                    <div class="numbers">
                                        <p class="card-category mb-0">This Month</p>
                                        <p class="card-title text-secondary">
                                            <?php echo $dashboard_data['month_requests'] ?? 0; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(108, 117, 125, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <i class="fa fa-calendar-alt text-secondary"></i> <?php echo date('F Y'); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Success Rate -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-chart-bar-32 text-info"></i>
                                    </div>
                                    <div class="numbers">
                                        <p class="card-category mb-0">Success Rate</p>
                                        <p class="card-title text-info">
                                            <?php 
                                            $total = $dashboard_data['total_all_forms'];
                                            $completed = $dashboard_data['completed_all'];
                                            $rate = $total > 0 ? round(($completed / $total) * 100) : 0;
                                            echo $rate . '%';
                                            ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(23, 162, 184, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <i class="fa fa-percentage text-info"></i> Completion rate
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Request Status Distribution</h5>
                            <p class="card-category">Overview of all your requests</p>
                        </div>
                        <div class="card-body">
                            <canvas id="statusChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Request Types Distribution</h5>
                            <p class="card-category">Breakdown by form type</p>
                        </div>
                        <div class="card-body">
                            <canvas id="typeChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activity Table -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Recent Activity</h5>
                            <p class="card-category">Your recent requests across all forms</p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover" id="userRequestsTable">
                                    <thead class="text-primary">
                                        <th>Request ID</th>
                                        <th>Form Type</th>
                                        <th>Submitted At</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </thead>
                                    <tbody>
                                        <!-- Data will be loaded via DataTables -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include INCLUDES_PATH . '/footer.php'; ?>
    </div>
</div>

<!-- Modal for viewing request -->
<div class="modal fade" id="viewRTSModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="d-flex align-items-center">
                    <h5 class="modal-title mr-3">Request Details</h5>
                    <span class="badge badge-primary" id="formTypeBadge"></span>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="modal-body-content">
                <div class="text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Cache DOM elements
        const $statusChart = $('#statusChart');
        const $typeChart = $('#typeChart');
        
        // Lazy load charts when they come into viewport
        const loadCharts = () => {
            const statusCtx = document.getElementById('statusChart').getContext('2d');
            const typeCtx = document.getElementById('typeChart').getContext('2d');
            
            // Status Distribution Chart
            new Chart(statusCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Pending', 'Ongoing', 'Completed', 'Disapproved'],
                    datasets: [{
                        data: [
                            <?php echo $dashboard_data['pending_all']; ?>,
                            <?php echo $dashboard_data['ongoing_all']; ?>,
                            <?php echo $dashboard_data['completed_all']; ?>,
                            <?php echo $dashboard_data['disapproved_all']; ?>
                        ],
                        backgroundColor: [
                            'rgba(255, 193, 7, 0.8)',
                            'rgba(23, 162, 184, 0.8)',
                            'rgba(40, 167, 69, 0.8)',
                            'rgba(220, 53, 69, 0.8)'
                        ],
                        borderColor: [
                            'rgba(255, 193, 7, 1)',
                            'rgba(23, 162, 184, 1)',
                            'rgba(40, 167, 69, 1)',
                            'rgba(220, 53, 69, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        }
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
            });

            // Type Distribution Chart
            new Chart(typeCtx, {
                type: 'bar',
                data: {
                    labels: ['RTS Forms', 'NG Forms', 'Coil & Solder Forms'],
                    datasets: [{
                        label: 'Number of Requests',
                        data: [
                            <?php echo $dashboard_data['total_rts']; ?>,
                            <?php echo $dashboard_data['total_ng']; ?>,
                            <?php echo $dashboard_data['total_coil_solder']; ?>
                        ],
                        backgroundColor: [
                            'rgba(54, 162, 235, 0.8)',
                            'rgba(255, 206, 86, 0.8)',
                            'rgba(75, 192, 192, 0.8)'
                        ],
                        borderColor: [
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        };

        // Initialize DataTable with optimized settings
        const table = $('#userRequestsTable').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [[2, "desc"]],
            "pageLength": 10,
            "deferRender": true,
            "ajax": {
                "url": "<?php echo BASE_URL; ?>/pages/user/fetch_dashboard_user.php",
                "type": "POST",
                "error": function(xhr, error, thrown) {
                    console.error('DataTable error:', error);
                }
            },
            "columns": [
                {"data": "control_no"},
                {
                    "data": "form_type",
                    "render": function(data, type, row) {
                        if (type === 'display') {
                            let badgeClass = 'badge-secondary';
                            if (data === 'RTS Form') badgeClass = 'badge-primary';
                            else if (data === 'NG Form') badgeClass = 'badge-warning';
                            else if (data === 'Coil and Solder Form') badgeClass = 'badge-info';
                            return `<span class="badge ${badgeClass}">${data}</span>`;
                        }
                        return data;
                    }
                },
                {
                    "data": "created_at",
                    "render": function(data, type, row) {
                        if (type === 'display' && data) {
                            const date = new Date(data);
                            return date.toLocaleString('en-US', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric',
                                hour: 'numeric',
                                minute: 'numeric',
                                hour12: true
                            });
                        }
                        return data;
                    }
                },
                {
                    "data": "workflow_status", // Changed from material_status to workflow_status
                    "render": function(data, type, row) {
                        if (type === 'display') {
                            let badgeClass;
                            let statusText = data;
                            
                            switch (data) {
                                case 'Completed':
                                    badgeClass = 'badge-success';
                                    break;
                                case 'Disapproved':
                                case 'Canceled':
                                    badgeClass = 'badge-danger';
                                    statusText = 'Disapproved';
                                    break;
                                case 'In-Progress':
                                    badgeClass = 'badge-info';
                                    break;
                                case 'Pending':
                                    badgeClass = 'badge-warning';
                                    break;
                                default:
                                    badgeClass = 'badge-secondary';
                            }
                            return `<span class="badge ${badgeClass}">${statusText}</span>`;
                        }
                        return data;
                    }
                },
                {
                    "data": null,
                    "orderable": false,
                    "render": function(data, type, row) {
                        return `<button class="btn btn-sm btn-info" onclick="viewRequest(${row.id}, '${row.control_no}', '${row.form_type}', '${row.workflow_status}')">
                                    <i class="fa fa-eye"></i> View
                                </button>`;
                    }
                }
            ],
            "language": {
                "emptyTable": "No requests found",
                "processing": '<i class="fa fa-spinner fa-spin fa-2x fa-fw"></i><span class="sr-only">Loading...</span>'
            }
        });

        // Load charts after page is ready
        setTimeout(loadCharts, 100);

        // Enable modal focus fix
        $.fn.modal.Constructor.prototype.enforceFocus = function() {};
    });

    // View request function - opens modal directly instead of redirecting
    function viewRequest(id, controlNo, formType, status) {
        const $modal = $('#viewRTSModal');
        const $modalBody = $('#modal-body-content');
        
        // Update modal title
        $('#formTypeBadge').text(formType);
        
        // Show loading
        $modalBody.html(`
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
        `);
        
        // Show modal
        $modal.modal('show');
        
        // Determine which view file to load
        let viewUrl = '';
        if (formType === 'RTS Form') {
            viewUrl = `<?php echo BASE_URL; ?>/pages/requests/view_rts.php?id=${id}&status=${status}`;
        } else if (formType === 'NG Form') {
            viewUrl = `<?php echo BASE_URL; ?>/pages/requests/view_ng.php?id=${id}&status=${status}`;
        } else if (formType === 'Coil and Solder Form') {
            viewUrl = `<?php echo BASE_URL; ?>/pages/requests/view_coil_solder.php?id=${id}&status=${status}`;
        }
        
        // Load content into modal
        fetch(viewUrl)
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.text();
            })
            .then(html => {
                $modalBody.html(html);
            })
            .catch(error => {
                console.error('Error loading request:', error);
                $modalBody.html(`
                    <div class="alert alert-danger">
                        <i class="fa fa-exclamation-triangle"></i> Failed to load request details. Please try again.
                    </div>
                `);
            });
    }
    
    // Clean up modal on close
    $('#viewRTSModal').on('hidden.bs.modal', function () {
        $('#modal-body-content').html(`
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
        `);
    });
</script>