<?php
session_start();
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['data' => []]);
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    $db = new Connection();
    $conn = $db->link;

    // DataTables parameters
    $draw = intval($_POST['draw'] ?? 1);
    $start = intval($_POST['start'] ?? 0);
    $length = intval($_POST['length'] ?? 10);
    $search_value = $_POST['search']['value'] ?? '';
    
    // Count total records
    $count_query = "SELECT COUNT(*) as total FROM rts_forms WHERE requestor_id = ?";
    $stmt_count = sqlsrv_query($conn, $count_query, [$user_id]);
    $total_records = 0;
    if ($stmt_count && $row = sqlsrv_fetch_array($stmt_count, SQLSRV_FETCH_ASSOC)) {
        $total_records = $row['total'];
    }

        // Add search functionality
    $search_condition = "";
    $params = [$user_id];
    if (!empty($search_value)) {
        $search_condition = " AND (control_no LIKE ? OR workflow_status LIKE ?)";
        $search_param = '%' . $search_value . '%';
        $params[] = $search_param;
        $params[] = $search_param;
        
        // Recalculate total with search
        $filtered_count_query = "SELECT COUNT(*) as total FROM rts_forms WHERE requestor_id = ?" . $search_condition;
        $stmt_filtered = sqlsrv_query($conn, $filtered_count_query, $params);
        if ($stmt_filtered && $row = sqlsrv_fetch_array($stmt_filtered, SQLSRV_FETCH_ASSOC)) {
            $total_records = $row['total'];
        }
    }

    // Main query for RTS forms with pagination using workflow_status
    $main_query = "
        SELECT 
            id,
            control_no,
            'RTS Form' as form_type,
            created_at,
            workflow_status
        FROM rts_forms
        WHERE requestor_id = ?" . $search_condition . "
        ORDER BY created_at DESC
        OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    $params[] = $start;
    $params[] = $length;
    $stmt = sqlsrv_query($conn, $main_query, $params);

    $data = [];
    if ($stmt) {
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            if ($row['created_at'] instanceof DateTime) {
                $row['created_at'] = $row['created_at']->format('Y-m-d H:i:s');
            }
            $data[] = $row;
        }
    }

    echo json_encode([
        'draw' => $draw,
        'recordsTotal' => $total_records,
        'recordsFiltered' => $total_records,
        'data' => $data
    ]);

    $db->close();

} catch (Exception $e) {
    error_log("Error in fetch_dashboard_user.php: " . $e->getMessage());
    echo json_encode([
        'draw' => $_POST['draw'] ?? 1,
        'recordsTotal' => 0,
        'recordsFiltered' => 0,
        'data' => [],
        'error' => 'Database error occurred'
    ]);
}
?>