<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/includes/functions.php';
require_once APP_ROOT . '/assets/db/connection.php';

header('Content-Type: application/json');

// Authentication check
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit();
}

// Validate resubmission
if (!isset($_POST['original_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Original form ID not provided.']);
    exit();
}

$original_id = (int)$_POST['original_id'];
$user_id = $_SESSION['user_id'];

// Verify permissions
$check_permission = verifyResubmissionPermission($original_id, $user_id);
if (!$check_permission['success']) {
    echo json_encode(['status' => 'error', 'message' => $check_permission['message']]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = null;
    try {
        $db = new Connection();
        $conn = $db->link;

               if (!sqlsrv_begin_transaction($conn)) {
            throw new Exception("Failed to start DB transaction: " . print_r(sqlsrv_errors(), true));
        }

        // Get user data
        $userData = getUserData($user_id);
        if (!$userData['success']) {
            throw new Exception("User data not found.");
        }

        // CHANGE DETECTION: Get current form data and materials
        $current_data = getCurrentFormData($conn, $original_id);
        if (!$current_data) {
            throw new Exception("Original form data not found.");
        }

        // Get disapproval information for email notification
        $disapproval_info = getDisapprovalInfo($conn, $original_id);

        // Prepare new form data
        $new_form_data = prepareResubmissionData($_POST, $userData, $conn);
        
        // CHANGE DETECTION: Compare form data
        $form_changes = detectFormChanges($current_data['form'], $new_form_data);
        
        // CHANGE DETECTION: Compare material data
        $current_materials = getCurrentMaterialData($conn, $original_id);
        $new_materials = $_POST['material_details'] ?? [];
        $material_changes = detectMaterialChanges($current_materials, $new_materials);

        // Check if any changes were made
        if (!$form_changes && !$material_changes) {
            echo json_encode([
                'status' => 'error', 
                'message' => 'No changes detected. Please make modifications before resubmitting the form.',
                'details' => 'The form data and materials are identical to the previous submission.'
            ]);
            exit();
        }

        // Log detected changes for debugging
        error_log("Resubmission changes detected for ID $original_id - Form: " . ($form_changes ? 'Yes' : 'No') . ", Materials: " . ($material_changes ? 'Yes' : 'No'));

        // Use the original control number
        $control_no = $_POST['control_no'];

        // Optimized update query using the workflow_status index
        $sql_update = "
            UPDATE rts_forms SET
                material_type = ?, material_status = ?, judgement = ?, details = ?, remark = ?, 
                return_date = ?, department = ?, model = ?, sap_loc_code = ?,
                sap_from_location = ?, sap_to_location = ?, sap_from_description = ?, 
                sap_to_description = ?, sap_from_department = ?, sap_to_department = ?,
                original_material_status_selection = ?, workflow_status = 'Pending',
                checked_by = NULL, approved_by = NULL, noted_by = NULL,
                checked_by_id = NULL, approved_by_id = NULL, noted_by_id = NULL,
                checked_at = NULL, approved_at = NULL, noted_at = NULL,
                checked_status = 'Pending', approved_status = 'Pending', noted_status = 'Pending',
                disapproval_reason = NULL, disapproved_by_role = NULL,
                checked_by_signature_image = NULL, approved_by_signature_image = NULL, noted_by_signature_image = NULL,
                resubmission_count = ISNULL(resubmission_count, 0) + 1, resubmitted_at = GETDATE()
            WHERE id = ?
        ";

        $stmt_update = sqlsrv_query($conn, $sql_update, $new_form_data['params']);
        
        if ($stmt_update === false) {
            throw new Exception("SQL Update Error (rts_forms): " . print_r(sqlsrv_errors(), true));
        }

        // Update materials only if there are changes
        if ($material_changes) {
            updateMaterialDetails($conn, $original_id, $new_materials);
        }
        
        // Commit transaction first
        if (!sqlsrv_commit($conn)) {
            throw new Exception("Failed to commit database transaction: " . print_r(sqlsrv_errors(), true));
        }
        
        // REQUIREMENT: Send resubmission notification to the approver who originally disapproved
        if (!empty($disapproval_info['approver_email'])) {
            include_once APP_ROOT . '/includes/send_email.php';
            
            try {
                $approver_emails = [$disapproval_info['approver_email']];
                $email_result = sendResubmissionToApproverEmail($approver_emails, $control_no, $disapproval_info);
                
                if ($email_result) {
                    error_log("Resubmission notification sent to original disapproving approver ({$disapproval_info['approver_email']}) for Control No: $control_no");
                } else {
                    error_log("Failed to send resubmission notification to approver for Control No: $control_no");
                }
            } catch (Exception $email_error) {
                error_log("Exception sending resubmission notification to approver for Control No: $control_no. Error: " . $email_error->getMessage());
            }
        } else {
            // Fallback: Send to checker emails if no specific approver found
            $checker_emails = getCheckerEmailsOptimized($conn);
            
            if (!empty($checker_emails)) {
                include_once APP_ROOT . '/includes/send_email.php';
                
                try {
                    $email_result = sendEmailRTSResubmission($checker_emails, $control_no);
                    error_log($email_result ? 
                        "Resubmission notification sent to " . count($checker_emails) . " checker(s) for Control No: $control_no (fallback)" :
                        "Failed to send resubmission notification for Control No: $control_no"
                    );
                } catch (Exception $email_error) {
                    error_log("Exception sending resubmission notification for Control No: $control_no. Error: " . $email_error->getMessage());
                }
            } else {
                error_log("No approver or checker users found to send resubmission email to.");
            }
        }

        echo json_encode([
            'status' => 'success',
            'control_no' => $control_no,
            'message' => 'RTS form resubmitted successfully and notification sent to the original disapproving approver.',
            'changes_detected' => [
                'form_changes' => $form_changes,
                'material_changes' => $material_changes
            ]
        ]);
        exit();

    } catch (Exception $e) {
        if ($db && $db->link) {
            sqlsrv_rollback($db->link);
        }
        
        echo json_encode([
            'status' => 'error',
            'message' => 'An error occurred: ' . $e->getMessage()
        ]);
        exit();
    } finally {
        if ($db) {
            $db->close();
        }
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method.'
    ]);
    exit();
}

// NEW FUNCTION: Get disapproval information including the approver who disapproved
function getDisapprovalInfo($conn, $form_id) {
    $sql = "
        SELECT 
            rf.disapproved_by_role,
            rf.disapproval_reason,
            CASE 
                WHEN rf.disapproved_by_role = 'checker' THEN u_checker.email
                WHEN rf.disapproved_by_role = 'approver' THEN u_approver.email  
                WHEN rf.disapproved_by_role = 'noter' THEN u_noter.email
                ELSE NULL
            END as approver_email,
            CASE 
                WHEN rf.disapproved_by_role = 'checker' THEN rf.checked_by
                WHEN rf.disapproved_by_role = 'approver' THEN rf.approved_by
                WHEN rf.disapproved_by_role = 'noter' THEN rf.noted_by
                ELSE NULL
            END as approver_name
        FROM rts_forms rf
        LEFT JOIN users u_checker ON rf.checked_by_id = u_checker.user_id
        LEFT JOIN users u_approver ON rf.approved_by_id = u_approver.user_id
        LEFT JOIN users u_noter ON rf.noted_by_id = u_noter.user_id
        WHERE rf.id = ? AND rf.workflow_status = 'Disapproved'
    ";
    
    $stmt = sqlsrv_query($conn, $sql, [$form_id]);
    if ($stmt === false) {
        error_log("Failed to get disapproval info: " . print_r(sqlsrv_errors(), true));
        return [];
    }
    
    $result = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    if ($result) {
        return [
            'role' => $result['disapproved_by_role'],
            'reason' => $result['disapproval_reason'],
            'approver_email' => $result['approver_email'],
            'approver_name' => $result['approver_name']
        ];
    }
    
    return [];
}

// OPTIMIZED: Get current form data for comparison
function getCurrentFormData($conn, $form_id) {
    $sql = "SELECT material_type, material_status, judgement, details, remark, return_date, 
                   department, model, sap_loc_code, sap_from_location, sap_to_location,
                   sap_from_description, sap_to_description, sap_from_department, sap_to_department,
                   original_material_status_selection, control_no
            FROM rts_forms WHERE id = ?";
    
    $stmt = sqlsrv_query($conn, $sql, [$form_id]);
    if ($stmt === false) {
        return false;
    }
    
    $form_data = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    return $form_data ? ['form' => $form_data] : false;
}

// OPTIMIZED: Get current material data for comparison
function getCurrentMaterialData($conn, $form_id) {
    $sql = "SELECT ref_no, sap_doc, invoice_no, supplier, part_name, part_number, description, 
                   qty_returned, qty_received, amount, due_date
            FROM rts_materials WHERE rts_form_id = ? ORDER BY id";
    
    $stmt = sqlsrv_query($conn, $sql, [$form_id]);
    if ($stmt === false) {
        return [];
    }
    
    $materials = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        // Convert DateTime objects to strings for comparison
        if ($row['due_date'] instanceof DateTime) {
            $row['due_date'] = $row['due_date']->format('Y-m-d');
        }
        $materials[] = $row;
    }
    
    return $materials;
}

// OPTIMIZED: Detect form changes with normalized comparison
function detectFormChanges($current_form, $new_form_data) {
    // Normalize data for comparison
    $current_normalized = normalizeFormData($current_form);
    $new_normalized = normalizeNewFormData($new_form_data);
    
    // Compare each field
    foreach ($current_normalized as $field => $current_value) {
        $new_value = $new_normalized[$field] ?? null;
        
        // Normalize values for comparison
        $current_clean = trim($current_value ?? '');
        $new_clean = trim($new_value ?? '');
        
        // Handle date comparison
        if (in_array($field, ['return_date']) && !empty($current_clean) && !empty($new_clean)) {
            $current_clean = date('Y-m-d', strtotime($current_clean));
            $new_clean = date('Y-m-d', strtotime($new_clean));
        }
        
        if ($current_clean !== $new_clean) {
            error_log("Form change detected in field '$field': '$current_clean' -> '$new_clean'");
            return true;
        }
    }
    
    return false;
}

// OPTIMIZED: Detect material changes with detailed comparison
function detectMaterialChanges($current_materials, $new_materials) {
    // Normalize new materials data
    $normalized_new = normalizeMaterialsData($new_materials);
    
    // Compare counts first
    if (count($current_materials) !== count($normalized_new)) {
        error_log("Material change detected: count difference - " . count($current_materials) . " vs " . count($normalized_new));
        return true;
    }
    
    // Compare each material row
    for ($i = 0; $i < count($current_materials); $i++) {
        $current = $current_materials[$i];
        $new = $normalized_new[$i] ?? [];
        
        // Define fields to compare
        $fields_to_compare = ['ref_no', 'sap_doc', 'invoice_no', 'supplier', 'part_name', 
                             'part_number', 'description', 'qty_returned', 'qty_received', 'amount', 'due_date'];
        
        foreach ($fields_to_compare as $field) {
            $current_value = trim($current[$field] ?? '');
            $new_value = trim($new[$field] ?? '');
            
            // Handle numeric fields
            if (in_array($field, ['qty_returned', 'qty_received', 'amount'])) {
                $current_value = $current_value === '' ? '0' : $current_value;
                $new_value = $new_value === '' ? '0' : $new_value;
            }
            
            // Handle date fields
            if ($field === 'due_date' && !empty($current_value) && !empty($new_value)) {
                $current_value = date('Y-m-d', strtotime($current_value));
                $new_value = date('Y-m-d', strtotime($new_value));
            }
            
            if ($current_value !== $new_value) {
                error_log("Material change detected in row $i, field '$field': '$current_value' -> '$new_value'");
                return true;
            }
        }
    }
    
    return false;
}

// Helper function to normalize current form data
function normalizeFormData($form_data) {
    return [
        'material_type' => $form_data['material_type'] ?? '',
        'material_status' => $form_data['material_status'] ?? '',
        'judgement' => $form_data['judgement'] ?? '',
        'details' => $form_data['details'] ?? '',
        'remark' => $form_data['remark'] ?? '',
        'return_date' => $form_data['return_date'] ? $form_data['return_date']->format('Y-m-d') : '',
        'department' => $form_data['department'] ?? '',
        'model' => $form_data['model'] ?? '',
        'sap_loc_code' => $form_data['sap_loc_code'] ?? '',
        'sap_from_location' => $form_data['sap_from_location'] ?? '',
        'sap_to_location' => $form_data['sap_to_location'] ?? '',
        'sap_from_description' => $form_data['sap_from_description'] ?? '',
        'sap_to_description' => $form_data['sap_to_description'] ?? '',
        'sap_from_department' => $form_data['sap_from_department'] ?? '',
        'sap_to_department' => $form_data['sap_to_department'] ?? ''
    ];
}

// Helper function to normalize new form data
function normalizeNewFormData($new_form_data) {
    $params = $new_form_data['params'];
    return [
        'material_type' => $params[0] ?? '',
        'material_status' => $params[1] ?? '',
        'judgement' => $params[2] ?? '',
        'details' => $params[3] ?? '',
        'remark' => $params[4] ?? '',
        'return_date' => $params[5] ?? '',
        'department' => $params[6] ?? '',
        'model' => $params[7] ?? '',
        'sap_loc_code' => $params[8] ?? '',
        'sap_from_location' => $params[9] ?? '',
        'sap_to_location' => $params[10] ?? '',
        'sap_from_description' => $params[11] ?? '',
        'sap_to_description' => $params[12] ?? '',
        'sap_from_department' => $params[13] ?? '',
        'sap_to_department' => $params[14] ?? ''
    ];
}

// Helper function to normalize materials data
function normalizeMaterialsData($material_details) {
    if (empty($material_details)) {
        return [];
    }

    $ref_no_arr = $material_details['ref_no'] ?? [];
    $count_materials = count($ref_no_arr);
    $normalized = [];

    for ($i = 0; $i < $count_materials; $i++) {
        // Check if row has any data
        $has_data = !empty($ref_no_arr[$i]) || !empty($material_details['sap_doc'][$i] ?? '') ||
                   !empty($material_details['invoice_no'][$i] ?? '') || !empty($material_details['supplier'][$i] ?? '') ||
                   !empty($material_details['part_name'][$i] ?? '') || !empty($material_details['part_number'][$i] ?? '') ||
                   !empty($material_details['description'][$i] ?? '') || !empty($material_details['qty_returned'][$i] ?? '') ||
                   !empty($material_details['qty_received'][$i] ?? '') || !empty($material_details['amount'][$i] ?? '') ||
                   !empty($material_details['due_date'][$i] ?? '');

        if (!$has_data) continue;

        $due_date = !empty($material_details['due_date'][$i]) ? date('Y-m-d', strtotime($material_details['due_date'][$i])) : '';

        $normalized[] = [
            'ref_no' => $material_details['ref_no'][$i] ?? '',
            'sap_doc' => $material_details['sap_doc'][$i] ?? '',
            'invoice_no' => $material_details['invoice_no'][$i] ?? '',
            'supplier' => $material_details['supplier'][$i] ?? '',
            'part_name' => $material_details['part_name'][$i] ?? '',
            'part_number' => $material_details['part_number'][$i] ?? '',
            'description' => $material_details['description'][$i] ?? '',
            'qty_returned' => $material_details['qty_returned'][$i] ?? '',
            'qty_received' => $material_details['qty_received'][$i] ?? '',
            'amount' => $material_details['amount'][$i] ?? '',
            'due_date' => $due_date
        ];
    }

    return $normalized;
}

// Keep existing optimized helper functions...
function prepareResubmissionData($post_data, $userData, $conn) {
    $material_type_arr = $post_data['material_type'] ?? [];
    $material_type = !empty($material_type_arr) ? implode(', ', $material_type_arr) : null;
    
    $material_status_selection = $post_data['material_status'] ?? [];
    $original_material_status_selection = !empty($material_status_selection) ? implode(', ', $material_status_selection) : null;
    $material_status = $original_material_status_selection;

    $judgement_arr = $post_data['judgement'] ?? [];
    $judgement = !empty($judgement_arr) ? implode(', ', $judgement_arr) : null;

    $details = $post_data['details'] ?? null;
    $remark = $post_data['remark'] ?? null;
    $return_date = !empty($post_data['return_date']) ? date('Y-m-d', strtotime($post_data['return_date'])) : null;
    $department = $post_data['department'] ?? $post_data['department_backup'] ?? null;
    $model = $post_data['model'] ?? null;
    
    $sap_location_from_code = $post_data['sap_location']['from'] ?? null;
    $sap_location_to_code = $post_data['sap_location']['to'] ?? null;
    
    // Get SAP location details
    $sap_from_details = getSapLocationDetails($sap_location_from_code, $conn);
    $sap_to_details = getSapLocationDetails($sap_location_to_code, $conn);
    $sap_loc_code = $sap_location_from_code . ' → ' . $sap_location_to_code;

    return [
        'params' => [
            $material_type, $material_status, $judgement, $details, $remark, $return_date,
            $department, $model, $sap_loc_code, $sap_location_from_code, $sap_location_to_code,
            $sap_from_details['description'], $sap_to_details['description'],
            $sap_from_details['department'], $sap_to_details['department'],
            $original_material_status_selection, $post_data['original_id']
        ]
    ];
}

function updateMaterialDetails($conn, $form_id, $material_details) {
    // Delete existing materials efficiently using the index
    $sql_delete = "DELETE FROM rts_materials WHERE rts_form_id = ?";
    sqlsrv_query($conn, $sql_delete, [$form_id]);

    if (empty($material_details)) return;

    // Batch insert new materials
    $ref_no_arr = $material_details['ref_no'] ?? [];
    $count_materials = count($ref_no_arr);
    
    if ($count_materials === 0) return;

    $sql_insert = "
        INSERT INTO rts_materials
            (rts_form_id, ref_no, sap_doc, invoice_no, supplier, part_name, part_number, description, qty_returned, qty_received, amount, due_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ";

    for ($i = 0; $i < $count_materials; $i++) {
        // Check if row has any data
        $has_data = !empty($ref_no_arr[$i]) || !empty($material_details['sap_doc'][$i] ?? '') ||
                   !empty($material_details['invoice_no'][$i] ?? '') || !empty($material_details['supplier'][$i] ?? '') ||
                   !empty($material_details['part_name'][$i] ?? '') || !empty($material_details['part_number'][$i] ?? '') ||
                   !empty($material_details['description'][$i] ?? '') || !empty($material_details['qty_returned'][$i] ?? '') ||
                   !empty($material_details['qty_received'][$i] ?? '') || !empty($material_details['amount'][$i] ?? '') ||
                   !empty($material_details['due_date'][$i] ?? '');

        if (!$has_data) continue;

        $due_date = !empty($material_details['due_date'][$i]) ? date('Y-m-d', strtotime($material_details['due_date'][$i])) : null;
        $qty_returned = isset($material_details['qty_returned'][$i]) && $material_details['qty_returned'][$i] !== '' ? (int)$material_details['qty_returned'][$i] : null;
        $qty_received = isset($material_details['qty_received'][$i]) && $material_details['qty_received'][$i] !== '' ? (int)$material_details['qty_received'][$i] : null;
        $amount = isset($material_details['amount'][$i]) && $material_details['amount'][$i] !== '' ? (float)$material_details['amount'][$i] : null;

        $params = [
            $form_id, $ref_no_arr[$i], $material_details['sap_doc'][$i] ?? null,
            $material_details['invoice_no'][$i] ?? null, $material_details['supplier'][$i] ?? null,
            $material_details['part_name'][$i] ?? null, $material_details['part_number'][$i] ?? null,
            $material_details['description'][$i] ?? null, $qty_returned, $qty_received, $amount, $due_date
        ];

        $stmt = sqlsrv_query($conn, $sql_insert, $params);
        if ($stmt === false) {
            throw new Exception("Failed to insert material at index $i: " . print_r(sqlsrv_errors(), true));
        }
    }
}

function getCheckerEmailsOptimized($conn) {
    $sql_checkers = "
        SELECT DISTINCT TOP 20 email 
        FROM users 
        WHERE role = 'checker' 
        AND is_active = 1 
        AND email IS NOT NULL 
        AND email != ''
        ORDER BY email
    ";
    
    $stmt_checkers = sqlsrv_query($conn, $sql_checkers);
    if ($stmt_checkers === false) {
        error_log("Failed to fetch checker emails: " . print_r(sqlsrv_errors(), true));
        return [];
    }
    
    $checker_emails = [];
    while ($row = sqlsrv_fetch_array($stmt_checkers, SQLSRV_FETCH_ASSOC)) {
        if (!empty($row['email']) && filter_var($row['email'], FILTER_VALIDATE_EMAIL)) {
            $checker_emails[] = $row['email'];
        }
    }
    
    error_log("Found " . count($checker_emails) . " checker emails for resubmission: " . implode(', ', $checker_emails));
    return $checker_emails;
}

function getSapLocationDetails($locationCode, $conn) {
    if (empty($locationCode)) {
        return ['description' => '', 'department' => ''];
    }
    
    $sql = "SELECT LocationDescription, Department FROM sap_loc_code WHERE LocationCode = ?";
    $stmt = sqlsrv_query($conn, $sql, [$locationCode]);
    
    if ($stmt !== false && $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        return [
            'description' => $row['LocationDescription'] ?? '',
            'department' => $row['Department'] ?? ''
        ];
    }
    
    return ['description' => '', 'department' => ''];
}
?>