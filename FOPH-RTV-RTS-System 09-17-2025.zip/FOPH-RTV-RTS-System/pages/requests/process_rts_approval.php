<?php
session_start();
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

// Check authentication
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit();
}

// Validate request
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['rts_id'], $_POST['action'], $_POST['role'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request data.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];
$username = $_SESSION['username'] ?? 'Unknown User';
$rts_id = (int)$_POST['rts_id'];
$action = $_POST['action'];
$requested_role = $_POST['role'];
$reason = $_POST['reason'] ?? null;

// Role validation
$allowed_roles = ['checker', 'approver', 'noter'];
if (!in_array($requested_role, $allowed_roles) || !in_array($action, ['approve', 'disapprove', 'cancel'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid role or action specified.']);
    exit();
}

// Define field mappings
$status_fields = ['checker' => 'checked_status', 'approver' => 'approved_status', 'noter' => 'noted_status'];
$by_fields = ['checker' => 'checked_by', 'approver' => 'approved_by', 'noter' => 'noted_by'];
$by_id_fields = ['checker' => 'checked_by_id', 'approver' => 'approved_by_id', 'noter' => 'noted_by_id'];
$at_fields = ['checker' => 'checked_at', 'approver' => 'approved_at', 'noter' => 'noted_at'];
$signature_fields = ['checker' => 'checked_by_signature_image', 'approver' => 'approved_by_signature_image', 'noter' => 'noted_by_signature_image'];

try {
    $db = new Connection();
    $conn = $db->link;
    
    if (!sqlsrv_begin_transaction($conn)) {
        throw new Exception("Failed to start transaction: " . print_r(sqlsrv_errors(), true));
    }

    // Get user data and form details in one optimized query
    $sql_get_data = "
        SELECT 
            u.e_signiture, 
            u.requestor_name,
            rf.control_no,
            rf.requestor_id,
            ru.email as requestor_email,
            ru.requestor_name as requestor_display_name,
            rf.created_at,
            rf.checked_status,
            rf.approved_status,
            rf.noted_status,
            rf.workflow_status
        FROM users u
        CROSS JOIN rts_forms rf
        LEFT JOIN users ru ON rf.requestor_id = ru.user_id
        WHERE u.user_id = ? AND rf.id = ?
    ";
    
    $stmt_data = sqlsrv_query($conn, $sql_get_data, [$user_id, $rts_id]);
    $form_data = sqlsrv_fetch_array($stmt_data, SQLSRV_FETCH_ASSOC);
    
    if (!$form_data) {
        throw new Exception("Form or user data not found.");
    }

    $e_signature_data = $form_data['e_signiture'];
    $approver_display_name = $form_data['requestor_name'] ?? $username;
    
    // Process action
    $new_status = 'pending';
    
    if ($action === 'approve') {
        $sql_update = buildApprovalUpdateSQL($requested_role, $status_fields, $by_fields, $by_id_fields, $at_fields, $signature_fields);
        
        $params = [
            [$approver_display_name, SQLSRV_PARAM_IN],
            [$user_id, SQLSRV_PARAM_IN],
            [$e_signature_data, SQLSRV_PARAM_IN, SQLSRV_PHPTYPE_STREAM(SQLSRV_ENC_BINARY), SQLSRV_SQLTYPE_VARBINARY('max')],
            [$rts_id, SQLSRV_PARAM_IN]
        ];

        $stmt = sqlsrv_prepare($conn, $sql_update, $params);

        if (!$stmt || !sqlsrv_execute($stmt) || sqlsrv_rows_affected($stmt) == 0) {
            throw new Exception("Failed to approve the request. It may have already been processed.");
        }

        $new_status = ($requested_role === 'checker') ? 'in-progress' : 'pending';
        
        // Check for completion (noter approval)
        if ($requested_role === 'noter') {
            $new_status = handleFinalApproval($conn, $rts_id, $form_data);
        }
        
    } elseif ($action === 'disapprove') {
        $sql_update = buildDisapprovalUpdateSQL($requested_role, $status_fields, $by_fields, $by_id_fields, $at_fields, $signature_fields);
        
        $params = [
            [$requested_role, SQLSRV_PARAM_IN],
            [$approver_display_name, SQLSRV_PARAM_IN],
            [$user_id, SQLSRV_PARAM_IN],
            [$e_signature_data, SQLSRV_PARAM_IN, SQLSRV_PHPTYPE_STREAM(SQLSRV_ENC_BINARY), SQLSRV_SQLTYPE_VARBINARY('max')],
            [$reason, SQLSRV_PARAM_IN],
            [$rts_id, SQLSRV_PARAM_IN]
        ];

        $stmt = sqlsrv_prepare($conn, $sql_update, $params);

        if (!$stmt || !sqlsrv_execute($stmt) || sqlsrv_rows_affected($stmt) == 0) {
            throw new Exception("Failed to disapprove the request.");
        }
        
        $new_status = 'disapproved';
        
    } elseif ($action === 'cancel') {
        $cancel_note = "
[Canceled by $approver_display_name] Reason: " . ($reason ?? 'No reason provided.');
        $sql_update = "UPDATE rts_forms SET workflow_status = 'Canceled', remark = ISNULL(remark, '') + ? WHERE id = ?";
        
        $stmt = sqlsrv_query($conn, $sql_update, [$cancel_note, $rts_id]);
        if (!$stmt || sqlsrv_rows_affected($stmt) == 0) {
            throw new Exception("Failed to cancel the request.");
        }
        
        $new_status = 'canceled';
    }

    if (!sqlsrv_commit($conn)) {
        throw new Exception("Failed to commit transaction: " . print_r(sqlsrv_errors(), true));
    }
    
    // REQUIREMENT: Send email notifications after successful database operations
    if ($action !== 'cancel' && !empty($form_data['requestor_email'])) {
        sendNotificationEmail($action, $form_data, $requested_role, $approver_display_name, $reason, $new_status);
    }

    echo json_encode([
        'success' => true,
        'message' => 'RTS request processed successfully.',
        'new_status' => $new_status
    ]);

} catch (Exception $e) {
    if (isset($conn)) {
        sqlsrv_rollback($conn);
    }
    error_log("RTS Approval Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An internal server error occurred: ' . $e->getMessage()]);
} finally {
    if (isset($db)) {
        $db->close();
    }
}

// Helper functions
function buildApprovalUpdateSQL($role, $status_fields, $by_fields, $by_id_fields, $at_fields, $signature_fields) {
    $status_field = $status_fields[$role];
    $by_field = $by_fields[$role];
    $by_id_field = $by_id_fields[$role];
    $at_field = $at_fields[$role];
    $signature_field = $signature_fields[$role];
    
    $sql = "UPDATE rts_forms SET 
                $status_field = 'Approved',
                $by_field = ?,
                $by_id_field = ?,
                $at_field = GETDATE(),
                $signature_field = ?";
    
    if ($role === 'checker') {
        $sql .= ", workflow_status = 'In-Progress'";
    }
    
    $sql .= " WHERE id = ? AND $status_field = 'Pending'";
    
    return $sql;
}

function buildDisapprovalUpdateSQL($role, $status_fields, $by_fields, $by_id_fields, $at_fields, $signature_fields) {
    $status_field = $status_fields[$role];
    $by_field = $by_fields[$role];
    $by_id_field = $by_id_fields[$role];
    $at_field = $at_fields[$role];
    $signature_field = $signature_fields[$role];
    
    return "UPDATE rts_forms SET 
                workflow_status = 'Disapproved',
                disapproved_by_role = ?,
                $status_field = 'Disapproved',
                $by_field = ?,
                $by_id_field = ?,
                $at_field = GETDATE(),
                $signature_field = ?,
                disapproval_reason = ?
            WHERE id = ? AND workflow_status <> 'Disapproved'";
}

function handleFinalApproval($conn, $rts_id, $form_data) {
    // Check if all approvals are complete
    $sql_check = "SELECT checked_status, approved_status, noted_status FROM rts_forms WHERE id = ?";
    $stmt_check = sqlsrv_query($conn, $sql_check, [$rts_id]);
    $status_data = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_ASSOC);
    
    if ($status_data && 
        $status_data['checked_status'] === 'Approved' && 
        $status_data['approved_status'] === 'Approved' && 
        $status_data['noted_status'] === 'Approved') {
        
        $sql_complete = "UPDATE rts_forms SET workflow_status = 'Completed' WHERE id = ?";
        sqlsrv_query($conn, $sql_complete, [$rts_id]);
        
        return 'completed';
    }
    
    return 'pending';
}

// REQUIREMENT: Send notification emails to original preparer (user)
function sendNotificationEmail($action, $form_data, $role, $approver_name, $reason, $new_status) {
    include_once APP_ROOT . '/includes/send_email.php';
    
    try {
        $recipient_email = [$form_data['requestor_email']];
        $control_no = $form_data['control_no'];
        $requestor_name = $form_data['requestor_display_name'];
        $date_submitted = $form_data['created_at']->format('Y-m-d');
        
        if ($action === 'approve') {
            if ($new_status === 'completed') {
                // REQUIREMENT: Full approval notification to original preparer
                sendUserFullyApprovedEmail($recipient_email, $control_no, $requestor_name, $date_submitted);
                error_log("Full approval notification sent to requestor for Control No: $control_no");
            } else {
                // REQUIREMENT: Approval notification to original preparer at every stage
                $next_step = getLocalNextApprovalStep($role);
                sendUserApprovalNotificationEmail($recipient_email, $control_no, $requestor_name, $date_submitted, $role, $approver_name, $next_step);
                error_log("Approval notification sent to requestor for Control No: $control_no (Role: $role)");
            }
        } elseif ($action === 'disapprove') {
            // REQUIREMENT: Disapproval notification to original preparer at every stage
            sendUserDisapprovalNotificationEmail($recipient_email, $control_no, $requestor_name, $date_submitted, $reason ?? 'No reason provided', $role, $approver_name);
            error_log("Disapproval notification sent to requestor for Control No: $control_no (Role: $role)");
        }
        
    } catch (Exception $e) {
        error_log("Email notification error for Control No: {$form_data['control_no']}. Error: " . $e->getMessage());
    }
}

// LOCAL function to avoid conflicts with send_email.php
function getLocalNextApprovalStep($current_role) {
    switch ($current_role) {
        case 'checker': return 'For Approval';
        case 'approver': return 'For Noting';
        default: return 'In Process';
    }
}
?>