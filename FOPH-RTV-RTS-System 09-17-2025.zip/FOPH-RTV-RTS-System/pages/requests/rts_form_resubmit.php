<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/includes/functions.php';
require_once APP_ROOT . '/assets/db/connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/pages/requests/disapproved_requests.php');
    exit();
}

$rts_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Get RTS details including disapproval information
$rtsData = getRTSDetailsForResubmission($rts_id, $user_id);

if (!$rtsData['success']) {
    $_SESSION['error_message'] = $rtsData['message'];
    header('Location: ' . BASE_URL . '/pages/requests/disapproved_requests.php');
    exit();
}

$rts = $rtsData['rts'];
$items = $rtsData['items'];
$departments = $rtsData['departments'];
$sap_locations = $rtsData['sap_locations'];
$signature_base64 = $rtsData['signature_base64'];
$original_material_statuses = $rtsData['original_material_statuses'] ?? [];

// Keep the original control number
$control_no = $rts['control_no'];

// Parse SAP location data
$sap_data = parseSAPLocationData($rts);
?>

<style>
/* Enhanced A4 Print Optimized Styles with Wider Layout - Form Version */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 0;
    font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f8f9fa;
}

.wrapper {
    min-height: 100vh;
}

.main-panel {
    width: 100%;
}

.content {
    padding: 20px;
}

.container-fluid {
    max-width: 1400px;
    margin: 0 auto;
}

/* Card Styling */
.card {
    background: white;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0,0,0,0.1);
    border: none;
    margin-bottom: 20px;
}

/* Enhanced Document Header - Responsive Design */
.card-header {
    background: white;
    color: #1a1a1a;
    padding: 25px 30px;
    border-radius: 8px 8px 0 0;
    border: none;
    border-bottom: 3px solid #264c7eff;
    position: relative;
}

.document-header-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 25px;
    flex-wrap: wrap;
}

.company-section {
    display: flex;
    flex-direction: column; /* Changed to column to stack items */
    align-items: flex-start;
    gap: 8px; 
    flex: 1;
}

.company-logo {
    max-height: 45px;
    width: auto;
    flex-shrink: 0;
}

.company-details {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.company-name {
    font-size: 12pt;
    font-weight: 700;
    color: #1a1a1a;
    line-height: 1.2;
}

.company-subtitle {
    font-size: 10pt;
    color: #666;
    font-weight: 400;
    line-height: 1.3;
    max-width: 350px;
}

/* Control Number Box - Smaller and Responsive */
.control-number-box {
    border: 2px solid #264c7eff;
    padding: 8px 12px;
    background: #fff;
    border-radius: 4px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    flex-shrink: 0;
    min-width: 250px; /* Increased length */
    max-width: 300px; /* Increased length */
}

.control-number-box .label {
    font-size: 8pt;
    color: #666;
    font-weight: 600;
    text-transform: uppercase;
    margin-bottom: 3px;
    display: block;
    letter-spacing: 0.3px;
    text-align: center;
}

#control_no {
    font-family: 'Courier New', monospace;
    font-weight: 700;
    font-size: 11pt;
    text-align: center;
    background: transparent;
    border: none;
    color: #264c7eff;
    width: 100%;
    padding: 2px 0;
    outline: none;
}

/* Document Title Section */
.document-title-section {
    text-align: center;
    margin: 15px 0 5px 0;
}

.card-title {
    font-size: 22pt;
    font-weight: 700;
    color: #1a1a1a;
    margin: 0;
    letter-spacing: 0.5px;
    text-transform: uppercase;
    line-height: 1.2;
}

.card-header .subtitle {
    color: #666;
    font-size: 11pt;
    font-weight: 400;
    margin-top: 5px;
    line-height: 1.3;
}

/* Card Body */
.card-body {
    padding: 30px;
    background: white;
}

/* Disapproval Alert */
.disapproval-alert {
    background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
    border: 2px solid #ffc107;
    color: #856404;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 30px;
    box-shadow: 0 4px 8px rgba(255, 193, 7, 0.2);
}

.disapproval-alert h5 {
    margin-top: 0;
    color: #856404;
    font-weight: 600;
    font-size: 14pt;
}

.disapproval-alert i {
    margin-right: 8px;
    color: #dc3545;
}

/* Form Sections */
.form-section {
    margin-bottom: 30px;
    page-break-inside: avoid;
}

.section-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-left: 4px solid #264c7eff;
    padding: 12px 20px;
    margin-bottom: 20px;
    font-weight: 600;
    font-size: 14pt;
    color: #2c3e50;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    border-radius: 0 4px 4px 0;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.section-header i {
    margin-right: 8px;
    color: #264c7eff;
}

/* Form Controls */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    font-size: 11pt;
    font-weight: 600;
    color: #495057;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    margin-bottom: 8px;
    display: block;
    border-bottom: 1px solid #dee2e6;
    padding-bottom: 3px;
}

.form-control {
    border: 1px solid #ced4da;
    border-radius: 4px;
    padding: 10px 12px;
    font-size: 11pt;
    color: #495057;
    background-color: white;
    transition: all 0.15s ease-in-out;
    font-family: 'Inter', sans-serif;
}

.form-control:focus {
    border-color: #264c7eff;
    outline: none;
    box-shadow: 0 0 0 2px rgba(38, 76, 126, 0.25);
    background-color: white;
}

.form-control::placeholder {
    color: #6c757d;
    font-style: italic;
}

.form-control:disabled {
    background-color: #f8f9fa;
    border-color: #e9ecef;
    color: #6c757d;
    cursor: not-allowed;
}

/* Select Controls */
select.form-control {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3e%3cpath fill='%23343a40' d='m2 0-2 2h4zm0 5 2-2h-4z'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right 0.75rem center;
    background-size: 16px 12px;
    padding-right: 2.25rem;
}

/* Custom Checkbox Styling */
.custom-control {
    position: relative;
    display: block;
    min-height: 1.5rem;
    padding-left: 2rem;
    margin-bottom: 8px;
}

.custom-control-input {
    position: absolute;
    z-index: -1;
    opacity: 0;
}

.custom-control-label {
    position: relative;
    margin-bottom: 0;
    cursor: pointer;
    font-size: 11pt;
    color: #495057;
    line-height: 1.5;
    font-weight: 400;
}

.custom-control-label::before {
    position: absolute;
    top: 0.25rem;
    left: -2rem;
    display: block;
    width: 1.25rem;
    height: 1.25rem;
    pointer-events: none;
    content: "";
    background-color: #fff;
    border: 2px solid #ced4da;
    border-radius: 0.25rem;
    transition: all 0.15s ease-in-out;
}

.custom-control-label::after {
    position: absolute;
    top: 0.25rem;
    left: -2rem;
    display: block;
    width: 1.25rem;
    height: 1.25rem;
    content: "";
    background: no-repeat 50% / 60% 60%;
}

.custom-control-input:checked ~ .custom-control-label::before {
    color: #fff;
    border-color: #264c7eff;
    background-color: #264c7eff;
}

.custom-control-input:checked ~ .custom-control-label::after {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23fff' d='m6.564.75-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3e");
}

.custom-control-input:disabled ~ .custom-control-label {
    color: #6c757d;
    opacity: 0.6;
}

.custom-control-input:disabled ~ .custom-control-label::before {
    background-color: #e9ecef;
    border-color: #adb5bd;
}

/* Field Grid */
.field-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 25px;
    margin-bottom: 20px;
}

.checkbox-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

/* SAP Location Table */
.sap-location-table {
    border: 1px solid #dee2e6;
    border-radius: 6px;
    overflow: hidden;
    background: white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.sap-location-table table {
    width: 100%;
    border-collapse: collapse;
    margin: 0;
}

.sap-location-table th {
    background: #f8f9fa;
    padding: 15px;
    text-align: center;
    font-weight: 600;
    color: #495057;
    border: none;
    border-bottom: 1px solid #dee2e6;
    text-transform: uppercase;
    letter-spacing: 0.2px;
    font-size: 12pt;
}

.sap-location-table td {
    background: #ffffff;
    padding: 15px;
    vertical-align: middle;
    border: none;
    text-align: center;
}

/* Approval Matrix */
.approval-matrix {
    border: 1px solid #dee2e6;
    border-radius: 6px;
    overflow: hidden;
    margin-top: 15px;
    background: white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.approval-matrix table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10pt;
    margin: 0;
}

.approval-matrix th {
    background: #f8f9fa;
    padding: 15px;
    text-align: center;
    font-weight: 600;
    color: #495057;
    border-right: 1px solid #dee2e6;
    text-transform: uppercase;
    letter-spacing: 0.2px;
    font-size: 11pt;
}

.approval-matrix td {
    padding: 20px 15px;
    text-align: center;
    vertical-align: middle;
    border-right: 1px solid #dee2e6;
    border-bottom: 1px solid #dee2e6;
    min-height: 120px;
}

.approval-matrix th:last-child,
.approval-matrix td:last-child {
    border-right: none;
}

.signature-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 100px;
    justify-content: space-between;
}

.signature-container img {
    max-width: 120px;
    max-height: 60px;
    margin-bottom: 10px;
    border: 1px solid #e9ecef;
    border-radius: 4px;
    padding: 5px;
    background: white;
}

.signature-container span {
    font-weight: 500;
    color: #495057;
    font-size: 11pt;
    text-align: center;
}

/* Material Details Table */
.materials-section {
    margin-top: 20px;
}

.materials-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding: 0 5px;
}

.materials-header h5 {
    margin: 0;
    color: #495057;
    font-weight: 600;
}

/* Material Count Indicator */
.material-count-indicator {
    background: #e3f2fd;
    border: 1px solid #2196f3;
    border-radius: 4px;
    padding: 8px 15px;
    margin-bottom: 10px;
    font-size: 11pt;
    color: #1565c0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.material-count-indicator i {
    color: #2196f3;
}

.material-count-indicator.no-records {
    background: #fff3cd;
    border-color: #ffc107;
    color: #856404;
}

.material-count-indicator.no-records i {
    color: #ffc107;
}

#material_details_table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10pt;
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    overflow: hidden;
}

#material_details_table th {
    background: #f8f9fa;
    padding: 12px 8px;
    text-align: center;
    font-weight: 600;
    color: #495057;
    border: 1px solid #dee2e6;
    text-transform: uppercase;
    letter-spacing: 0.1px;
    font-size: 10pt;
    line-height: 1.2;
}

#material_details_table td {
    padding: 8px;
    border: 1px solid #dee2e6;
    text-align: left;
    vertical-align: middle;
    background: white;
}
#material_details_table input {
    border: 1px solid #ced4da;
    border-radius: 3px;
    padding: 6px 8px;
    font-size: 10pt;
    width: 100%;
    background: white;
    transition: border-color 0.15s ease-in-out;
}

#material_details_table input:focus {
    border-color: #264c7eff;
    outline: none;
    box-shadow: 0 0 0 1px rgba(38, 76, 126, 0.25);
}

#material_details_table input::placeholder {
    color: #6c757d;
    font-style: italic;
}

#material_details_table tbody tr:nth-child(even) {
    background: #f9f9f9;
}

#material_details_table tbody tr:hover {
    background: #e3f2fd;
}

/* Row with data styling */
#material_details_table tbody tr.has-data {
    background: #f0f8f0 !important;
    border-left: 3px solid #28a745;
}

#material_details_table tbody tr.has-data:hover {
    background: #e8f5e8 !important;
}

/* Button Styling */
.btn {
    border-radius: 4px;
    font-size: 11pt;
    font-weight: 500;
    padding: 10px 20px;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    transition: all 0.2s ease;
    border: none;
    cursor: pointer;
}

.btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.btn-primary {
    background: linear-gradient(135deg, #264c7eff 0%, #1a3a5c 100%);
    color: white;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #1a3a5c 0%, #0f2a42 100%);
    color: white;
}

.btn-secondary {
    background: #6c757d;
    color: white;
}

.btn-secondary:hover {
    background: #5a6268;
    color: white;
}

.btn-success {
    background: #28a745;
    color: white;
    font-size: 13pt;
    padding: 12px 30px;
}

.btn-success:hover {
    background: #218838;
    color: white;
}

.btn-danger {
    background: #dc3545;
    color: white;
}

.btn-danger:hover {
    background: #c82333;
    color: white;
}

.btn-sm {
    font-size: 9pt;
    padding: 5px 10px;
}

.btn-lg {
    font-size: 14pt;
    padding: 15px 40px;
}

/* Modal Styling */
.modal-content {
    border-radius: 8px;
    border: none;
    box-shadow: 0 16px 32px rgba(0,0,0,0.15);
}

.modal-header {
    background: linear-gradient(135deg, #264c7eff 0%, #1a3a5c 100%);
    color: white;
    border-bottom: none;
    border-radius: 8px 8px 0 0;
    padding: 20px 25px;
}

.modal-title {
    color: white;
    font-weight: 600;
    font-size: 16pt;
}

.modal-header .close {
    color: white;
    opacity: 0.8;
    font-size: 20pt;
}

.modal-header .close:hover {
    opacity: 1;
    color: white;
}

.modal-body {
    padding: 25px;
    max-height: 70vh;
    overflow-y: auto;
}

.modal-footer {
    border-top: 1px solid #e9ecef;
    padding: 20px 25px;
    background: #f8f9fa;
}

/* Additional Form Specific Styles */
.submit-section {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 8px;
    padding: 30px;
    text-align: center;
    margin-top: 30px;
    border: 1px solid #dee2e6;
}

.table-responsive {
    border-radius: 6px;
    overflow: hidden;
    border: 1px solid #dee2e6;
    background: white;
}

/* Status indicators */
.form-status {
    background: #e3f2fd;
    border: 1px solid #2196f3;
    border-radius: 6px;
    padding: 15px 20px;
    margin: 20px 0;
    color: #1565c0;
    text-align: center;
    font-weight: 500;
}

/* Loading states */
.btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

.btn:disabled:hover {
    transform: none;
    box-shadow: none;
}

/* Validation styling */
.is-invalid {
    border-color: #dc3545;
}

.is-invalid:focus {
    border-color: #dc3545;
    box-shadow: 0 0 0 2px rgba(220, 53, 69, 0.25);
}

.invalid-feedback {
    display: block;
    width: 100%;
    margin-top: 5px;
    font-size: 10pt;
    color: #dc3545;
}

.readonly-field {
    background-color: #f8f9fa !important;
    border-color: #e9ecef !important;
    color: #6c757d !important;
    cursor: not-allowed !important;
}

/* Responsive Design - same as rts_form.php */
@media (max-width: 1024px) and (min-width: 769px) {
    .card-header {
        padding: 20px 25px;
    }
    
    .document-header-content {
        margin-bottom: 20px;
    }
    
    .company-section {
        gap: 8px;
    }
    
    .company-logo {
        max-height: 40px;
    }
    
    .company-name {
        font-size: 13pt;
    }
    
    .company-subtitle {
        font-size: 9pt;
        max-width: 300px;
    }
    
    .card-title {
        font-size: 20pt;
    }
    
    .card-header .subtitle {
        font-size: 10pt;
    }
    
    .control-number-box {
        min-width: 180px;
        max-width: 220px;
        padding: 7px 10px;
    }
    
    #control_no {
        font-size: 10pt;
    }

    .field-grid {
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
    }

    .checkbox-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) and (min-width: 481px) {
    .card-header {
        padding: 18px 20px;
    }
    
    .document-header-content {
        flex-direction: column;
        align-items: center;
        gap: 15px;
        margin-bottom: 18px;
    }
    
    .company-section {
        width: 100%;
        justify-content: center;
        text-align: center;
        flex-direction: column;
        align-items: center;
        gap: 6px;
    }
    
    .company-details {
        align-items: center;
        text-align: center;
    }
    
    .company-logo {
        max-height: 38px;
    }
    
    .company-name {
        font-size: 12pt;
    }
    
    .company-subtitle {
        font-size: 9pt;
        max-width: 100%;
        text-align: center;
    }
    
    .control-number-box {
        min-width: 160px;
        max-width: 180px;
        padding: 6px 10px;
    }
    
    .control-number-box .label {
        font-size: 7pt;
    }
    
    #control_no {
        font-size: 9pt;
    }
    
    .card-title {
        font-size: 18pt;
    }
    
    .card-header .subtitle {
        font-size: 9pt;
    }

    .card-body {
        padding: 20px 15px;
    }

    .field-grid {
        grid-template-columns: 1fr;
        gap: 15px;
    }

    .materials-header {
        flex-direction: column;
        gap: 10px;
        align-items: stretch;
    }

    #material_details_table {
        font-size: 9pt;
    }

    #material_details_table th,
    #material_details_table td {
        padding: 6px 4px;
    }

    .btn-lg {
        font-size: 12pt;
        padding: 12px 25px;
    }
}

@media (max-width: 480px) {
    .card-header {
        padding: 15px;
    }
    
    .document-header-content {
        flex-direction: column;
        align-items: center;
        gap: 12px;
        margin-bottom: 15px;
    }
    
    .company-section {
        width: 100%;
        justify-content: center;
        text-align: center;
        flex-direction: column;
        align-items: center;
        gap: 4px;
    }
    
    .company-details {
        align-items: center;
        text-align: center;
        gap: 2px;
    }
    
    .company-logo {
        max-height: 35px;
    }
    
    .company-name {
        font-size: 11pt;
        line-height: 1.1;
    }
    
    .company-subtitle {
        font-size: 8pt;
        max-width: 100%;
        text-align: center;
        line-height: 1.2;
    }
    
    .control-number-box {
        min-width: 140px;
        max-width: 160px;
        padding: 5px 8px;
    }
    
    .control-number-box .label {
        font-size: 7pt;
        margin-bottom: 2px;
    }
    
    #control_no {
        font-size: 9pt;
        padding: 1px 0;
    }
    
    .document-title-section {
        margin: 10px 0;
    }
    
    .card-title {
        font-size: 16pt;
        letter-spacing: 0.3px;
    }
    
    .card-header .subtitle {
        font-size: 8pt;
        margin-top: 3px;
    }

    .content {
        padding: 10px;
    }
}

@media (max-width: 320px) {
    .card-header {
        padding: 12px;
    }
    
    .company-logo {
        max-height: 30px;
    }
    
    .company-name {
        font-size: 10pt;
    }
    
    .company-subtitle {
        font-size: 7pt;
    }
    
    .control-number-box {
        min-width: 120px;
        max-width: 140px;
        padding: 4px 6px;
    }
    
    .control-number-box .label {
        font-size: 6pt;
    }
    
    #control_no {
        font-size: 8pt;
        padding: 1px 0;
    }
    
    .card-title {
        font-size: 14pt;
    }
    
    .card-header .subtitle {
        font-size: 7pt;
    }
}

@media (min-width: 1200px) {
    .card-header {
        padding: 30px 35px;
    }
    
    .company-section {
        gap: 8px;
    }
    
    .company-logo {
        max-height: 50px;
    }
    
    .company-name {
        font-size: 15pt;
    }
    
    .company-subtitle {
        font-size: 11pt;
        max-width: 400px;
    }
    
    .control-number-box {
        min-width: 350px;
        max-width: 360px;
        padding: 10px 15px;
    }
    
    .control-number-box .label {
        font-size: 9pt;
    }
    
    #control_no {
        font-size: 12pt;
    }
    
    .card-title {
        font-size: 24pt;
    }
    
    .card-header .subtitle {
        font-size: 12pt;
    }
}

/* Print optimizations */
@media print {
    .btn, .modal {
        display: none !important;
    }
    
    .card {
        box-shadow: none;
        border: 1px solid #000;
    }
    
    .section-header {
        break-after: avoid;
    }
    
    .form-section {
        break-inside: avoid;
    }

    .card-header {
        padding: 15mm;
        border-bottom: 2pt solid #264c7eff;
    }
    
    .document-header-content {
        margin-bottom: 10mm;
    }
    
    .company-logo {
        max-height: 12mm;
    }
    
    .company-name {
        font-size: 12pt;
    }
    
    .company-subtitle {
        font-size: 9pt;
    }
    
    .control-number-box {
        border: 1pt solid #264c7eff;
        padding: 3mm;
        min-width: 60mm;
    }
    
    .card-title {
        font-size: 18pt;
    }
}

/* Accessibility Improvements */
@media (prefers-reduced-motion: reduce) {
    * {
        transition: none !important;
        animation: none !important;
    }
}

/* High Contrast Mode */
@media (prefers-contrast: high) {
    .control-number-box {
        border-width: 3px;
        border-color: #000;
    }
    
    .company-name {
        color: #000;
    }
    
    .card-title {
        color: #000;
    }
}

/* Focus States for Better Accessibility */
.control-number-box:focus-within {
    outline: 2px solid #264c7eff;
    outline-offset: 2px;
}

#control_no:focus {
    outline: none;
}

/* Hover Effects for Interactive Elements */
.company-section:hover .company-logo {
    transform: scale(1.02);
    transition: transform 0.2s ease;
}

/* Loading State */
.card-header.loading {
    opacity: 0.8;
    pointer-events: none;
}

.card-header.loading::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Enhanced Modal Sizing - Custom Breakpoints */
.modal-xl-custom {
    max-width: 95vw !important;
    width: 95vw !important;
}

/* Enhanced Modal Content */
#materialDetailsModal .modal-content {
    height: 90vh;
    max-height: 90vh;
    display: flex;
    flex-direction: column;
}

#materialDetailsModal .modal-body {
    flex: 1;
    overflow: hidden;
    padding: 20px 25px;
    display: flex;
    flex-direction: column;
}

/* Custom Table Responsive Container */
.table-responsive-custom {
    flex: 1;
    overflow: auto;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    background: white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

/* Enhanced Material Table Styling */
.material-table-enhanced {
    width: 100%;
    border-collapse: collapse;
    font-size: 11pt;
    background: white;
    margin: 0;
    min-width: 1600px; /* Minimum width for proper display */
}

.material-table-enhanced th {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 15px 12px;
    text-align: center;
    font-weight: 600;
    color: #495057;
    border: 1px solid #dee2e6;
    text-transform: uppercase;
    letter-spacing: 0.2px;
    font-size: 10pt;
    line-height: 1.3;
    position: sticky;
    top: 0;
    z-index: 10;
    white-space: nowrap;
}

.material-table-enhanced td {
    padding: 12px;
    border: 1px solid #dee2e6;
    text-align: center;
    vertical-align: middle;
    background: white;
}

/* Enhanced Input Field Styling in Modal */
.material-table-enhanced input {
    border: 2px solid #e9ecef;
    border-radius: 6px;
    padding: 10px 12px;
    font-size: 11pt;
    width: 100%;
    background: white;
    transition: all 0.2s ease-in-out;
    min-height: 42px;
}

.material-table-enhanced input:focus {
    border-color: #264c7eff;
    outline: none;
    box-shadow: 0 0 0 3px rgba(38, 76, 126, 0.15);
    background: #fff;
    transform: scale(1.02);
}

.material-table-enhanced input::placeholder {
    color: #6c757d;
    font-style: italic;
    font-size: 10pt;
}

/* Enhanced Row Styling */
.material-table-enhanced tbody tr {
    transition: all 0.2s ease;
}

.material-table-enhanced tbody tr:nth-child(even) {
    background: #f8f9fa;
}

.material-table-enhanced tbody tr:hover {
    background: #e3f2fd !important;
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.material-table-enhanced tbody tr.has-data {
    background: linear-gradient(135deg, #f0f8f0 0%, #e8f5e8 100%) !important;
    border-left: 4px solid #28a745;
}

.material-table-enhanced tbody tr.has-data:hover {
    background: linear-gradient(135deg, #e8f5e8 0%, #d4edda 100%) !important;
}

/* Enhanced Button Styling in Modal */
.material-table-enhanced .btn-danger {
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 10pt;
    transition: all 0.2s ease;
}

.material-table-enhanced .btn-danger:hover {
    transform: scale(1.1);
    box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
}

/* Modal Footer Enhancement */
#materialDetailsModal .modal-footer {
    border-top: 2px solid #e9ecef;
    padding: 20px 25px;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 0 0 8px 8px;
}

/* Row Number Styling */
.material-table-enhanced td:first-child {
    background: #f8f9fa;
    font-weight: 600;
    color: #495057;
    border-right: 2px solid #dee2e6;
    position: sticky;
    left: 0;
    z-index: 5;
}

/* Responsive Breakpoints */

/* Large Desktop (1200px+) */
@media (min-width: 1200px) {
    .modal-xl-custom {
        max-width: 90vw !important;
        width: 90vw !important;
    }
    
    .material-table-enhanced {
        min-width: 1800px;
    }
    
    .material-table-enhanced input {
        padding: 12px 15px;
        font-size: 12pt;
        min-height: 46px;
    }
}

/* Standard Desktop (992px - 1199px) */
@media (max-width: 1199px) and (min-width: 992px) {
    .modal-xl-custom {
        max-width: 95vw !important;
        width: 95vw !important;
    }
    
    .material-table-enhanced {
        min-width: 1400px;
    }
    
    .material-table-enhanced th,
    .material-table-enhanced td {
        padding: 10px 8px;
    }
}

/* Tablet Landscape (768px - 991px) */
@media (max-width: 991px) and (min-width: 768px) {
    .modal-xl-custom {
        max-width: 98vw !important;
        width: 98vw !important;
    }
    
    #materialDetailsModal .modal-content {
        height: 95vh;
    }
    
    .material-table-enhanced {
        min-width: 1200px;
        font-size: 10pt;
    }
    
    .material-table-enhanced th {
        padding: 12px 6px;
        font-size: 9pt;
    }
    
    .material-table-enhanced td {
        padding: 8px 6px;
    }
    
    .material-table-enhanced input {
        padding: 8px 10px;
        font-size: 10pt;
        min-height: 38px;
    }
}

/* Mobile Landscape & Tablet Portrait (481px - 767px) */
@media (max-width: 767px) and (min-width: 481px) {
    .modal-xl-custom {
        max-width: 100vw !important;
        width: 100vw !important;
        margin: 0;
    }
    
    #materialDetailsModal .modal-content {
        height: 100vh;
        border-radius: 0;
        border: none;
    }
    
    .material-table-enhanced {
        min-width: 1000px;
        font-size: 9pt;
    }
    
    .material-table-enhanced th {
        padding: 10px 4px;
        font-size: 8pt;
    }
    
    .material-table-enhanced td {
        padding: 6px 4px;
    }
    
    .material-table-enhanced input {
        padding: 6px 8px;
        font-size: 9pt;
        min-height: 34px;
    }
    
    #materialDetailsModal .modal-footer {
        padding: 15px 20px;
    }
    
    #materialDetailsModal .modal-footer .d-flex {
        flex-direction: column;
        gap: 15px;
        align-items: stretch;
    }
    
    #materialDetailsModal .modal-footer .d-flex > div {
        justify-content: center;
    }
}

/* Mobile Portrait (320px - 480px) */
@media (max-width: 480px) {
    .modal-xl-custom {
        max-width: 100vw !important;
        width: 100vw !important;
        margin: 0;
    }
    
    #materialDetailsModal .modal-content {
        height: 100vh;
        border-radius: 0;
    }
    
    #materialDetailsModal .modal-body {
        padding: 15px;
    }
    
    .material-table-enhanced {
        min-width: 800px;
        font-size: 8pt;
    }
    
    .material-table-enhanced th {
        padding: 8px 3px;
        font-size: 7pt;
        line-height: 1.2;
    }
    
    .material-table-enhanced td {
        padding: 5px 3px;
    }
    
    .material-table-enhanced input {
        padding: 5px 6px;
        font-size: 8pt;
        min-height: 30px;
    }
    
    .material-table-enhanced .btn-danger {
        padding: 4px 6px;
        font-size: 8pt;
    }
}

/* Scrollbar Styling for Table */
.table-responsive-custom::-webkit-scrollbar {
    width: 12px;
    height: 12px;
}

.table-responsive-custom::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 6px;
}

.table-responsive-custom::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 6px;
    transition: background 0.2s ease;
}

.table-responsive-custom::-webkit-scrollbar-thumb:hover {
    background: #264c7eff;
}

/* Loading States for Modal */
#materialDetailsModal.loading .modal-body {
    opacity: 0.7;
    pointer-events: none;
}

/* Enhanced Focus States */
.material-table-enhanced input:focus + .form-control {
    transform: scale(1.02);
}

/* Print Optimization for Modal */
@media print {
    #materialDetailsModal {
        display: none !important;
    }
}
</style>

<?php include INCLUDES_PATH . '/header.php'; ?>
<div class="wrapper">
    <?php include INCLUDES_PATH . '/sidebar.php'; ?>
    <div class="main-panel">
        <?php include INCLUDES_PATH . '/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <!-- Document Header-->
                            <div class="card-header">
                                <div class="document-header-content">
                                    <div class="company-section">
                                        <img src="<?php echo BASE_URL; ?>/assets/img/logo_black.png" alt="Fujifilm Logo" class="company-logo">
                                        <div class="company-details">
                                            <div class="company-name"><strong>Fujifilm Optics Philippines Inc.</strong></div>
                                        </div>
                                    </div>
                                    
                                    <div class="control-number-box">
                                        <span class="label">Control No.</span>
                                        <input type="text" id="control_no" name="control_no" value="<?= htmlspecialchars($control_no) ?>" readonly>
                                    </div>
                                </div>

                                <div class="document-title-section">
                                    <h1 class="card-title">Return / Transfer Slip</h1>
                                    <div class="subtitle">Resubmission Form</div>
                                </div>
                            </div>
                            
                            <div class="card-body">
                                <!-- Disapproval Information Alert -->
                                <div class="disapproval-alert">
                                    <h5><i class="fa fa-exclamation-triangle"></i> Disapproval Information</h5>
                                    <p><strong>Disapproved by:</strong> <?= htmlspecialchars(ucfirst($rts['disapproved_by_role'])) ?></p>
                                    <p><strong>Reason:</strong> <?= htmlspecialchars($rts['disapproval_reason']) ?></p>
                                    <p class="mb-0"><small>Please review and update the form based on the disapproval reason before resubmitting.</small></p>
                                </div>

                                <form id="rtsResubmitForm" method="POST" action="process_rts_form_resubmit.php">
                                    <input type="hidden" name="original_id" value="<?php echo $rts_id; ?>">
                                    <input type="hidden" name="control_no" value="<?php echo htmlspecialchars($control_no); ?>">
                                    <input type="hidden" name="requestor_id" value="<?php echo $_SESSION['user_id']; ?>">
                                    <input type="hidden" name="requestor_name" value="<?php echo htmlspecialchars($_SESSION['username']); ?>">
                                    <input type="hidden" name="requestor_department" value="<?php echo htmlspecialchars($rts['requestor_department']); ?>">
                                    <input type="hidden" name="resubmission_count" value="<?php echo ($rts['resubmission_count'] ?? 0) + 1; ?>">

                                    <!-- Material Classification Section -->
                                    <div class="form-section">
                                        <div class="section-header">
                                            <i class="fas fa-boxes"></i> Material Classification
                                        </div>
                                        <div class="checkbox-grid">
                                            <div class="form-group">
                                                <label>Material Type</label>
                                                <?php 
                                                $material_types = explode(', ', $rts['material_type']);
                                                ?>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="rawMaterial" 
                                                           name="material_type[]" value="Raw Material" 
                                                           <?= in_array('Raw Material', $material_types) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="rawMaterial">Raw Material</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="packagingMaterial" 
                                                           name="material_type[]" value="Packaging Material" 
                                                           <?= in_array('Packaging Material', $material_types) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="packagingMaterial">Packaging Material</label>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Material Status</label>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input material-status-checkbox" 
                                                           id="good" name="material_status[]" value="Good"
                                                           <?= in_array('Good', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="good">Good</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input material-status-checkbox" 
                                                           id="materialDefect" name="material_status[]" value="Material Defect"
                                                           <?= in_array('Material Defect', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="materialDefect">Material Defect</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input material-status-checkbox" 
                                                           id="humanError" name="material_status[]" value="Human Error"
                                                           <?= in_array('Human Error', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="humanError">Human Error</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input material-status-checkbox" 
                                                           id="endOfLife" name="material_status[]" value="EOL"
                                                           <?= in_array('EOL', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="endOfLife">End of Life (EOL)</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input material-status-checkbox" 
                                                           id="othersNoGood" name="material_status[]" value="NG/Others"
                                                           <?= in_array('NG/Others', $original_material_statuses) ? 'checked' : '' ?>>
                                                    <label class="custom-control-label" for="othersNoGood">NG/Others</label>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Judgement</label>
                                                <?php 
                                                $judgements = explode(', ', $rts['judgement']);
                                                ?>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input judgement-checkbox" 
                                                           id="scrapdisposal" name="judgement[]" value="Scrap/Disposal"
                                                           <?= in_array('Scrap/Disposal', $judgements) ? 'checked' : '' ?> disabled>
                                                    <label class="custom-control-label" for="scrapdisposal">Scrap/Disposal</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input judgement-checkbox" 
                                                           id="rtv" name="judgement[]" value="RTV"
                                                           <?= in_array('RTV', $judgements) ? 'checked' : '' ?> disabled>
                                                    <label class="custom-control-label" for="rtv">Return to Vendor</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input judgement-checkbox" 
                                                           id="hold" name="judgement[]" value="Hold"
                                                           <?= in_array('Hold', $judgements) ? 'checked' : '' ?> disabled>
                                                    <label class="custom-control-label" for="hold">Hold</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input judgement-checkbox" 
                                                           id="transfertogood" name="judgement[]" value="Transfer to Good"
                                                           <?= in_array('Transfer to Good', $judgements) ? 'checked' : '' ?> disabled>
                                                    <label class="custom-control-label" for="transfertogood">Transfer to Good</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- SAP Location Section -->
                                    <div class="form-section">
                                        <div class="section-header">
                                            <i class="fas fa-map-marker-alt"></i> SAP Location Code
                                        </div>
                                        <div class="sap-location-table">
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th style="width: 50%;">From Location</th>
                                                        <th style="width: 50%;">To Location</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <select class="form-control" name="sap_location[from]" id="sapLocationFrom">
                                                                <option value="" disabled>Select From Location</option>
                                                                <?php foreach ($sap_locations as $location): ?>
                                                                    <option value="<?php echo htmlspecialchars($location['LocationCode']); ?>"
                                                                        <?= $sap_data['from']['code'] == $location['LocationCode'] ? 'selected' : '' ?>>
                                                                        <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                    </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select class="form-control" name="sap_location[to]" id="sapLocationTo">
                                                                <option value="" disabled>Select To Location</option>
                                                                <?php foreach ($sap_locations as $location): ?>
                                                                    <option value="<?php echo htmlspecialchars($location['LocationCode']); ?>"
                                                                        <?= $sap_data['to']['code'] == $location['LocationCode'] ? 'selected' : '' ?>>
                                                                        <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                    </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <!-- Additional Information Section -->
                                    <div class="form-section">
                                        <div class="section-header">
                                            <i class="fas fa-info-circle"></i> Additional Information
                                        </div>
                                        <div class="field-grid">
                                            <div class="form-group">
                                                <label for="details">Details under others status</label>
                                                <textarea class="form-control" id="details" name="details" rows="4"
                                                          placeholder="Enter additional details..." 
                                                          <?= empty($rts['details']) && empty($original_material_statuses) ? 'disabled' : '' ?>><?= htmlspecialchars($rts['details'] ?? '') ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="remarks">Remarks</label>
                                                <textarea name="remark" id="remark" class="form-control" rows="4"
                                                          placeholder="Enter remarks..."><?= htmlspecialchars($rts['remark'] ?? '') ?></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Form Details Section -->
                                    <div class="form-section">
                                        <div class="section-header">
                                            <i class="fas fa-calendar-alt"></i> Model & Department Details
                                        </div>
                                        <div class="field-grid">
                                            <div class="form-group">
                                                <label for="return_date">Return Date</label>
                                                <input type="date" class="form-control" id="return_date" name="return_date"
                                                       value="<?= $rts['return_date'] ? date('Y-m-d', strtotime($rts['return_date']->format('Y-m-d'))) : '' ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="department">Department</label>
                                                <input type="text" class="form-control readonly-field" id="department" name="department" 
                                                    value="<?php echo htmlspecialchars($rts['requestor_department']); ?>" readonly>
                                                <!-- Hidden field to ensure the value is always submitted -->
                                                <input type="hidden" name="department_backup" value="<?php echo htmlspecialchars($rts['requestor_department']); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="model">Model</label>
                                                <input type="text" class="form-control" id="model" name="model"
                                                       placeholder="Enter Model" value="<?= htmlspecialchars($rts['model'] ?? '') ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Approval Matrix Section -->
                                    <div class="form-section">
                                        <div class="section-header">
                                            <i class="fas fa-clipboard-check"></i> Approval Matrix
                                        </div>
                                        <div class="approval-matrix">
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th>Prepared By</th>
                                                                                                                <th>Checked By</th>
                                                        <th>Approved By</th>
                                                        <th>Noted By</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div class="signature-container">
                                                                <?php if (!empty($signature_base64)): ?>
                                                                    <img src="<?php echo $signature_base64; ?>" alt="Signature">
                                                                <?php endif; ?>
                                                                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="signature-container">
                                                                <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending">
                                                                <span>Pending</span>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="signature-container">
                                                                <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending">
                                                                <span>Pending</span>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="signature-container">
                                                                <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending">
                                                                <span>Pending</span>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <!-- Material Details Section -->
                                    <div class="form-section">
                                        <div class="section-header">
                                            <i class="fas fa-list-alt"></i> Material Details
                                        </div>
                                        
                                        <!-- Material Count Indicator -->
                                        <div class="material-count-indicator no-records" id="materialCountIndicator">
                                            <i class="fas fa-exclamation-triangle"></i>
                                            <span id="materialCountText">No material details added yet. Please add material information.</span>
                                        </div>

                                        <div class="materials-header">
                                            <div></div>
                                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                                    data-target="#materialDetailsModal">
                                                <i class="fas fa-plus"></i> Add Material Details
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Material Details Modal - Enhanced Wide Version -->
                                    <div class="modal fade" id="materialDetailsModal" tabindex="-1" role="dialog">
                                        <div class="modal-dialog modal-fullscreen-xl-down modal-xl-custom" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">
                                                        <i class="fas fa-table"></i> Material Details
                                                    </h5>
                                                    <button type="button" class="close text-white" data-dismiss="modal">
                                                        <span>&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="table-responsive-custom">
                                                        <table id="material_details_table" class="material-table-enhanced">
                                                            <thead>
                                                                <tr>
                                                                    <th style="width: 60px;">No.</th>
                                                                    <th style="width: 140px;">Ref. No</th>
                                                                    <th style="width: 150px;">SAP Mat Doc</th>
                                                                    <th style="width: 130px;">Invoice No</th>
                                                                    <th style="width: 180px;">Supplier</th>
                                                                    <th style="width: 140px;">Part Number</th>  
                                                                    <th style="width: 160px;">Part Name</th>
                                                                    <th style="width: 180px;">Description</th>
                                                                    <th style="width: 110px;">Qty Returned</th>
                                                                    <th style="width: 110px;">Qty Received</th>
                                                                    <th style="width: 100px;">Amount</th>
                                                                    <th style="width: 140px;">Due Date</th>
                                                                    <th style="width: 90px;">Actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <!-- Rows will be added dynamically -->
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <div class="d-flex justify-content-between align-items-center w-100">
                                                        <div class="d-flex align-items-center">
                                                            <input type="number" class="form-control mr-2" id="numRowsInput" 
                                                                placeholder="Number of rows" min="1" max="50" value="5" style="width: 150px;">
                                                            <button type="button" class="btn btn-secondary" id="addRowsBtn">
                                                                <i class="fas fa-plus"></i> Add Rows
                                                            </button>
                                                        </div>
                                                        <button type="button" class="btn btn-primary" data-dismiss="modal">
                                                            <i class="fas fa-check"></i> Done
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Submit Section -->
                                    <div class="submit-section">
                                        <button type="submit" class="btn btn-success btn-lg">
                                            <i class="fas fa-paper-plane"></i> Resubmit RTS Form
                                        </button>
                                        <a href="<?php echo BASE_URL; ?>/pages/requests/disapproved_requests.php" class="btn btn-secondary btn-lg ml-3">
                                            <i class="fas fa-times"></i> Cancel
                                        </a>
                                        <div style="margin-top: 10px; color: #6c757d; font-size: 10pt;">
                                            <i class="fas fa-info-circle"></i> Please review all information before resubmitting
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include INCLUDES_PATH . '/footer.php'; ?>
    </div>
</div>

<script>
$(document).ready(function() {
    let totalRows = 0;
    let recordsWithData = 0;

    $('#department').addClass('readonly-field');

    // Pre-populate existing materials
    const existingMaterials = <?php echo json_encode($items); ?>;

    // Initialize material table when modal is opened
    $('#materialDetailsModal').one('shown.bs.modal', function() {
        if (existingMaterials && existingMaterials.length > 0) {
            existingMaterials.forEach((material, index) => {
                const rowNumber = index + 1;
                let dueDate = '';
                
                // Handle date conversion properly
                if (material.due_date) {
                    if (material.due_date.date) {
                        dueDate = material.due_date.date.split(' ')[0];
                    } else {
                        dueDate = material.due_date.split(' ')[0];
                    }
                }
                
                const rowHtml = `
                    <tr data-row-number="${rowNumber}">
                        <td style="text-align: center; font-weight: 500;">${rowNumber}</td>
                        <td><input type="text" class="form-control material-input" name="material_details[ref_no][]" value="${material.ref_no || ''}" placeholder="Ref. No"></td>
                        <td><input type="text" class="form-control material-input" name="material_details[sap_doc][]" value="${material.sap_doc || ''}" placeholder="SAP Doc"></td>
                        <td><input type="text" class="form-control material-input" name="material_details[invoice_no][]" value="${material.invoice_no || ''}" placeholder="Invoice"></td>
                        <td><input type="text" class="form-control material-input" name="material_details[supplier][]" value="${material.supplier || ''}" placeholder="Supplier"></td>
                        <td><input type="text" class="form-control material-input" name="material_details[part_number][]" value="${material.part_number || ''}" placeholder="Part No"></td>
                        <td><input type="text" class="form-control material-input" name="material_details[part_name][]" value="${material.part_name || ''}" placeholder="Part Name"></td>
                        <td><input type="text" class="form-control material-input" name="material_details[description][]" value="${material.description || ''}" placeholder="Description"></td>
                        <td><input type="number" class="form-control material-input" name="material_details[qty_returned][]" value="${material.qty_returned || ''}" placeholder="0" min="0"></td>
                        <td><input type="number" class="form-control material-input" name="material_details[qty_received][]" value="${material.qty_received || ''}" placeholder="0" min="0"></td>
                        <td><input type="number" class="form-control material-input" name="material_details[amount][]" value="${material.amount || ''}" placeholder="0.00" min="0" step="0.01"></td>
                        <td><input type="date" class="form-control material-input" name="material_details[due_date][]" value="${dueDate}"></td>
                        <td style="text-align: center;">
                            <button type="button" class="btn btn-danger btn-sm remove-row-btn">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>`;
                
                $('#material_details_table tbody').append(rowHtml);
            });
            
            // Attach event listeners and update count
            attachMaterialInputListeners();
            updateMaterialCount();
        }
    });

    // Add rows functionality
    $('#addRowsBtn').on('click', function() {
        const numRows = parseInt($('#numRowsInput').val()) || 5;
        if (numRows >= 1 && numRows <= 50) {
            generateTableRows(numRows);
            $('#numRowsInput').val('');
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Invalid Input',
                text: 'Please enter a number between 1 and 50.',
                confirmButtonText: 'OK',
                confirmButtonColor: '#264c7eff'
            });
        }
    });

    // Generate table rows
    function generateTableRows(numberOfRows) {
        let rowsHtml = '';
        const startingIndex = $('#material_details_table tbody tr').length + 1;
        
        for (let i = 0; i < numberOfRows; i++) {
            const rowNumber = startingIndex + i;
            rowsHtml += `
                <tr data-row-number="${rowNumber}">
                    <td style="text-align: center; font-weight: 500;">${rowNumber}</td>
                    <td><input type="text" class="form-control material-input" name="material_details[ref_no][]" placeholder="Ref. No"></td>
                    <td><input type="text" class="form-control material-input" name="material_details[sap_doc][]" placeholder="SAP Doc"></td>
                    <td><input type="text" class="form-control material-input" name="material_details[invoice_no][]" placeholder="Invoice"></td>
                    <td><input type="text" class="form-control material-input" name="material_details[supplier][]" placeholder="Supplier"></td>
                    <td><input type="text" class="form-control material-input" name="material_details[part_number][]" placeholder="Part No"></td>
                    <td><input type="text" class="form-control material-input" name="material_details[part_name][]" placeholder="Part Name"></td>
                    <td><input type="text" class="form-control material-input" name="material_details[description][]" placeholder="Description"></td>
                    <td><input type="number" class="form-control material-input" name="material_details[qty_returned][]" placeholder="0" min="0"></td>
                    <td><input type="number" class="form-control material-input" name="material_details[qty_received][]" placeholder="0" min="0"></td>
                    <td><input type="number" class="form-control material-input" name="material_details[amount][]" placeholder="0.00" min="0" step="0.01"></td>
                    <td><input type="date" class="form-control material-input" name="material_details[due_date][]"></td>
                    <td style="text-align: center;">
                        <button type="button" class="btn btn-danger btn-sm remove-row-btn">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>`;
        }
        
        $('#material_details_table tbody').append(rowsHtml);
        totalRows += numberOfRows;
        
        // Attach event listeners to new inputs
        attachMaterialInputListeners();
        updateMaterialCount();
    }

    // Attach event listeners to material inputs for real-time tracking
    function attachMaterialInputListeners() {
        $(document).off('input change', '.material-input');
        $(document).on('input change', '.material-input', function() {
            const $row = $(this).closest('tr');
            checkRowData($row);
            updateMaterialCount();
        });
    }

    // Check if a row has data
    function checkRowData($row) {
        const inputs = $row.find('.material-input');
        let hasData = false;
        
        inputs.each(function() {
            if ($(this).val().trim() !== '') {
                hasData = true;
                return false; // Break the loop
            }
        });
        
        if (hasData) {
            $row.addClass('has-data');
        } else {
            $row.removeClass('has-data');
        }
        
        return hasData;
    }

    // Update material count indicator
    function updateMaterialCount() {
        recordsWithData = 0;
        const totalAvailableRows = $('#material_details_table tbody tr').length;
        
        $('#material_details_table tbody tr').each(function() {
            if (checkRowData($(this))) {
                recordsWithData++;
            }
        });
        
        const $indicator = $('#materialCountIndicator');
        const $text = $('#materialCountText');
        
        if (recordsWithData > 0) {
            $indicator.removeClass('no-records');
            $indicator.find('i').removeClass('fa-exclamation-triangle').addClass('fa-check-circle');
            $text.text(`${recordsWithData} material record(s) added out of ${totalAvailableRows} available rows.`);
        } else {
            $indicator.addClass('no-records');
            $indicator.find('i').removeClass('fa-check-circle').addClass('fa-exclamation-triangle');
            if (totalAvailableRows > 0) {
                $text.text(`No material details filled yet. ${totalAvailableRows} rows available for input.`);
            } else {
                $text.text('No material details added yet. Please add material information.');
            }
        }
    }

    // Remove row functionality
    $(document).on('click', '.remove-row-btn', function() {
        $(this).closest('tr').remove();
        renumberRows();
        updateMaterialCount();
    });

    // Renumber rows after removal
    function renumberRows() {
        $('#material_details_table tbody tr').each(function(index) {
            $(this).find('td:first').text(index + 1);
            $(this).attr('data-row-number', index + 1);
        });
    }

    // Update count when modal is closed
    $('#materialDetailsModal').on('hidden.bs.modal', function() {
        updateMaterialCount();
    });

    // Initialize material status logic based on pre-selected values
    $('.material-status-checkbox:checked').each(function() {
        handleJudgementOptions($(this).val());
        $('#details').prop('disabled', false);
    });

    // Fixed Material Status Selection - Allow Uncheck
    $('.material-status-checkbox').on('change', function() {
        const $this = $(this);
        const isChecked = $this.is(':checked');
        
        if (isChecked) {
            // Uncheck other material status checkboxes
            $('.material-status-checkbox').not($this).prop('checked', false);
            
            // Handle judgement options
            handleJudgementOptions($this.val());
            
            // Enable details field
            $('#details').prop('disabled', false);
        } else {
            // If unchecked, disable and uncheck all judgement checkboxes
            $('.judgement-checkbox').prop('checked', false).prop('disabled', true);
            
            // Disable details field
            $('#details').prop('disabled', true).val('');
        }
    });

    // Handle judgement options based on material status
    function handleJudgementOptions(selectedStatus) {
        // Reset all judgement checkboxes
        $('.judgement-checkbox').prop('checked', false).prop('disabled', true);
        
        // Enable appropriate judgement options
        switch(selectedStatus) {
            case 'NG/Others':
                $('#scrapdisposal, #hold').prop('disabled', false);
                break;
            case 'Good':
                $('#transfertogood').prop('disabled', false);
                break;
            default:
                $('#scrapdisposal, #hold').prop('disabled', false);
                break;
        }
    }

    // Judgement checkbox handling
    $('.judgement-checkbox').on('change', function() {
        if ($(this).is(':checked')) {
            $('.judgement-checkbox').not(this).prop('checked', false);
        }
    });

    // SAP Location validation - prevent same selection
    $('#sapLocationFrom, #sapLocationTo').on('change', function() {
        const fromLocation = $('#sapLocationFrom').val();
        const toLocation = $('#sapLocationTo').val();
        
        if (fromLocation && toLocation && fromLocation === toLocation) {
            Swal.fire({
                icon: 'warning',
                title: 'Invalid Selection',
                text: 'From and To locations cannot be the same.',
                confirmButtonText: 'OK',
                confirmButtonColor: '#264c7eff'
            });
            $(this).val('');
        }
    });

    // Form validation and submission with SweetAlert
    $('#rtsResubmitForm').on('submit', function(e) {
        e.preventDefault();
        
        const validation = validateForm();
        
        if (!validation.isValid) {
            Swal.fire({
                icon: 'error', 
                title: 'Validation Error',
                html: validation.errors.join('<br>'),
                confirmButtonText: 'Fix Issues',
                confirmButtonColor: '#264c7eff'
            });
            return;
        }

        // Show confirmation dialog
        Swal.fire({
            title: 'Resubmit RTS Form?',
            text: 'Are you sure you want to resubmit this Return/Transfer Slip?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#264c7eff',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, Resubmit',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                submitForm();
            }
        });
    });

    // Enhanced form validation function
    function validateForm() {
        const errors = [];

        // Material Type validation
        if ($('input[name="material_type[]"]:checked').length === 0) {
            errors.push('• Please select at least one Material Type.');
        }

        // Material Status validation
        const materialStatusChecked = $('input[name="material_status[]"]:checked');
        if (materialStatusChecked.length === 0) {
            errors.push('• Please select at least one Material Status.');
        }

        // Judgement validation
        const selectedStatus = materialStatusChecked.val();
        const judgementChecked = $('input[name="judgement[]"]:checked');
        
        if (selectedStatus === 'NG/Others' && judgementChecked.length === 0) {
            errors.push('• Please select a judgement for NG/Others status.');
        } else if (selectedStatus && selectedStatus !== 'Good' && selectedStatus !== 'NG/Others' && judgementChecked.length === 0) {
            errors.push('• Please select at least one Judgement.');
        }

        // SAP Location validation
        if (!$('#sapLocationFrom').val() || !$('#sapLocationTo').val()) {
            errors.push('• Please select both From and To SAP Location Codes.');
        }

        // Basic field validation
        if (!$('#return_date').val()) {
            errors.push('• Please select a Return Date.');
        }

        if (!$('#department').val()) {
            errors.push('• Please select a Department.');
        }

        // Enhanced Material details validation
        if (recordsWithData === 0) {
            errors.push('• Please enter details for at least one material.');
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    // Submit form function with SweetAlert
    function submitForm() {
        const $submitBtn = $('button[type="submit"]');
        const originalText = $submitBtn.html();
        
        $submitBtn.html('<i class="fas fa-spinner fa-spin"></i> Resubmitting...').prop('disabled', true);

        // Show loading SweetAlert
        Swal.fire({
            title: 'Processing...',
            text: 'The request is being processed. Please wait.',
            icon: 'info',
            allowOutsideClick: false,
            showConfirmButton: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: $('#rtsResubmitForm').attr('action'),
            type: 'POST',
            data: $('#rtsResubmitForm').serialize(),
            dataType: 'json',
            success: function(response) {
                Swal.close();
                
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Form Resubmitted Successfully!',
                        html: `
                            <div style="text-align: center;">
                                <h4>Your RTS Control Number:</h4>
                                <div style="background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 10px 0; border: 2px solid #28a745;">
                                    <strong style="font-size: 1.3em; color: #264c7eff; font-family: 'Courier New', monospace;">${response.control_no}</strong>
                                </div>
                                <p style="color: #666; font-size: 14px;">Your form has been resubmitted for approval.</p>
                                <p style="color: #666; font-size: 12px;">Materials entered: ${recordsWithData} records</p>
                            </div>
                        `,
                        confirmButtonText: 'Continue',
                        confirmButtonColor: '#264c7eff',
                        allowOutsideClick: false
                    }).then(() => {
                        window.location.href = '<?php echo BASE_URL; ?>/pages/requests/pending_requests.php';
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Resubmission Failed',
                        text: response.message || 'An error occurred while resubmitting the form.',
                        confirmButtonText: 'Try Again',
                        confirmButtonColor: '#264c7eff'
                    });
                }
            },
            error: function(xhr, status, error) {
                Swal.close();
                
                Swal.fire({
                    icon: 'error',
                    title: 'Network Error',
                    text: 'Unable to resubmit form. Please check your connection and try again.',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#264c7eff'
                });
            },
            complete: function() {
                $submitBtn.html(originalText).prop('disabled', false);
            }
        });
    }

    // Enhanced visual feedback
    $('input, select, textarea').on('focus', function() {
        $(this).closest('.form-group').addClass('focused');
    }).on('blur', function() {
        $(this).closest('.form-group').removeClass('focused');
    });

    // Add smooth transitions for checkboxes
    $('.custom-control-input').on('change', function() {
        $(this).closest('.custom-control').toggleClass('checked', this.checked);
    });

    // Initialize material count tracking
    updateMaterialCount();
});
</script>

                                                        

    