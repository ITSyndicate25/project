<?php
session_start();
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

// Check for user ID in session
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not authenticated.']);
    exit();
}

$current_user_id = $_SESSION['user_id'];
$current_user_role = $_SESSION['user_role'] ?? '';
$user_roles_array = explode(',', str_replace(' ', '', $current_user_role));

// Get request type from POST data
$request_type = $_POST['request_type'] ?? 'pending'; // pending, ongoing, completed, disapproved

try {
    $db = new Connection();
    $conn = $db->link;

    $draw = $_POST['draw'] ?? 1;
    $start = intval($_POST['start'] ?? 0);
    $length = intval($_POST['length'] ?? 10);
    $search_value = $_POST['search']['value'] ?? '';

    // Base select clause - now using workflow_status instead of material_status for workflow tracking
    $select_clause = "
        SELECT
            rts_forms.id,
            rts_forms.control_no AS rts_no,
            'RTS Form' AS form_type,
            rts_forms.created_at,
            submitted_user.requestor_name AS submitted_by,
            submitted_user.user_id AS submitted_by_id,
            rts_forms.checked_status,
            rts_forms.approved_status,
            rts_forms.noted_status,
            rts_forms.material_status,
            rts_forms.workflow_status";

    // Add additional fields based on request type
    if ($request_type === 'disapproved') {
        $select_clause .= ",
            rts_forms.disapproval_reason,
            rts_forms.disapproved_by_role,
            rts_forms.workflow_status AS overall_status";
    } elseif ($request_type === 'completed') {
        $select_clause .= ",
            rts_forms.workflow_status AS status";
    } elseif ($request_type === 'ongoing') {
        $select_clause .= ",
            CASE
                WHEN rts_forms.workflow_status = 'Pending' THEN 'Pending'
                ELSE 'In-Progress'
            END AS status";
    } else { // pending
        $select_clause .= ",
            CASE
                WHEN rts_forms.workflow_status = 'Disapproved' OR rts_forms.workflow_status = 'Canceled' THEN 'Disapproved'
                WHEN rts_forms.workflow_status = 'Completed' THEN 'Completed'
                WHEN rts_forms.workflow_status = 'In-Progress' THEN 'In-Progress'
                ELSE 'Pending'
            END AS status";
    }
    
    $from_clause = "
        FROM rts_forms
        LEFT JOIN users AS submitted_user ON rts_forms.requestor_id = submitted_user.user_id
    ";

    $conditions = [];
    $query_params = [];

    // Apply request type specific conditions using workflow_status
    switch ($request_type) {
        case 'pending':
            $role_conditions = [];
            
            if (in_array('checker', $user_roles_array)) {
                $role_conditions[] = "rts_forms.checked_status = 'Pending'";
            }
            
            if (in_array('approver', $user_roles_array)) {
                $role_conditions[] = "rts_forms.checked_status = 'Approved' AND rts_forms.approved_status = 'Pending'";
            }
            
            if (in_array('noter', $user_roles_array)) {
                $role_conditions[] = "rts_forms.checked_status = 'Approved' AND rts_forms.approved_status = 'Approved' AND rts_forms.noted_status = 'Pending'";
            }
            
            if (!empty($role_conditions)) {
                $conditions[] = "(" . implode(' OR ', $role_conditions) . ")";
            } elseif (!in_array('admin', $user_roles_array)) {
                $conditions[] = "rts_forms.requestor_id = ?";
                $query_params[] = $current_user_id;
                $conditions[] = "rts_forms.checked_status <> 'Disapproved' AND rts_forms.approved_status <> 'Disapproved' AND rts_forms.noted_status <> 'Disapproved'";
            }

            // Use workflow_status for filtering
            $conditions[] = "rts_forms.workflow_status NOT IN ('In-Progress', 'Completed', 'Disapproved', 'Canceled')";
            break;

        case 'ongoing':
            // Use workflow_status for filtering ongoing requests
            $conditions[] = "rts_forms.workflow_status = 'In-Progress' OR (rts_forms.workflow_status = 'Pending' AND (rts_forms.checked_status = 'Approved' OR rts_forms.approved_status = 'Approved'))";

            $role_specific_conditions = [];
            
            if (in_array('checker', $user_roles_array)) {
                $role_specific_conditions[] = "rts_forms.checked_status = 'Pending'";
            }
            
            if (in_array('approver', $user_roles_array)) {
                $role_specific_conditions[] = "rts_forms.checked_status = 'Approved' AND rts_forms.approved_status = 'Pending'";
            }
            
            if (in_array('noter', $user_roles_array)) {
                $role_specific_conditions[] = "rts_forms.approved_status = 'Approved' AND rts_forms.noted_status = 'Pending'";
            }

            if (!empty($role_specific_conditions)) {
                $conditions[] = "(" . implode(' OR ', $role_specific_conditions) . ")";
            } elseif (!in_array('admin', $user_roles_array)) {
                $conditions[] = "rts_forms.requestor_id = ?";
                $query_params[] = $current_user_id;
            }
            break;

        case 'completed':
            // Use workflow_status for filtering completed requests
            $conditions[] = "rts_forms.workflow_status IN ('Completed', 'Canceled')";

            if (!in_array('admin', $user_roles_array) && !in_array('checker', $user_roles_array) && 
                !in_array('approver', $user_roles_array) && !in_array('noter', $user_roles_array)) {
                $conditions[] = "rts_forms.requestor_id = ?";
                $query_params[] = $current_user_id;
            }
            break;

        case 'disapproved':
            $conditions[] = "rts_forms.workflow_status = 'Disapproved'"; 
                
                // Allow users to see their own disapproved requests
                if (!in_array('admin', $user_roles_array) && 
                    !in_array('checker', $user_roles_array) && 
                    !in_array('approver', $user_roles_array) && 
                    !in_array('noter', $user_roles_array)) {
                    $conditions[] = "rts_forms.requestor_id = ?";
                    $query_params[] = $current_user_id;
                }
                break;
                }

    // Add search conditions
    if (!empty($search_value)) {
        $search_param = '%' . $search_value . '%';
        $search_conditions = "(rts_forms.control_no LIKE ? OR submitted_user.requestor_name LIKE ? OR rts_forms.workflow_status LIKE ? OR rts_forms.material_status LIKE ?";
        $query_params[] = $search_param;
        $query_params[] = $search_param;
        $query_params[] = $search_param;
        $query_params[] = $search_param;
        
        if ($request_type === 'disapproved') {
            $search_conditions .= " OR rts_forms.disapproval_reason LIKE ?";
            $query_params[] = $search_param;
        }
        
        $search_conditions .= ")";
        $conditions[] = $search_conditions;
    }
    
    $where_string = count($conditions) > 0 ? "WHERE " . implode(" AND ", $conditions) : "";

    // Count total records
    $sql_total = "SELECT COUNT(*) FROM rts_forms";
    $stmt_total = sqlsrv_query($conn, $sql_total);
    $total_records = 0;
    if ($stmt_total && sqlsrv_fetch($stmt_total)) {
        $total_records = sqlsrv_get_field($stmt_total, 0);
    }

    // Count filtered records
    $sql_filtered_count = "SELECT COUNT(*) " . $from_clause . " " . $where_string;
    $stmt_filtered_count = sqlsrv_query($conn, $sql_filtered_count, $query_params);
    $total_filtered_records = 0;
    if ($stmt_filtered_count && sqlsrv_fetch($stmt_filtered_count)) {
        $total_filtered_records = sqlsrv_get_field($stmt_filtered_count, 0);
    }

    // Determine order column
    $order_column = $_POST['columns'][$_POST['order'][0]['column']]['data'] ?? 'created_at';
    $order_dir = $_POST['order'][0]['dir'] ?? 'desc';

    switch ($order_column) {
        case 'rts_no': 
            $order_sql = 'rts_forms.control_no'; 
            break;
        case 'created_at': 
            $order_sql = 'rts_forms.created_at'; 
            break;
        case 'submitted_by': 
            $order_sql = 'submitted_user.requestor_name'; 
            break;
        case 'status':
        case 'overall_status':
            if ($request_type === 'completed') {
                $order_sql = "CASE 
                    WHEN rts_forms.workflow_status = 'Completed' THEN 1
                    WHEN rts_forms.workflow_status = 'Canceled' THEN 2
                    ELSE 3
                END";
            } elseif ($request_type === 'ongoing') {
                $order_sql = "CASE 
                    WHEN rts_forms.workflow_status = 'In-Progress' THEN 1
                    WHEN rts_forms.workflow_status = 'Pending' THEN 2
                    ELSE 3
                END";
            } else {
                $order_sql = "CASE 
                    WHEN rts_forms.workflow_status = 'Disapproved' OR rts_forms.workflow_status = 'Canceled' THEN 4
                    WHEN rts_forms.workflow_status = 'Completed' THEN 3
                    WHEN rts_forms.workflow_status = 'In-Progress' THEN 2
                    ELSE 1
                END";
            }
            break;
        case 'disapproval_reason':
            $order_sql = 'rts_forms.disapproval_reason';
            break;
        case 'disapproved_by_role':
            $order_sql = 'rts_forms.disapproved_by_role';
            break;
        default: 
            $order_sql = 'rts_forms.created_at'; 
            $order_dir = 'desc';
    }

    // Final query
    $sql_final = "
        " . $select_clause . "
        " . $from_clause . "
        " . $where_string . "
        ORDER BY " . $order_sql . " " . $order_dir . "
        OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    $query_params[] = $start;
    $query_params[] = $length;

    $stmt = sqlsrv_query($conn, $sql_final, $query_params);

    if ($stmt === false) {
        error_log("SQL Server Query Error (Final Query): " . print_r(sqlsrv_errors(), true));
        throw new Exception("Database query failed.");
    }

    $data = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if (isset($row['created_at']) && $row['created_at'] instanceof DateTime) {
            $row['created_at'] = $row['created_at']->format('Y-m-d H:i:s');
        }
        
        // Make sure to return workflow_status as the main status for proper display
        if (isset($row['workflow_status'])) {
            if (!isset($row['status'])) {
                $row['status'] = $row['workflow_status'];
            }
        }
        
        $data[] = $row;
    }

    echo json_encode([
        'status' => 'success',
        'draw' => intval($draw),
        'recordsTotal' => intval($total_records),
        'recordsFiltered' => intval($total_filtered_records),
        'data' => $data
    ]);

    $db->close();

} catch (Exception $e) {
    error_log("General Error (Fetch Requests - $request_type): " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'An internal server error occurred.']);
}
?>