<?php
session_start();

require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once INCLUDES_PATH . '/functions.php';

// Authentication and permission checks remain unchanged as they are correct.
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

$user_department = $_SESSION['department'] ?? getUserDepartment($_SESSION['user_id']);
if (!checkScrapPermission($user_department, $_SESSION['user_role'])) {
    if ($_SESSION['user_role'] === 'admin') {
        header('Location: ' . BASE_URL . '/pages/admin/admin_dashboard.php');
    } else {
        header('Location: ' . BASE_URL . '/pages/user/user_dashboard.php');
    }
    exit();
}
?>

<?php include INCLUDES_PATH . '/header.php'; ?>

<style>
    /* CSS Variables for easy theming */
    :root {
        --primary-color: #007bff;
        --secondary-color: #51cbce;
        --text-color: #333;
        --muted-text-color: #6c757d;
        --background-color: #f4f7f9;
        --card-background: #fff;
        --border-color: #e0e0e0;
        --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        --border-radius: 12px;
        --transition-speed: 0.3s;
    }

    body {
        background-color: var(--background-color);
    }

    /* Dashboard Layout */
    .scrap-dashboard {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 24px; /* Increased gap for better spacing */
        padding: 24px;
    }

    /* Card Styling */
    .scrap-card {
        width: 320px; /* Slightly wider cards */
        background-color: var(--card-background);
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
        transition: transform var(--transition-speed) ease, box-shadow var(--transition-speed) ease;
        overflow: hidden;
        text-align: center;
        display: flex; /* Flexbox for internal alignment */
        flex-direction: column;
        justify-content: space-between;
    }

    .scrap-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    }

    .scrap-card-header {
        padding: 20px;
        background-color: var(--background-color);
        border-bottom: 1px solid var(--border-color);
    }

    .scrap-card-body {
        padding: 24px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .scrap-card-icon {
        font-size: 3.5rem;
        margin-bottom: 12px;
        color: var(--primary-color);
    }

    .scrap-card-title {
        font-size: 1.35rem;
        font-weight: 600;
        color: var(--text-color);
        margin-bottom: 8px;
    }

    .scrap-card-body p {
        color: var(--muted-text-color);
        font-size: 0.95rem;
        margin-bottom: 24px;
    }

    .scrap-card-btn {
        width: 100%;
        padding: 12px;
        background-color: var(--secondary-color);
        color: white;
        border: none;
        border-radius: 8px; /* Slightly larger button border-radius */
        font-weight: bold;
        transition: background-color var(--transition-speed) ease;
    }

    .scrap-card-btn:hover {
        background-color: #46b8bc; /* Darker shade on hover */
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .scrap-dashboard {
            flex-direction: column;
            align-items: center;
        }

        .scrap-card {
            width: 95%;
            max-width: 400px;
        }
    }
</style>

<body>
    <div class="wrapper">
        <?php include INCLUDES_PATH . '/sidebar.php'; ?>
        <div class="main-panel">
            <?php include INCLUDES_PATH . '/navbar.php'; ?>
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title text-center">Scrap Management</h4>
                                </div>
                                <div class="card-body">
                                    <div class="scrap-dashboard">
                                        <div class="scrap-card">
                                            <div class="scrap-card-body">
                                                <i class="fas fa-recycle scrap-card-icon"></i>
                                                <div class="scrap-card-title">Return / Transfer Slip (RTS) Form</div>
                                                <p>Create a new Return or Transfer Slip for material management.</p>
                                                <a href="rts_form.php" class="btn scrap-card-btn">Create RTS Form</a>
                                            </div>
                                        </div>

                                        <div class="scrap-card">
                                            <div class="scrap-card-body">
                                                <i class="fas fa-trash-alt scrap-card-icon"></i>
                                                <div class="scrap-card-title">NG (No Good) Disposal Form</div>
                                                <p>Process and document NG material disposal.</p>
                                                <a href="ng_disposal_form.php" class="btn scrap-card-btn">Create NG Disposal Form</a>
                                            </div>
                                        </div>

                                        <div class="scrap-card">
                                            <div class="scrap-card-body">
                                                <i class="fas fa-industry scrap-card-icon"></i>
                                                <div class="scrap-card-title">Coil & Solder Endorsement Form</div>
                                                <p>Create endorsement for Coil and Solder materials.</p>
                                                <a href="coil_solder_form.php" class="btn scrap-card-btn">Create Endorsement Form</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include INCLUDES_PATH . '/footer.php'; ?>
        </div>
    </div>
</body>