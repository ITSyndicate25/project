<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/includes/functions.php';

header('Content-Type: application/json');

// Check for admin role
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

// Get and sanitize POST data
$location_code = trim($_POST['location_code'] ?? '');

if (empty($location_code)) {
    echo json_encode(['success' => false, 'message' => 'No location code provided.']);
    exit();
}

// Call the new function to handle the database deletion
$result = deleteSapLocCode($location_code);

echo json_encode($result);
exit();
?>