<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}
?>

<?php include INCLUDES_PATH . '/header.php'; ?>

<style>
    /* Multi-select card style */
    .multi-select-container {
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 15px;
        background: #f8f9fa;
        min-height: 120px;
    }

    .multi-select-container.focused {
        border-color: #007bff;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .multi-select-header {
        display: flex;
        justify-content: between;
        align-items: center;
        margin-bottom: 10px;
        font-weight: 600;
        color: #495057;
    }

    .select-all-btn {
        font-size: 0.75rem;
        padding: 2px 8px;
        border-radius: 12px;
    }

    .option-card {
        display: inline-block;
        margin: 4px;
        padding: 8px 12px;
        border: 2px solid #dee2e6;
        border-radius: 20px;
        background: white;
        cursor: pointer;
        transition: all 0.3s ease;
        font-size: 0.85rem;
        position: relative;
        user-select: none;
    }

    .option-card:hover {
        border-color: #007bff;
        transform: translateY(-1px);
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .option-card.selected {
        background: linear-gradient(135deg, #007bff, #0056b3);
        border-color: #007bff;
        color: white;
        transform: scale(1.02);
    }

    .option-card.selected:hover {
        background: linear-gradient(135deg, #0056b3, #004085);
    }

    /* Role-specific colors */
    .role-user.selected { background: linear-gradient(135deg, #28a745, #1e7e34); border-color: #28a745; }
    .role-checker.selected { background: linear-gradient(135deg, #17a2b8, #117a8b); border-color: #17a2b8; }
    .role-approver.selected { background: linear-gradient(135deg, #ffc107, #e0a800); border-color: #ffc107; color: #212529; }
    .role-noter.selected { background: linear-gradient(135deg, #fd7e14, #e55a00); border-color: #fd7e14; }
    .role-admin.selected { background: linear-gradient(135deg, #dc3545, #bd2130); border-color: #dc3545; }

    /* Category-specific colors */
    .category-good.selected { background: linear-gradient(135deg, #28a745, #1e7e34); border-color: #28a745; }
    .category-material-defect.selected { background: linear-gradient(135deg, #dc3545, #bd2130); border-color: #dc3545; }
    .category-human-error.selected { background: linear-gradient(135deg, #ffc107, #e0a800); border-color: #ffc107; color: #212529; }
    .category-others.selected { background: linear-gradient(135deg, #6c757d, #545b62); border-color: #6c757d; }
    .category-eol.selected { background: linear-gradient(135deg, #6f42c1, #5a359a); border-color: #6f42c1; }

    .option-card .check-icon {
        display: none;
        position: absolute;
        top: -5px;
        right: -5px;
        width: 18px;
        height: 18px;
        background: #28a745;
        border-radius: 50%;
        border: 2px solid white;
        font-size: 10px;
        color: white;
        text-align: center;
        line-height: 14px;
    }

    .option-card.selected .check-icon {
        display: block;
    }

    .selection-counter {
        float: right;
        font-size: 0.75rem;
        color: #6c757d;
        background: white;
        padding: 2px 8px;
        border-radius: 10px;
        border: 1px solid #dee2e6;
    }

    /* Enhanced modal styles */
    .modal-dialog {
        max-width: 700px;
    }

    .form-section {
        background: #f8f9fa;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        border-left: 4px solid #007bff;
    }

    .form-section h6 {
        color: #007bff;
        font-weight: 600;
        margin-bottom: 15px;
        font-size: 1rem;
    }

    .enhanced-file-upload {
        border: 2px dashed #dee2e6;
        border-radius: 8px;
        padding: 20px;
        text-align: center;
        background: white;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .enhanced-file-upload:hover {
        border-color: #007bff;
        background: #f8f9fa;
    }

    .enhanced-file-upload.dragover {
        border-color: #28a745;
        background: #d4edda;
    }

    .file-upload-icon {
        font-size: 2rem;
        color: #6c757d;
        margin-bottom: 10px;
    }

    .file-upload-text {
        color: #6c757d;
        font-size: 0.9rem;
    }

    .file-preview {
        margin-top: 10px;
        text-align: left;
    }

    .file-preview img {
        max-width: 100px;
        max-height: 100px;
        border-radius: 4px;
        border: 1px solid #dee2e6;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .modal-dialog {
            max-width: 95%;
            margin: 1rem auto;
        }
        
        .option-card {
            font-size: 0.8rem;
            padding: 6px 10px;
        }
        
        .form-section {
            padding: 15px;
        }
    }
</style>

<div class="wrapper">
    <?php include INCLUDES_PATH . '/sidebar.php'; ?>
    <div class="main-panel">
        <?php include INCLUDES_PATH . '/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="card-title m-0">User Management</h4>
                                <button class="btn btn-primary btn-round" id="addUserButton">
                                    <span class="d-none d-lg-inline">Add New User</span>
                                    <span class="d-lg-none"><i class="fa fa-plus"></i></span>
                                </button>
                            </div>
                            <div class="card-body">
                                <div id="loading" class="text-center">
                                    <i class="fa fa-spinner fa-spin fa-2x"></i>
                                    <p>Loading users...</p>
                                </div>
                                <div id="error-message" class="alert alert-danger" style="display: none;"></div>
                                <div class="table-responsive" id="users-table-container" style="display: none;">
                                    <table id="users-table" class="table table-striped table-bordered" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Username</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Role</th>
                                                <th>Department</th>
                                                <th>Category</th>
                                                <th>Date Created</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include INCLUDES_PATH . '/footer.php'; ?>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addUserModalLabel">
                    <i class="fa fa-user-plus mr-2"></i>Add New User
                </h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="addUserForm">
                <div class="modal-body">
                    <input type="hidden" id="add_user_id" name="user_id">
                    
                    <!-- Basic Information Section -->
                    <div class="form-section">
                        <h6><i class="fa fa-user mr-2"></i>Basic Information</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="add_id_number">Employee ID Number</label>
                                    <input type="number" class="form-control" id="add_id_number" name="id_number" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="add_username">Username</label>
                                    <input type="text" class="form-control" id="add_username" name="username" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="add_password">Password</label>
                                    <input type="password" class="form-control" id="add_password" name="password" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="add_requestor_name">Requestor Name</label>
                                    <input type="text" class="form-control" id="add_requestor_name" name="requestor_name" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="add_department">Department</label>
                                    <select class="form-control" id="add_department" name="department" required>
                                        <option value="">Select Department</option>
                                        <option value="Engineering">Engineering</option>
                                        <option value="Logistics">Logistics</option>
                                        <option value="LX">LX</option>
                                        <option value="INSTAX">INSTAX</option>
                                        <option value="PT">PT</option>
                                        <option value="LENS">LENS</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="add_email">Email address</label>
                                    <input type="email" class="form-control" id="add_email" name="email" required>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Roles Section -->
                    <div class="form-section">
                        <h6><i class="fa fa-shield-alt mr-2"></i>User Roles</h6>
                        <div class="multi-select-container" id="add_roles_container">
                            <div class="multi-select-header">
                                Select User Roles
                                <span class="selection-counter" id="add_roles_counter">0 selected</span>
                            </div>
                            <div class="options-grid">
                                <div class="option-card role-user" data-value="user">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-user mr-1"></i>User
                                </div>
                                <div class="option-card role-checker" data-value="checker">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-search mr-1"></i>Checker
                                </div>
                                <div class="option-card role-approver" data-value="approver">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-check-circle mr-1"></i>Approver
                                </div>
                                <div class="option-card role-noter" data-value="noter">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-sticky-note mr-1"></i>Noter
                                </div>
                                <div class="option-card role-admin" data-value="admin">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-crown mr-1"></i>Admin
                                </div>
                            </div>
                        </div>
                        <select class="form-control d-none" id="add_role" name="role[]" multiple required>
                            <option value="user">User</option>
                            <option value="checker">Checker</option>
                            <option value="approver">Approver</option>
                            <option value="noter">Noter</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>

                    <!-- Categories Section -->
                    <div class="form-section">
                        <h6><i class="fa fa-tags mr-2"></i>Categories</h6>
                        <div class="multi-select-container" id="add_categories_container">
                            <div class="multi-select-header">
                                Select Categories
                                <span class="selection-counter" id="add_categories_counter">0 selected</span>
                            </div>
                            <div class="options-grid">
                                <div class="option-card category-good" data-value="Good">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-thumbs-up mr-1"></i>Good
                                </div>
                                <div class="option-card category-material-defect" data-value="Material Defect">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-exclamation-triangle mr-1"></i>Material Defect
                                </div>
                                <div class="option-card category-human-error" data-value="Human Error">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-user-times mr-1"></i>Human Error
                                </div>
                                <div class="option-card category-others" data-value="Others">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-ellipsis-h mr-1"></i>Others
                                </div>
                                <div class="option-card category-eol" data-value="EOL">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-clock mr-1"></i>EOL
                                </div>
                            </div>
                        </div>
                        <select class="form-control d-none" id="add_category" name="category[]" multiple required>
                            <option value="Good">Good</option>
                            <option value="Material Defect">Material Defect</option>
                            <option value="Human Error">Human Error</option>
                            <option value="Others">Others</option>
                            <option value="EOL">EOL</option>
                        </select>
                    </div>

                    <!-- Signature Section -->
                    <div class="form-section">
                        <h6><i class="fa fa-signature mr-2"></i>Digital Signature</h6>
                        <div class="enhanced-file-upload" id="add_file_upload_area">
                            <input type="file" class="d-none" id="add_e_signiture" name="e_signiture" accept="image/*">
                            <div class="file-upload-icon">
                                <i class="fa fa-cloud-upload-alt"></i>
                            </div>
                            <div class="file-upload-text">
                                <strong>Click to upload</strong> or drag and drop<br>
                                <small>PNG, JPG, JPEG up to 5MB</small>
                            </div>
                            <div class="file-preview" id="add_file_preview" style="display: none;">
                                <img id="add_preview_image" src="" alt="Preview">
                                <div class="mt-2">
                                    <small id="add_file_name" class="text-muted"></small>
                                    <button type="button" class="btn btn-sm btn-danger ml-2" id="add_remove_file">Remove</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="add-user-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <i class="fa fa-times mr-1"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-primary" id="addUserSubmitBtn">
                        <i class="fa fa-user-plus mr-1"></i>Add User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title" id="editUserModalLabel">
                    <i class="fa fa-user-edit mr-2"></i>Edit User
                </h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editUserForm">
                <div class="modal-body">
                    <input type="hidden" id="edit_user_id" name="user_id">
                    
                    <!-- Basic Information Section -->
                    <div class="form-section">
                        <h6><i class="fa fa-user mr-2"></i>Basic Information</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="edit_username">Username</label>
                                    <input type="text" class="form-control" id="edit_username" name="username" required readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="edit_requestor_name">Requestor Name</label>
                                    <input type="text" class="form-control" id="edit_requestor_name" name="requestor_name" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="edit_id_number">Employee ID Number</label>
                                    <input type="text" class="form-control" id="edit_id_number" name="id_number" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="edit_email">Email address</label>
                                    <input type="email" class="form-control" id="edit_email" name="email" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="edit_department">Department</label>
                                    <select class="form-control" id="edit_department" name="department" required>
                                        <option value="">Select Department</option>
                                        <option value="Engineering">Engineering</option>
                                        <option value="Logistics">Logistics</option>
                                        <option value="LX">LX</option>
                                        <option value="INSTAX">INSTAX</option>
                                        <option value="PT">PT</option>
                                        <option value="LENS">LENS</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Roles Section -->
                    <div class="form-section">
                        <h6><i class="fa fa-shield-alt mr-2"></i>User Roles</h6>
                        <div class="multi-select-container" id="edit_roles_container">
                            <div class="multi-select-header">
                                Select User Roles
                                <span class="selection-counter" id="edit_roles_counter">0 selected</span>
                            </div>
                            <div class="options-grid">
                                <div class="option-card role-user" data-value="user">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-user mr-1"></i>User
                                </div>
                                <div class="option-card role-checker" data-value="checker">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-search mr-1"></i>Checker
                                </div>
                                <div class="option-card role-approver" data-value="approver">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-check-circle mr-1"></i>Approver
                                </div>
                                <div class="option-card role-noter" data-value="noter">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-sticky-note mr-1"></i>Noter
                                </div>
                                <div class="option-card role-admin" data-value="admin">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-crown mr-1"></i>Admin
                                </div>
                            </div>
                        </div>
                        <select class="form-control d-none" id="edit_role" name="role[]" multiple required>
                            <option value="user">User</option>
                            <option value="checker">Checker</option>
                            <option value="approver">Approver</option>
                            <option value="noter">Noter</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>

                    <!-- Categories Section -->
                    <div class="form-section">
                        <h6><i class="fa fa-tags mr-2"></i>Categories</h6>
                        <div class="multi-select-container" id="edit_categories_container">
                            <div class="multi-select-header">
                                Select Categories
                                <span class="selection-counter" id="edit_categories_counter">0 selected</span>
                            </div>
                            <div class="options-grid">
                                <div class="option-card category-good" data-value="Good">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-thumbs-up mr-1"></i>Good
                                </div>
                                <div class="option-card category-material-defect" data-value="Material Defect">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-exclamation-triangle mr-1"></i>Material Defect
                                </div>
                                <div class="option-card category-human-error" data-value="Human Error">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-user-times mr-1"></i>Human Error
                                </div>
                                <div class="option-card category-others" data-value="Others">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-ellipsis-h mr-1"></i>Others
                                </div>
                                <div class="option-card category-eol" data-value="EOL">
                                    <span class="check-icon">✓</span>
                                    <i class="fa fa-clock mr-1"></i>EOL
                                </div>
                            </div>
                        </div>
                        <select class="form-control d-none" id="edit_category" name="category[]" multiple required>
                            <option value="Good">Good</option>
                            <option value="Material Defect">Material Defect</option>
                            <option value="Human Error">Human Error</option>
                            <option value="Others">Others</option>
                            <option value="EOL">EOL</option>
                        </select>
                    </div>

                    <div id="edit-user-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <i class="fa fa-times mr-1"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-info" id="editUserSubmitBtn">
                        <i class="fa fa-save mr-1"></i>Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div class="modal fade" id="changePasswordModal" tabindex="-1" role="dialog" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title" id="changePasswordModalLabel">
                    <i class="fa fa-key mr-2"></i>Change User Password
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="changePasswordForm">
                <div class="modal-body">
                    <input type="hidden" id="change_password_user_id" name="user_id">
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_new_password">Confirm New Password</label>
                        <input type="password" class="form-control" id="confirm_new_password" name="confirm_new_password" required>
                    </div>
                    <div id="change-password-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <i class="fa fa-times mr-1"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-warning" id="changePasswordSubmitBtn">
                        <i class="fa fa-key mr-1"></i>Change Password
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Verify Password Modal -->
<div class="modal fade" id="verifyPasswordModal" tabindex="-1" role="dialog" aria-labelledby="verifyPasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="verifyPasswordModalLabel">
                    <i class="fa fa-lock mr-2"></i>Admin Password Verification
                </h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="verifyPasswordForm">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fa fa-info-circle mr-2"></i>
                        Please enter your password to confirm this action.
                    </div>
                    <div class="form-group">
                        <label for="admin_password">Admin Password</label>
                        <input type="password" class="form-control" id="admin_password" name="admin_password" required>
                    </div>
                    <div id="verify-password-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <i class="fa fa-times mr-1"></i>Cancel
                                        <button type="submit" class="btn btn-danger" id="verifyPasswordSubmitBtn">
                        <i class="fa fa-lock mr-1"></i>Verify and Proceed
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    class MultiSelectHandler {
        constructor(containerId, selectId, counterSelector) {
            this.container = document.getElementById(containerId);
            this.select = document.getElementById(selectId);
            this.counter = document.querySelector(counterSelector);
            this.selectedValues = new Set();
            this.init();
        }

        init() {
            // Add click listeners to option cards
            this.container.querySelectorAll('.option-card').forEach(card => {
                card.addEventListener('click', () => this.toggleOption(card));
            });

            // Add focus/blur events for container styling
            this.container.addEventListener('click', () => {
                this.container.classList.add('focused');
            });

            document.addEventListener('click', (e) => {
                if (!this.container.contains(e.target)) {
                    this.container.classList.remove('focused');
                }
            });
        }

        toggleOption(card) {
            const value = card.dataset.value;
            
            if (this.selectedValues.has(value)) {
                this.selectedValues.delete(value);
                card.classList.remove('selected');
            } else {
                this.selectedValues.add(value);
                card.classList.add('selected');
            }

            this.updateSelect();
            this.updateCounter();
            this.addAnimation(card);
        }

        addAnimation(card) {
            card.style.transform = 'scale(0.95)';
            setTimeout(() => {
                card.style.transform = card.classList.contains('selected') ? 'scale(1.02)' : 'scale(1)';
            }, 100);
        }

        updateSelect() {
            // Clear all selected options
            Array.from(this.select.options).forEach(option => {
                option.selected = this.selectedValues.has(option.value);
            });
        }

        updateCounter() {
            const count = this.selectedValues.size;
            this.counter.textContent = `${count} selected`;
            
            if (count > 0) {
                this.counter.style.background = '#e3f2fd';
                this.counter.style.color = '#1976d2';
                this.counter.style.fontWeight = '600';
            } else {
                this.counter.style.background = 'white';
                this.counter.style.color = '#6c757d';
                this.counter.style.fontWeight = 'normal';
            }
        }

        setValues(values) {
            // Clear current selection
            this.selectedValues.clear();
            this.container.querySelectorAll('.option-card').forEach(card => {
                card.classList.remove('selected');
            });

            // Set new values
            values.forEach(value => {
                this.selectedValues.add(value);
                const card = this.container.querySelector(`[data-value="${value}"]`);
                if (card) {
                    card.classList.add('selected');
                }
            });

            this.updateSelect();
            this.updateCounter();
        }

        reset() {
            this.selectedValues.clear();
            this.container.querySelectorAll('.option-card').forEach(card => {
                card.classList.remove('selected');
            });
            this.updateSelect();
            this.updateCounter();
        }
    }

    // Enhanced File Upload Handler
    class FileUploadHandler {
        constructor(uploadAreaId, fileInputId, previewId) {
            this.uploadArea = document.getElementById(uploadAreaId);
            this.fileInput = document.getElementById(fileInputId);
            this.preview = document.getElementById(previewId);
            this.init();
        }

        init() {
            // Click to upload
            this.uploadArea.addEventListener('click', () => {
                this.fileInput.click();
            });

            // File input change
            this.fileInput.addEventListener('change', (e) => {
                this.handleFile(e.target.files[0]);
            });

            // Drag and drop
            this.uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                this.uploadArea.classList.add('dragover');
            });

            this.uploadArea.addEventListener('dragleave', () => {
                this.uploadArea.classList.remove('dragover');
            });

            this.uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                this.uploadArea.classList.remove('dragover');
                this.handleFile(e.dataTransfer.files[0]);
            });

            // Remove file button
            const removeBtn = this.preview.querySelector('button');
            if (removeBtn) {
                removeBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.removeFile();
                });
            }
        }

        handleFile(file) {
            if (!file) return;

            if (!file.type.startsWith('image/')) {
                Swal.fire('Error!', 'Please select an image file.', 'error');
                return;
            }

            if (file.size > 5 * 1024 * 1024) { // 5MB
                Swal.fire('Error!', 'File size must be less than 5MB.', 'error');
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                this.showPreview(e.target.result, file.name);
            };
            reader.readAsDataURL(file);
        }

        showPreview(src, fileName) {
            const img = this.preview.querySelector('img');
            const nameElement = this.preview.querySelector('small');
            
            img.src = src;
            nameElement.textContent = fileName;
            this.preview.style.display = 'block';
        }

        removeFile() {
            this.fileInput.value = '';
            this.preview.style.display = 'none';
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        let userTable = null;
        let currentAction = '';
        let userToUpdate = {};
        let userToChangePassword = null;

        // Initialize multi-select handlers
        const addRolesHandler = new MultiSelectHandler('add_roles_container', 'add_role', '#add_roles_counter');
        const addCategoriesHandler = new MultiSelectHandler('add_categories_container', 'add_category', '#add_categories_counter');
        const editRolesHandler = new MultiSelectHandler('edit_roles_container', 'edit_role', '#edit_roles_counter');
        const editCategoriesHandler = new MultiSelectHandler('edit_categories_container', 'edit_category', '#edit_categories_counter');

        // Initialize file upload handlers
        const addFileHandler = new FileUploadHandler('add_file_upload_area', 'add_e_signiture', 'add_file_preview');

        // Function to initialize the DataTable
        function initializeUserTable() {
            $('#loading').show();
            $('#users-table-container').hide();
            $('#error-message').hide();

            userTable = $('#users-table').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "fetch_user.php",
                    "type": "GET",
                    "dataSrc": "data",
                    "error": function (xhr, error, thrown) {
                        $('#loading').hide();
                        $('#users-table-container').hide();
                        $('#error-message').text("Failed to load user data. Please check the server response and the console for details.").show();
                        console.error("AJAX error:", error, thrown);
                        console.log("Server response:", xhr.responseText);
                    }
                },
                "columns": [
                    { "data": "id" },
                    { "data": "username" },
                    { "data": "requestor_name" },
                    { "data": "email" },
                    {
                        "data": "role",
                        "render": function (data) {
                            const roles = data ? data.split(',').map(role => role.trim()) : [];
                            return roles.map(role => {
                                let badgeClass = 'badge-primary';
                                if (role === 'admin') {
                                    badgeClass = 'badge-danger';
                                } else if (role === 'checker') {
                                    badgeClass = 'badge-info';
                                } else if (role === 'approver') {
                                    badgeClass = 'badge-success';
                                } else if (role === 'noter') {
                                    badgeClass = 'badge-warning';
                                }
                                return `<span class="badge ${badgeClass} mr-1">${role.charAt(0).toUpperCase() + role.slice(1)}</span>`;
                            }).join('');
                        }
                    },
                    { "data": "department" },
                    {
                        "data": "category",
                        "render": function(data) {
                            if (data) {
                                const categories = data.split(',').map(cat => cat.trim());
                                return categories.map(cat => `<span class="badge badge-secondary mr-1">${cat}</span>`).join('');
                            }
                            return '';
                        }
                    },
                    { "data": "created_at" },
                    {
                        "data": null,
                        "orderable": false,
                        "searchable": false,
                        "render": function (data, type, row) {
                            return `
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        More
                                    </button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item edit-user" href="#" data-id="${row.id}">
                                            <i class="fa fa-edit text-info mr-2"></i> Update User
                                        </a>
                                        <a class="dropdown-item change-password" href="#" data-id="${row.id}">
                                            <i class="fa fa-key text-warning mr-2"></i> Change Password
                                        </a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item delete-user" href="#" data-id="${row.id}">
                                            <i class="fa fa-trash text-danger mr-2"></i> Delete User
                                        </a>
                                    </div>
                                </div>
                            `;
                        }
                    }
                ],
                "dom": '<"row"<"col-md-12 text-center"B>>' +
                    '<"row"<"col-md-6"l><"col-md-6"f>>' +
                    '<"row"<"col-md-12"t>>' +
                    '<"row"<"col-md-5"i><"col-md-7"p>>',
                "buttons": [
                    'copy', 'csv', 'excel', 'pdf', 'print',
                    {
                        extend: 'colvis',
                        text: 'Column Visibility'
                    }
                ],
                "lengthMenu": [[10, 20, 30, -1], [10, 20, 30, "All"]],
                "pageLength": 10,
                "initComplete": function () {
                    $('#loading').hide();
                    $('#users-table-container').show();
                },
                "drawCallback": function () {
                    $('#loading').hide();
                    $('#users-table-container').show();
                }
            });
        }

        initializeUserTable();

        // Event Listeners
        $('#add_id_number').on('input', function() {
            $('#add_username').val($(this).val());
        });

        $('#addUserButton').click(function () {
            $('#addUserForm')[0].reset();
            addRolesHandler.reset();
            addCategoriesHandler.reset();
            addFileHandler.removeFile();
            $('#addUserModal').modal('show');
        });

        // Handle delete button click
        $('#users-table').on('click', '.delete-user', function () {
            const userId = $(this).data('id');
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'delete_user.php',
                        type: 'POST',
                        data: { user_id: userId },
                        dataType: 'json',
                        success: function (response) {
                            if (response.success) {
                                Swal.fire('Deleted!', 'The user has been deleted.', 'success');
                                userTable.ajax.reload();
                            } else {
                                Swal.fire('Failed!', response.message || 'There was an error deleting the user.', 'error');
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire('Error!', 'An error occurred while communicating with the server.', 'error');
                            console.error("AJAX Error:", status, error, xhr.responseText);
                        }
                    });
                }
            });
        });

        // Handle Add User Form Submission
        $('#addUserForm').submit(function (e) {
            e.preventDefault();
            const selectedRoles = Array.from(addRolesHandler.selectedValues);
            
            if (selectedRoles.includes('admin')) {
                currentAction = 'add';
                $('#addUserModal').modal('hide');
                $('#verifyPasswordModal').modal('show');
                $('#admin_password').val('');
            } else {
                submitAddUserForm();
            }
        });

        // Handle Edit button click
        $('#users-table').on('click', '.edit-user', function () {
            const userId = $(this).data('id');
            $.ajax({
                url: 'get_user_update.php',
                type: 'GET',
                data: { user_id: userId },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        userToUpdate = response.data;
                        $('#edit_user_id').val(userToUpdate.id);
                        $('#edit_id_number').val(userToUpdate.id_number);
                        $('#edit_username').val(userToUpdate.id_number);
                        $('#edit_requestor_name').val(userToUpdate.requestor_name);
                        $('#edit_department').val(userToUpdate.department);
                        $('#edit_email').val(userToUpdate.email);
                        
                        // Set categories using the new handler
                        const categories = userToUpdate.category ? userToUpdate.category.split(',').map(cat => cat.trim()) : [];
                        editCategoriesHandler.setValues(categories);
                        
                        // Set roles using the new handler
                        const roles = userToUpdate.role ? userToUpdate.role.split(',').map(role => role.trim()) : [];
                        editRolesHandler.setValues(roles);

                        currentAction = 'edit';
                        $('#editUserModal').modal('show');
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function (xhr, status, error) {
                    Swal.fire('Error!', 'An error occurred fetching user data.', 'error');
                    console.error("AJAX Error:", status, error, xhr.responseText);
                }
            });
        });

        // Handle Edit User Form Submission
        $('#editUserForm').submit(function (e) {
            e.preventDefault();
            const newRoles = Array.from(editRolesHandler.selectedValues);
            const oldRoles = userToUpdate.role ? userToUpdate.role.split(',').map(role => role.trim()) : [];
            const newIsAdmin = newRoles.includes('admin');
            const oldIsAdmin = oldRoles.includes('admin');

            if (newIsAdmin && !oldIsAdmin) {
                currentAction = 'edit';
                $('#editUserModal').modal('hide');
                $('#verifyPasswordModal').modal('show');
                $('#admin_password').val('');
            } else {
                submitUpdateUserForm();
            }
        });

        // Handle Change Password Button Click
        $('#users-table').on('click', '.change-password', function () {
            userToChangePassword = $(this).data('id');
            $('#changePasswordForm')[0].reset();
            $('#change_password_user_id').val(userToChangePassword);
            $('#changePasswordModal').modal('show');
        });

        // Handle Change Password Form Submission
        $('#changePasswordForm').submit(function (e) {
            e.preventDefault();
            const newPassword = $('#new_password').val();
            const confirmNewPassword = $('#confirm_new_password').val();

            if (newPassword !== confirmNewPassword) {
                Swal.fire('Error!', 'New password and confirmation do not match.', 'error');
                return;
            }

            currentAction = 'change_password';
            $('#changePasswordModal').modal('hide');
            $('#verifyPasswordModal').modal('show');
            $('#admin_password').val('');
        });

        // Handle Password Verification Form Submission
        $('#verifyPasswordForm').submit(function (e) {
            e.preventDefault();
            const adminPassword = $('#admin_password').val();
            const verifyBtn = $('#verifyPasswordSubmitBtn');
            verifyBtn.prop('disabled', true).text('Verifying...');

            $.ajax({
                url: 'verify_admin_password.php',
                type: 'POST',
                data: { admin_password: adminPassword },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        $('#verifyPasswordModal').modal('hide');
                        if (currentAction === 'add') {
                            submitAddUserForm();
                        } else if (currentAction === 'edit') {
                            submitUpdateUserForm();
                        } else if (currentAction === 'change_password') {
                            submitChangePasswordForm();
                        }
                    } else {
                        $('#verify-password-message').removeClass('alert-success').addClass('alert-danger').text(response.message).show();
                    }
                },
                error: function (xhr, status, error) {
                    $('#verify-password-message').removeClass('alert-success').addClass('alert-danger').text('An error occurred during verification.').show();
                    console.error("Verification AJAX Error:", status, error, xhr.responseText);
                },
                complete: function () {
                    verifyBtn.prop('disabled', false).html('<i class="fa fa-lock mr-1"></i>Verify and Proceed');
                }
            });
        });

        // Form submission functions (keeping your existing logic)
        function submitAddUserForm() {
            const form = $('#addUserForm');
            const submitBtn = $('#addUserSubmitBtn');
            submitBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin mr-1"></i>Adding...');

            const formData = new FormData(form[0]);

            $.ajax({
                url: 'add_user.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                processData: false, 
                contentType: false, 
                success: function (response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'User Added!',
                            text: 'The new user has been added successfully.',
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            $('#addUserModal').modal('hide');
                            userTable.ajax.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: response.message || 'Error adding user.',
                        });
                    }
                },
                error: function (xhr, status, error) {
                    let errorMsg = 'An error occurred. Please try again.';
                    if (xhr.responseText) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            errorMsg = response.message || errorMsg;
                        } catch (e) {
                            console.error("Non-JSON response from add_user.php");
                        }
                    }
                    Swal.fire({
                        icon: 'error',
                        title: 'An Error Occurred',
                        text: errorMsg,
                    });
                    console.error("AJAX Error:", status, error, xhr.responseText);
                },
                complete: function () {
                    submitBtn.prop('disabled', false).html('<i class="fa fa-user-plus mr-1"></i>Add User');
                }
            });
        }

        function submitUpdateUserForm() {
            const form = $('#editUserForm');
            const submitBtn = $('#editUserSubmitBtn');
            submitBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin mr-1"></i>Saving...');
            const formData = form.serialize();

            $.ajax({
                url: 'update_user.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'User Updated!',
                            text: 'The user data has been updated successfully.',
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            $('#editUserModal').modal('hide');
                            userTable.ajax.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: response.message || 'Error updating user.',
                        });
                    }
                },
                error: function (xhr, status, error) {
                    let errorMsg = 'An error occurred. Please try again.';
                    if (xhr.responseText) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            errorMsg = response.message || errorMsg;
                        } catch (e) {
                            console.error("Non-JSON response from update_user.php");
                        }
                    }
                    Swal.fire({
                        icon: 'error',
                        title: 'An Error Occurred',
                        text: errorMsg,
                    });
                    console.error("AJAX Error:", status, error, xhr.responseText);
                },
                complete: function () {
                    submitBtn.prop('disabled', false).html('<i class="fa fa-save mr-1"></i>Save Changes');
                }
            });
        }

        function submitChangePasswordForm() {
            const form = $('#changePasswordForm');
            const submitBtn = $('#changePasswordSubmitBtn');
            submitBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin mr-1"></i>Changing...');

            $.ajax({
                url: 'change_user_password.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Password Changed!',
                            text: 'The user\'s password has been updated successfully.',
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            $('#changePasswordModal').modal('hide');
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: response.message || 'Error changing password.',
                        });
                    }
                },
                error: function (xhr, status, error) {
                    let errorMsg = 'An error occurred. Please try again.';
                    if (xhr.responseText) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            errorMsg = response.message || errorMsg;
                        } catch (e) {
                            console.error("Non-JSON response from change_user_password.php");
                        }
                    }
                    Swal.fire({
                        icon: 'error',
                        title: 'An Error Occurred',
                        text: errorMsg,
                    });
                    console.error("AJAX Error:", status, error, xhr.responseText);
                },
                complete: function () {
                    submitBtn.prop('disabled', false).html('<i class="fa fa-key mr-1"></i>Change Password');
                }
            });
        }
    });
</script>
                    