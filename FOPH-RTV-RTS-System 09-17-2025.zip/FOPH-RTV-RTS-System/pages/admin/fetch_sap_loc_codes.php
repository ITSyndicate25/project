<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

// Only allow logged-in admin users
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

header('Content-Type: application/json');

// Change from $_GET to $_POST to match the AJAX request type
$params = $_POST;

// Call the function
$response = getSapLocCodes($params);

echo json_encode($response);
exit();
?>