<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/includes/functions.php';

header('Content-Type: application/json');

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

$user_id = $_GET['user_id'] ?? null;

// Call the function
$result = getUserData($user_id);

// If the signature data exists, encode it in base64 for JSON transport
if (isset($result['data']['e_signiture']) && $result['data']['e_signiture'] !== null) {
    $result['data']['e_signiture_base64'] = base64_encode($result['data']['e_signiture']);
    unset($result['data']['e_signiture']); // Unset the original binary data
}

// Return the result as a JSON response
echo json_encode($result);
?>