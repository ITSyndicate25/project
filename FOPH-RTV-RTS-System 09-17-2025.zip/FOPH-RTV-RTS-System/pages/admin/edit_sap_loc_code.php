<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/includes/functions.php';

header('Content-Type: application/json');

// Check for admin role
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

// Get and sanitize POST data
$location_code = trim($_POST['location_code'] ?? '');
$location_name = trim($_POST['location_name'] ?? '');
$department = trim($_POST['department'] ?? '');
$original_location_code = trim($_POST['original_location_code'] ?? '');

$result = updateSapLocCode($original_location_code, $location_code, $location_name, $department);

echo json_encode($result);
exit();
?>