<?php

// Application settings
define('APP_NAME', 'Centralized RTV & RTS Monitoring System');
define('APP_VERSION', '1.0.0');
define('BASE_URL', '/FOPH-RTV-RTS-System');
// Application directories
define('APP_ROOT', $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System');
define('ASSETS_PATH', APP_ROOT . '/assets');
define('INCLUDES_PATH', APP_ROOT . '/includes');
define('PAGES_PATH', APP_ROOT . '/pages');

?>