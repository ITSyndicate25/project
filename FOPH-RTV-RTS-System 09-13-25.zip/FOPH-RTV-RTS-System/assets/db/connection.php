<?php

class Connection
{
    public $link;
    public $centralizedLink;

    public function __construct()
    {
        $conn_array = array(
            "UID" => "sa",
            "PWD" => "kim123",
            "Database" => "dbfophcrtvsproject",
            "CharacterSet" => "UTF-8"
        );

        $this->link = sqlsrv_connect('localhost\SQLEXPRESS', $conn_array);

        if ($this->link === false) {
            die('Could not connect to dbfophcrtvsproject: ' . print_r(sqlsrv_errors(), true));
        }
    }

        public function insertImage() {
            $connArray2 = array (
            "UID" => "sa",
                "PWD" => "kim123",
                "Database" => "dbfophcrtvsproject",
                );
    
        
            $this->link = sqlsrv_connect('localhost\SQLEXPRES', $connArray2);
        
            if ($this->link === false) {
                die('Could not connect to the second database: ' . print_r(sqlsrv_errors(), true));
            }
        }

    public function close()
    {
        if ($this->link) {
            sqlsrv_close($this->link);
        }
        if ($this->centralizedLink) {
            sqlsrv_close($this->centralizedLink);
        }
    }

    public function query($sql)
    {
        return sqlsrv_query($this->link, $sql);
    }

}

?>