<?php
session_start();
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not authenticated.']);
    exit();
}

$current_user_id = $_SESSION['user_id'];
$user_roles = explode(',', $_SESSION['user_role']);

try {
    $db = new Connection();
    $conn = $db->link;

    $draw = $_POST['draw'] ?? 1;
    $start = intval($_POST['start'] ?? 0);
    $length = intval($_POST['length'] ?? 10);
    $search_value = $_POST['search']['value'] ?? '';

    // Build dynamic query based on user roles
    $conditions = [];
    $union_queries = [];
    
    if (in_array('checker', $user_roles)) {
        $union_queries[] = "
            SELECT id, control_no, requestor_name, requestor_department, created_at, 'Check' as action_required, 'RTS Form' as form_type
            FROM rts_forms
            WHERE checked_status = 'Pending' AND material_status = 'Pending'
        ";
    }
    
    if (in_array('approver', $user_roles)) {
        $union_queries[] = "
            SELECT id, control_no, requestor_name, requestor_department, created_at, 'Approve' as action_required, 'RTS Form' as form_type
            FROM rts_forms
            WHERE approved_status = 'Pending' AND checked_status = 'Approved' AND material_status IN ('Pending', 'In-Progress')
        ";
    }
    
    if (in_array('noter', $user_roles)) {
        $union_queries[] = "
            SELECT id, control_no, requestor_name, requestor_department, created_at, 'Note' as action_required, 'RTS Form' as form_type
            FROM rts_forms
            WHERE noted_status = 'Pending' AND approved_status = 'Approved' AND material_status IN ('Pending', 'In-Progress')
        ";
    }

    // TODO: Add similar queries for NG Forms and Coil and Solder Forms when those tables are created
    // Example:
    // if (in_array('checker', $user_roles)) {
    //     $union_queries[] = "
    //         SELECT id, control_no, requestor_name, requestor_department, created_at, 'Check' as action_required, 'NG Form' as form_type
    //         FROM ng_forms
    //         WHERE checked_status = 'Pending' AND material_status = 'Pending'
    //     ";
    // }

    if (empty($union_queries)) {
        echo json_encode([
            'status' => 'success',
            'draw' => intval($draw),
            'recordsTotal' => 0,
            'recordsFiltered' => 0,
            'data' => []
        ]);
        exit();
    }

    $base_query = "(" . implode(" UNION ALL ", $union_queries) . ") AS combined_results";
    
    // Add search conditions
    $search_conditions = "";
    $query_params = [];
    if (!empty($search_value)) {
        $search_param = '%' . $search_value . '%';
        $search_conditions = " WHERE (control_no LIKE ? OR requestor_name LIKE ? OR requestor_department LIKE ? OR form_type LIKE ?)";
        $query_params = [$search_param, $search_param, $search_param, $search_param];
    }

    // Count total records
    $sql_total = "SELECT COUNT(*) FROM " . $base_query . $search_conditions;
    $stmt_total = sqlsrv_query($conn, $sql_total, $query_params);
    $total_records = 0;
    if ($stmt_total && sqlsrv_fetch($stmt_total)) {
        $total_records = sqlsrv_get_field($stmt_total, 0);
    }

    // Final query with pagination
    $sql_final = "
        SELECT * FROM " . $base_query . "
        " . $search_conditions . "
        ORDER BY created_at DESC
        OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
    
    $query_params[] = $start;
    $query_params[] = $length;

    $stmt = sqlsrv_query($conn, $sql_final, $query_params);

    if ($stmt === false) {
        throw new Exception("Database query failed: " . print_r(sqlsrv_errors(), true));
    }

    $data = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if (isset($row['created_at']) && $row['created_at'] instanceof DateTime) {
            $row['created_at'] = $row['created_at']->format('Y-m-d H:i:s');
        }
        $data[] = $row;
    }

    echo json_encode([
        'status' => 'success',
        'draw' => intval($draw),
        'recordsTotal' => intval($total_records),
        'recordsFiltered' => intval($total_records),
        'data' => $data
    ]);

    $db->close();

} catch (Exception $e) {
    error_log("Error in fetch_pending_approvals: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'An internal server error occurred.']);
}