<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/includes/functions.php';

// Check if user is logged in and has approver role(s)
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

$allowed_roles = ['checker', 'approver', 'noter'];
$user_roles = explode(',', $_SESSION['user_role']); // Handle multiple roles
$has_approver_role = false;

foreach ($user_roles as $role) {
    if (in_array(trim($role), $allowed_roles)) {
        $has_approver_role = true;
        break;
    }
}

if (!$has_approver_role) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

// Get dashboard data for the logged-in approver
$user_id = $_SESSION['user_id'];
$dashboard_data = getApproverDashboardData($user_id, $user_roles);
$username = htmlspecialchars(ucfirst($dashboard_data['username']));
$today = $dashboard_data['today'];
?>

<?php include '../../includes/header.php'; ?>

<div class="wrapper">
    <?php include '../../includes/sidebar.php'; ?>
    <div class="main-panel">
        <?php include '../../includes/navbar.php'; ?>
        <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card card-stats">
                        <div class="card-header">
                            <h5 class="card-title">Welcome, <?php echo $username; ?>!</h5>
                            <p class="card-category">Today is <?php echo $today; ?></p>
                            <p class="card-category">Your roles: <?php echo implode(', ', array_map('ucfirst', $user_roles)); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Show role-specific stats -->
                <?php if (in_array('checker', $user_roles)): ?>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center icon-warning">
                                        <i class="nc-icon nc-ruler-pencil text-warning"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers">
                                        <p class="card-category">Pending for Checking</p>
                                        <p class="card-title"><?php echo $dashboard_data['pending_checking']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <?php if ($dashboard_data['pending_checking'] > 0): ?>
                                    <i class="fa fa-clock text-warning"></i>
                                    <span class="text-warning">Awaiting your review</span>
                                <?php else: ?>
                                    <i class="fa fa-check text-success"></i>
                                    <span class="text-success">All checked</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (in_array('approver', $user_roles)): ?>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center icon-warning">
                                        <i class="nc-icon nc-badge text-info"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers">
                                        <p class="card-category">Pending for Approval</p>
                                        <p class="card-title"><?php echo $dashboard_data['pending_approval']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <?php if ($dashboard_data['pending_approval'] > 0): ?>
                                    <i class="fa fa-clock text-info"></i>
                                    <span class="text-info">Awaiting your approval</span>
                                <?php else: ?>
                                    <i class="fa fa-check text-success"></i>
                                    <span class="text-success">All approved</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (in_array('noter', $user_roles)): ?>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center icon-warning">
                                        <i class="nc-icon nc-notes text-primary"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers">
                                        <p class="card-category">Pending for Noting</p>
                                        <p class="card-title"><?php echo $dashboard_data['pending_noting']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <?php if ($dashboard_data['pending_noting'] > 0): ?>
                                    <i class="fa fa-clock text-primary"></i>
                                    <span class="text-primary">Awaiting your notation</span>
                                <?php else: ?>
                                    <i class="fa fa-check text-success"></i>
                                    <span class="text-success">All noted</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Summary Cards -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center icon-warning">
                                        <i class="nc-icon nc-chart-bar-32 text-success"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers">
                                        <p class="card-category">Total Processed</p>
                                        <p class="card-title"><?php echo $dashboard_data['total_processed']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <i class="fa fa-calendar"></i> This month
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center icon-warning">
                                        <i class="nc-icon nc-simple-remove text-danger"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers">
                                        <p class="card-category">Disapproved</p>
                                        <p class="card-title"><?php echo $dashboard_data['total_disapproved']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr>
                            <div class="stats">
                                <i class="fa fa-calendar"></i> This month
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row" id="pendingActionsSection">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Pending Actions</h5>
                            <p class="card-category">
                                <?php if (($dashboard_data['pending_checking'] ?? 0) > 0 || 
                                         ($dashboard_data['pending_approval'] ?? 0) > 0 || 
                                         ($dashboard_data['pending_noting'] ?? 0) > 0): ?>
                                    Forms requiring your action
                                <?php else: ?>
                                    No pending actions at this time
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table" id="approverPendingTable">
                                    <thead class="text-primary">
                                        <th>Request ID</th>
                                        <th>Form Type</th>
                                        <th>Requestor</th>
                                        <th>Department</th>
                                        <th>Action Required</th>
                                        <th>Submitted At</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Recent Activities</h5>
                            <p class="card-category">Your recent approvals and actions</p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table" id="approverRecentTable">
                                    <thead class="text-primary">
                                        <th>Control No</th>
                                        <th>Requestor</th>
                                        <th>Your Action</th>
                                        <th>Action Date</th>
                                        <th>Current Status</th>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include '../../includes/footer.php'; ?>
    </div>
</div>

<style>
    #approverPendingTable_wrapper, #approverRecentTable_wrapper {
        width: 100%;
    }
    #approverPendingTable, #approverRecentTable {
        width: 100% !important;
    }
</style>

<!-- Update the pending actions table action column in the script section -->
<script>
$(document).ready(function() {
    // Check if there are any pending actions based on the dashboard stats
    const hasPendingActions = <?php echo json_encode(
        ($dashboard_data['pending_checking'] ?? 0) > 0 || 
        ($dashboard_data['pending_approval'] ?? 0) > 0 || 
        ($dashboard_data['pending_noting'] ?? 0) > 0
    ); ?>;
    
    // Hide the pending actions table if no pending actions
    if (!hasPendingActions) {
        $('#pendingActionsSection').hide();
    }
    
    // Pending actions table
    $('#approverPendingTable').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo BASE_URL; ?>/pages/approver/fetch_pending_approvals.php",
            "type": "POST",
            "dataSrc": function(json) {
                // If no data, hide the table section
                if (!json.data || json.data.length === 0) {
                    $('#pendingActionsSection').fadeOut();
                } else {
                    $('#pendingActionsSection').fadeIn();
                }
                return json.data;
            }
        },
        "columns": [
            {"data": "control_no"},             // Request ID
            {"data": "form_type"},              // Form Type (RTS Form, etc.)
            {"data": "requestor_name"},         // Requestor
            {"data": "requestor_department"},   // Department
            {
                "data": "action_required",      // Action Required (Check/Approve/Note)
                "render": function(data, type, row) {
                    let badgeClass = 'badge-warning';
                    if (data === 'Check') badgeClass = 'badge-warning';
                    else if (data === 'Approve') badgeClass = 'badge-info';
                    else if (data === 'Note') badgeClass = 'badge-primary';
                    return `<span class="badge ${badgeClass}">${data}</span>`;
                }
            },
            {
                "data": "created_at",           // Submitted At
                "render": function(data, type, row) {
                    if (type === 'display' && data) {
                        const date = new Date(data);
                        return date.toLocaleString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: 'numeric',
                            minute: 'numeric',
                            hour12: true
                        });
                    }
                    return data;
                }
            },
            {
                "data": null,
                "orderable": false,
                "render": function(data, type, row) {
                    // Determine which page to redirect to based on action required
                    let redirectUrl = '';
                    let redirectParams = '';
                    
                    if (row.action_required === 'Check') {
                        // Checkers go to pending_requests.php
                        redirectUrl = '<?php echo BASE_URL; ?>/pages/requests/pending_requests.php';
                        redirectParams = `?id=${row.id}&type=${encodeURIComponent(row.form_type)}&action=${encodeURIComponent(row.action_required)}`;
                    } else if (row.action_required === 'Approve' || row.action_required === 'Note') {
                        // Approvers and Noters go to ongoing_requests.php
                        redirectUrl = '<?php echo BASE_URL; ?>/pages/requests/ongoing_requests.php';
                        redirectParams = `?id=${row.id}&type=${encodeURIComponent(row.form_type)}&action=${encodeURIComponent(row.action_required)}`;
                    }
                    
                    return `<a href="${redirectUrl}${redirectParams}" 
                                class="btn btn-sm btn-primary">
                                <i class="fa fa-eye"></i> View
                            </a>`;
                }
            }
        ],
        "order": [[5, "desc"]], // Sort by Submitted At
        "pageLength": 10,
        "drawCallback": function(settings) {
            // Check if table has any rows after drawing
            const api = this.api();
            const rowCount = api.rows({page: 'current'}).count();
            
            if (rowCount === 0) {
                // Add a "No pending actions" message
                $('#approverPendingTable tbody').html(
                    '<tr><td colspan="7" class="text-center text-muted">No pending actions at this time</td></tr>'
                );
            }
        }
    });

    // Recent activities table (keep the existing code)
    $('#approverRecentTable').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo BASE_URL; ?>/pages/approver/fetch_recent_activities.php",
            "type": "POST"
        },
        "columns": [
            {"data": "control_no"},
            {"data": "requestor_name"},
            {
                "data": "action_taken",
                "render": function(data, type, row) {
                    let badgeClass = 'badge-success';
                    if (data.includes('Disapproved')) badgeClass = 'badge-danger';
                    return `<span class="badge ${badgeClass}">${data}</span>`;
                }
            },
            {
                "data": "action_date",
                "render": function(data, type, row) {
                    if (type === 'display' && data) {
                        const date = new Date(data);
                        return date.toLocaleString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: 'numeric',
                            minute: 'numeric',
                            hour12: true
                        });
                    }
                    return data;
                }
            },
            {
                "data": "material_status",
                "render": function(data, type, row) {
                    let badgeClass = 'badge-secondary';
                    if (data === 'Completed') badgeClass = 'badge-success';
                    else if (data === 'In-Progress') badgeClass = 'badge-info';
                    else if (data === 'Disapproved') badgeClass = 'badge-danger';
                    return `<span class="badge ${badgeClass}">${data}</span>`;
                }
            }
        ],
        "order": [[3, "desc"]],
        "pageLength": 10
    });
});
</script>