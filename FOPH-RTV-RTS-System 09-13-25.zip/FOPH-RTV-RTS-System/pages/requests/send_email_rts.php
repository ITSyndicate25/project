<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';

require_once APP_ROOT . '/assets/db/connection.php';

require APP_ROOT . '/PHPMailer/src/PHPMailer.php';
require APP_ROOT . '/PHPMailer/src/SMTP.php';
require APP_ROOT . '/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Function for sending approval/disapproval notifications to the requestor
// Added the $approverName parameter to the function signature
function sendApprovalEmail(array $recipientEmails, string $control_no, string $action, string $role, string $approverName, ?string $reason) {
    if (empty($recipientEmails)) {
        error_log("Email sending aborted: No requestor email provided.");
        return;
    }

    // Remove "ed" from status - use action as is
    $subject_status = ucfirst($action);

    // Capitalize first letter of approver name and role
    $approverName = ucfirst($approverName);
    $role = ucfirst($role);

    $subject = "RTS Request (Control No: $control_no) has been $subject_status" . "d";

    $body_status = ucfirst($action) . "d";

    // Updated the body to include the name of the approver with capitalized first letters
    $body_action_text = "Your RTS request with control number <b>$control_no</b> has been <b>$body_status</b> by <b>$approverName</b> ($role).";

    $reason_text = "";

    if ($action === 'disapprove' && $reason) {
        $reason_text = "<p>Reason for disapproval: <i>" . htmlspecialchars($reason) . "</i></p>";
    }

    $message = "<p>Good Day,</p>";
    $message .= "<p>$body_action_text</p>";
    $message .= $reason_text;
    $message .= "<p>Please login to the system for more details.</p>";
    $message .= "<p>Thank you.</p>";
    $message .= "<br><p><i>This is an automated message. Please do not reply.</i></p>";

    $mail = new PHPMailer();

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.office365.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'foph.dc-noreply@007.fujifilm.com';
        $mail->Password = 'Fujifilm@4';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Correct the sender email to match the SMTP username
        $mail->setFrom('foph.dc-noreply@007.fujifilm.com', 'No-Reply');

        foreach ($recipientEmails as $email) {
            $mail->addAddress($email);
        }

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        ini_set('display_errors', 0);
        ini_set('display_startup_errors', 0);
        error_reporting(E_ALL);

        if ($mail->send()) {
            error_log("Notification email for $body_status sent to requestor for Control No: $control_no");
        } else {
            error_log("Notification email failed for Control No: $control_no. Error: " . $mail->ErrorInfo);
        }
    } catch (Exception $e) {
        error_log("Notification email exception for Control No: $control_no. Exception: " . $e->getMessage());
    }
}

?>