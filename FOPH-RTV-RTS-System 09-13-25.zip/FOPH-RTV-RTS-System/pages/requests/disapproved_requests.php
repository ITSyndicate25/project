<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

$user_role = $_SESSION['user_role'] ?? '';
$user_id = $_SESSION['user_id'] ?? null;
?>

<?php include INCLUDES_PATH . '/header.php'; ?>
<div class="wrapper">
    <?php include '../../includes/sidebar.php'; ?>
    <div class="main-panel">
        <?php include '../../includes/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="card-title m-0">Disapproved Requests</h4>
                            </div>
                            <div class="card-body">
                                <div id="loading" class="text-center">
                                    <i class="fa fa-spinner fa-spin fa-2x"></i>
                                    <p>Loading disapproved requests...</p>
                                </div>
                                <div id="error-message" class="alert alert-danger" style="display: none;"></div>
                                <div class="table-responsive" id="rts-requests-table-container" style="display: none;">
                                    <table id="rts-requests-table" class="table table-striped table-bordered"
                                        style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Request ID</th>
                                                <th>Form Type</th>
                                                <th>Created On</th>
                                                <th>Submitted By</th>
                                                <th>Checker Status</th>
                                                <th>Approver Status</th>
                                                <th>Noter Status</th>
                                                <th>Disapproved By</th>
                                                <th>Disapproval Reason</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include '../../includes/footer.php'; ?>
    </div>
</div>

<div class="modal fade" id="viewRTSModal" tabindex="-1" role="dialog" aria-labelledby="viewRTSModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewRTSModalLabel">Request Details</h5>
                <span class="badge badge-primary ml-2" id="formTypeBadge"></span>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="modal-body-content">
                <div class="text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        const userRole = "<?php echo $user_role; ?>";
        const userId = <?php echo json_encode($user_id); ?>;

        // Initialize DataTables
        const rtsTable = $('#rts-requests-table').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "fetch_requests_rts.php",
                "type": "POST",
                "data": function (d) {
                    d.user_role = userRole;
                    d.user_id = userId;
                    d.request_type = 'disapproved';
                },
                "dataSrc": function (json) {
                    if (json.status === 'success') {
                        $('#loading').hide();
                        $('#rts-requests-table-container').show();
                        return json.data;
                    } else {
                        $('#loading').hide();
                        $('#error-message').text(json.message).show();
                        return [];
                    }
                },
                "error": function (xhr, status, error) {
                    $('#loading').hide();
                    $('#error-message').text('An error occurred while fetching data. Please try again.').show();
                    console.error("DataTables AJAX Error:", status, error);
                }
            },
            "columns": [
                { "data": "rts_no" },
                {
                    "data": "form_type",
                    "render": function (data) {
                        let badgeClass = 'badge-secondary';
                        if (data === 'RTS Form') badgeClass = 'badge-primary';
                        else if (data === 'NG Form') badgeClass = 'badge-warning';
                        else if (data === 'Coil and Solder Form') badgeClass = 'badge-info';
                        return `<span class="badge ${badgeClass}">${data}</span>`;
                    }
                },
                { "data": "created_at" },
                { "data": "submitted_by" },
                {
                    "data": "checked_status",
                    "defaultContent": "N/A",
                    "render": function (data) {
                        let badgeClass = '';
                        if (data === 'Approved') badgeClass = 'badge-success';
                        else if (data === 'Pending') badgeClass = 'badge-warning';
                        else if (data === 'Disapproved') badgeClass = 'badge-danger';
                        else badgeClass = 'badge-secondary';
                        return `<span class="badge ${badgeClass}">${data || 'N/A'}</span>`;
                    }
                },
                {
                    "data": "approved_status",
                    "defaultContent": "N/A",
                    "render": function (data) {
                        let badgeClass = '';
                        if (data === 'Approved') badgeClass = 'badge-success';
                        else if (data === 'Pending') badgeClass = 'badge-warning';
                        else if (data === 'Disapproved') badgeClass = 'badge-danger';
                        else badgeClass = 'badge-secondary';
                        return `<span class="badge ${badgeClass}">${data || 'N/A'}</span>`;
                    }
                },
                {
                    "data": "noted_status",
                    "defaultContent": "N/A",
                    "render": function (data) {
                        let badgeClass = '';
                        if (data === 'Approved') badgeClass = 'badge-success';
                        else if (data === 'Pending') badgeClass = 'badge-warning';
                        else if (data === 'Disapproved') badgeClass = 'badge-danger';
                        else badgeClass = 'badge-secondary';
                        return `<span class="badge ${badgeClass}">${data || 'N/A'}</span>`;
                    }
                },
                { 
                    "data": "disapproved_by_role",
                    "defaultContent": "N/A",
                    "render": function (data) {
                        if (data) {
                            const capitalizedData = data.charAt(0).toUpperCase() + data.slice(1);
                            return `<span class="badge badge-info">${capitalizedData}</span>`;
                        }
                        return `<span class="badge badge-danger">N/A</span>`;
                    }
                },
                { "data": "disapproval_reason" },
                {
                    "data": null,
                    "orderable": false,
                    "searchable": false,
                    "render": function (data, type, row) {
                        return `<button type="button" class="btn btn-info btn-sm" onclick="viewRTS(${row.id}, '${row.rts_no}', '${row.overall_status}', '${row.form_type}')"><i class="fa fa-eye"></i> View</button>`;
                    }
                }
            ],
            "dom": "<'row'<'col-md-12'B>><'row'<'col-md-6'l><'col-md-6'f>>rtip",
            "buttons": [
                'copy', 'csv', 'excel', 'pdf', 'print', 'colvis'
            ],
            "initComplete": function (settings, json) {
                $('#loading').hide();
                $('#rts-requests-table-container').show();
            }
        });

        let currentRTSNo = '';
        let currentFormType = '';

        window.viewRTS = function (rtsId, rtsNo, overallStatus, formType = 'RTS Form') {
            currentRTSNo = rtsNo;
            currentFormType = formType;
            
            // Update modal title and badge
            $('#viewRTSModalLabel').text(`${formType} Details`);
            $('#formTypeBadge').text(formType);
            
            const modalBody = document.getElementById('modal-body-content');
            modalBody.innerHTML = `
                <div class="text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>`;

            // Determine which view file to load based on form type
            let viewUrl = '';
            if (formType === 'RTS Form') {
                viewUrl = `view_rts.php?id=${rtsId}&status=${overallStatus}`;
            } else if (formType === 'NG Form') {
                viewUrl = `view_ng.php?id=${rtsId}&status=${overallStatus}`;
            } else if (formType === 'Coil and Solder Form') {
                viewUrl = `view_coil_solder.php?id=${rtsId}&status=${overallStatus}`;
            } else {
                modalBody.innerHTML = `<div class="alert alert-danger">Unknown form type: ${formType}</div>`;
                $('#viewRTSModal').modal('show');
                return;
            }

            fetch(viewUrl)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Network response was not ok, status: ${response.status}`);
                    }
                    return response.text();
                })
                .then(html => {
                    modalBody.innerHTML = html;
                    $('#viewRTSModal').modal('show');
                })
                .catch(error => {
                    console.error('There has been a problem with your fetch operation:', error);
                    modalBody.innerHTML = `<div class="alert alert-danger">Failed to load content. ${error.message}</div>`;
                });
        }
        
        // PDF GENERATION SCRIPT
        $('#viewRTSModal').on('click', '#downloadPdfBtn', async function(e) {
            e.preventDefault();
            const pdfContent = document.getElementById('pdf-content');
        
            const elementsToHide = document.querySelectorAll(
                '#viewRTSModal .approval-details-section, ' +
                '#viewRTSModal .modal-footer, ' +
                '#viewRTSModal .modal-header .close, ' +
                '#headingMaterial' 
            );
        
            const rtsNo = currentRTSNo || 'Request';
            const pdfFileName = `${rtsNo}.pdf`;
            
            const originalDisplays = {};
            elementsToHide.forEach(el => {
                originalDisplays[el] = el.style.display;
                el.style.display = 'none';
            });
        
            await new Promise(resolve => setTimeout(resolve, 50));
            
            try {
                const canvas = await html2canvas(pdfContent, {
                    scale: 2,
                    logging: true,
                    useCORS: true
                });
        
                const imgData = canvas.toDataURL('image/png');
                const { jsPDF } = window.jspdf;
                const pdf = new jsPDF('p', 'mm', 'a4');
                const imgWidth = 210;
                const pageHeight = 295;
                const imgHeight = canvas.height * imgWidth / canvas.width;
                let heightLeft = imgHeight;
                let position = 0;
                
                pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                heightLeft -= pageHeight;
                
                while (heightLeft >= 0) {
                    position = heightLeft - imgHeight;
                    pdf.addPage();
                    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                    heightLeft -= pageHeight;
                }
                
                pdf.save(pdfFileName);
            } catch (error) {
                console.error('Error generating PDF:', error);
                Swal.fire({
                    title: 'Error!',
                    text: 'Failed to generate PDF. Please try again.',
                    icon: 'error'
                });
            } finally {
                elementsToHide.forEach(el => {
                    el.style.display = originalDisplays[el];
                });
            }
        });

        $('#viewRTSModal').on('hidden.bs.modal', function () {
            currentRTSNo = '';
            currentFormType = '';
            document.getElementById('modal-body-content').innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>`;
        });
    });
</script>