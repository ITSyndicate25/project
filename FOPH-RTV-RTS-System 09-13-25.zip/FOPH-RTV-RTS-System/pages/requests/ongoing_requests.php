<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

$user_role = $_SESSION['user_role'] ?? '';
$user_id = $_SESSION['user_id'] ?? null;
?>

<?php include INCLUDES_PATH . '/header.php'; ?>
<div class="wrapper">
    <?php include '../../includes/sidebar.php'; ?>
    <div class="main-panel">
        <?php include '../../includes/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="card-title m-0">
                                    <?php
                                    if (str_contains($user_role, 'checker') || str_contains($user_role, 'approver') || str_contains($user_role, 'noter')) {
                                        echo 'Ongoing Requests For Approval';
                                    } else {
                                        echo 'My Ongoing Requests';
                                    }
                                    ?>
                                </h4>
                            </div>
                            <div class="card-body">
                                <div id="loading" class="text-center">
                                    <i class="fa fa-spinner fa-spin fa-2x"></i>
                                    <p>Loading ongoing requests...</p>
                                </div>
                                <div id="error-message" class="alert alert-danger" style="display: none;"></div>
                                <div class="table-responsive" id="rts-requests-table-container" style="display: none;">
                                    <table id="rts-requests-table" class="table table-striped table-bordered"
                                        style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Request ID</th>
                                                <th>Form Type</th>
                                                <th>Created On</th>
                                                <th>Submitted By</th>
                                                <th>Overall Status</th>
                                                <th>Checker Status</th>
                                                <th>Approver Status</th>
                                                <th>Noter Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include '../../includes/footer.php'; ?>
    </div>
</div>

<div class="modal fade" id="viewRTSModal" tabindex="-1" role="dialog" aria-labelledby="viewRTSModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewRTSModalLabel">Request Details</h5>
                <span class="badge badge-primary ml-2" id="formTypeBadge"></span>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="modal-body-content">
                <div class="text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="disapproveReasonModal" tabindex="-1" role="dialog" aria-labelledby="disapproveReasonModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="disapproveReasonModalLabel">Reason for Disapproval</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="disapproveReasonForm">
                    <div class="form-group">
                        <label for="disapproveReason">Please provide a reason for disapproving this request:</label>
                        <textarea class="form-control" id="disapproveReason" rows="5" required></textarea>
                        <input type="hidden" id="disapproveRtsId">
                        <input type="hidden" id="disapproveRole">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" form="disapproveReasonForm" class="btn btn-danger" id="submitDisapproveReasonBtn">Submit</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        const userRole = "<?php echo $user_role; ?>";
        const userId = <?php echo json_encode($user_id); ?>;

        const rtsTable = $('#rts-requests-table').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "fetch_requests_rts.php",
                "type": "POST",
                "data": function (d) {
                    d.user_role = userRole;
                    d.user_id = userId;
                    d.request_type = 'ongoing';
                },
                "dataSrc": function (json) {
                    if (json.status === 'success') {
                        $('#loading').hide();
                        $('#rts-requests-table-container').show();
                        return json.data;
                    } else {
                        $('#loading').hide();
                        $('#error-message').text(json.message).show();
                        return [];
                    }
                },
                "error": function (xhr, status, error) {
                    $('#loading').hide();
                    $('#error-message').text('An error occurred while fetching data. Please try again.').show();
                    console.error("DataTables AJAX Error:", status, error);
                }
            },
            "columns": [
                { "data": "rts_no" },
                {
                    "data": "form_type",
                    "render": function (data) {
                        let badgeClass = 'badge-secondary';
                        if (data === 'RTS Form') badgeClass = 'badge-primary';
                        else if (data === 'NG Form') badgeClass = 'badge-warning';
                        else if (data === 'Coil and Solder Form') badgeClass = 'badge-info';
                        return `<span class="badge ${badgeClass}">${data}</span>`;
                    }
                },
                { "data": "created_at" },
                { "data": "submitted_by" },
                {
                    "data": "status",
                    "render": function (data) {
                        let badgeClass = '';
                        switch (data.toLowerCase()) {
                            case 'pending': badgeClass = 'badge-warning'; break;
                            case 'in-progress': badgeClass = 'badge-info'; break;
                            case 'disapproved': badgeClass = 'badge-danger'; break;
                            default: badgeClass = 'badge-secondary';
                        }
                        return `<span class="badge ${badgeClass}">${data}</span>`;
                    }
                },
                {
                    "data": "checked_status",
                    "defaultContent": "N/A",
                    "render": function (data) {
                        let badgeClass = '';
                        if (data === 'Approved') badgeClass = 'badge-success';
                        else if (data === 'Pending') badgeClass = 'badge-warning';
                        else if (data === 'Disapproved') badgeClass = 'badge-danger';
                        else badgeClass = 'badge-secondary';
                        return `<span class="badge ${badgeClass}">${data || 'N/A'}</span>`;
                    }
                },
                {
                    "data": "approved_status",
                    "defaultContent": "N/A",
                    "render": function (data) {
                        let badgeClass = '';
                        if (data === 'Approved') badgeClass = 'badge-success';
                        else if (data === 'Pending') badgeClass = 'badge-warning';
                        else if (data === 'Disapproved') badgeClass = 'badge-danger';
                        else badgeClass = 'badge-secondary';
                        return `<span class="badge ${badgeClass}">${data || 'N/A'}</span>`;
                    }
                },
                {
                    "data": "noted_status",
                    "defaultContent": "N/A",
                    "render": function (data) {
                        let badgeClass = '';
                        if (data === 'Approved') badgeClass = 'badge-success';
                        else if (data === 'Pending') badgeClass = 'badge-warning';
                        else if (data === 'Disapproved') badgeClass = 'badge-danger';
                        else badgeClass = 'badge-secondary';
                        return `<span class="badge ${badgeClass}">${data || 'N/A'}</span>`;
                    }
                },
                {
                    "data": null,
                    "orderable": false,
                    "searchable": false,
                    "render": function (data, type, row) {
                        return `<button type="button" class="btn btn-info btn-sm" onclick="viewRTS(${row.id}, '${row.rts_no}', '${row.status}', '${row.form_type}')"><i class="fa fa-eye"></i> View</button>`;
                    }
                },
            ],
            "dom": "<'row'<'col-md-12'B>><'row'<'col-md-6'l><'col-md-6'f>>rtip",
            "buttons": [
                'copy', 'csv', 'excel', 'pdf', 'print', 'colvis'
            ],
            "initComplete": function (settings, json) {
                $('#loading').hide();
                $('#rts-requests-table-container').show();
            },
            "drawCallback": function (settings) {
                $('[data-toggle="tooltip"]').tooltip();
            }
        });

        let currentRTSNo = '';
        let currentFormType = '';

        window.viewRTS = function (rtsId, rtsNo, overallStatus, formType = 'RTS Form') {
            currentRTSNo = rtsNo;
            currentFormType = formType;
            
            // Update modal title and badge
            $('#viewRTSModalLabel').text(`${formType} Details`);
            $('#formTypeBadge').text(formType);
            
            const modalBody = document.getElementById('modal-body-content');
            modalBody.innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>`;

            // Determine which view file to load based on form type
            let viewUrl = '';
            if (formType === 'RTS Form') {
                viewUrl = `view_rts.php?id=${rtsId}&status=${overallStatus}`;
            } else if (formType === 'NG Form') {
                viewUrl = `view_ng.php?id=${rtsId}&status=${overallStatus}`;
            } else if (formType === 'Coil and Solder Form') {
                viewUrl = `view_coil_solder.php?id=${rtsId}&status=${overallStatus}`;
            } else {
                modalBody.innerHTML = `<div class="alert alert-danger">Unknown form type: ${formType}</div>`;
                $('#viewRTSModal').modal('show');
                return;
            }

            fetch(viewUrl)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Network response was not ok, status: ${response.status}`);
                    }
                    return response.text();
                })
                .then(html => {
                    modalBody.innerHTML = html;
                    $('#viewRTSModal').modal('show');
                })
                .catch(error => {
                    console.error('There has been a problem with your fetch operation:', error);
                    modalBody.innerHTML = `<div class="alert alert-danger">Failed to load content. ${error.message}</div>`;
                });
        }
        
        // Updated click handler for the disapprove button within the view modal
        $('#viewRTSModal').on('click', '.disapprove-btn', function(e) {
            e.preventDefault();
            const rtsId = $(this).data('rts-id');
            const role = $(this).data('role');

            $('#disapproveRtsId').val(rtsId);
            $('#disapproveRole').val(role);
            $('#disapproveReason').val('');
            $('#viewRTSModal').modal('hide'); // Hide the view modal first
            $('#disapproveReasonModal').modal('show'); // Show the disapproval reason modal
        });

        // Handle form submission from the disapproval modal
        $('#disapproveReasonForm').on('submit', function(e) {
            e.preventDefault();
            const rtsId = $('#disapproveRtsId').val();
            const role = $('#disapproveRole').val();
            const reason = $('#disapproveReason').val();

            if (reason.trim() === '') {
                Swal.fire('Reason Required', 'Please provide a reason for disapproval.', 'warning');
                return;
            }

            processRTSRequest(rtsId, 'disapprove', role, reason, currentFormType);
            $('#disapproveReasonModal').modal('hide');
        });

        // Handle Approve button click
        $('#viewRTSModal').on('click', '.approve-btn', function(e) {
            e.preventDefault();
            const rtsId = $(this).data('rts-id');
            const role = $(this).data('role');

            Swal.fire({
                title: 'Are you sure?',
                text: `Do you want to approve this request as the ${role}?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#28a745',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, approve it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    processRTSRequest(rtsId, 'approve', role, null, currentFormType);
                    $('#viewRTSModal').modal('hide');
                }
            });
        });
        

        // PDF GENERATION SCRIPT (remains the same)
        $('#viewRTSModal').on('click', '#downloadPdfBtn', async function(e) {
            e.preventDefault();
            const pdfContent = document.getElementById('pdf-content');

            const elementsToHide = document.querySelectorAll(
            '#viewRTSModal .approval-details-section, ' +
            '#viewRTSModal .modal-footer, ' +
            '#viewRTSModal .modal-header .close, ' +
            '#headingMaterial' 
            );

            const rtsNo = currentRTSNo || 'Request';
            const pdfFileName = `${rtsNo}.pdf`;
            
            const originalDisplays = {};
            elementsToHide.forEach(el => {
                originalDisplays[el] = el.style.display;
                el.style.display = 'none';
            });

            await new Promise(resolve => setTimeout(resolve, 50));
            
            try {
                const canvas = await html2canvas(pdfContent, {
                    scale: 2,
                    logging: true,
                    useCORS: true
                });

                const imgData = canvas.toDataURL('image/png');
                const { jsPDF } = window.jspdf;
                const pdf = new jsPDF('p', 'mm', 'a4');
                const imgWidth = 210;
                const pageHeight = 295;
                const imgHeight = canvas.height * imgWidth / canvas.width;
                let heightLeft = imgHeight;
                let position = 0;
                
                pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                heightLeft -= pageHeight;
                
                while (heightLeft >= 0) {
                    position = heightLeft - imgHeight;
                    pdf.addPage();
                    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                    heightLeft -= pageHeight;
                }
                
                pdf.save(pdfFileName);
            } catch (error) {
                console.error('Error generating PDF:', error);
                Swal.fire({
                    title: 'Error!',
                    text: 'Failed to generate PDF. Please try again.',
                    icon: 'error'
                });
            } finally {
                elementsToHide.forEach(el => {
                    el.style.display = originalDisplays[el];
                });
            }
        });

        // Updated processRTSRequest function
        function processRTSRequest(rtsId, action, role, reason = null, formType = 'RTS Form') {
            // Show a loading indicator
            Swal.fire({
                title: 'Processing...',
                text: 'The request is being processed. Please wait.',
                icon: 'info',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            $.ajax({
                url: 'process_rts_approval.php',
                type: 'POST',
                data: {
                    rts_id: rtsId,
                    action: action,
                    role: role,
                    reason: reason,
                    form_type: formType
                },
                dataType: 'json',
                success: function (response) {
                    Swal.close(); // Close the loading indicator
                    if (response.success) {
                        Swal.fire({
                            title: 'Success!',
                            text: response.message,
                            icon: 'success',
                            timer: 1500,
                            showConfirmButton: false
                        }).then(() => {
                            if (action === 'disapprove') {
                                window.location.href = '<?php echo BASE_URL; ?>/pages/requests/disapproved_requests.php';
                            } else {
                                rtsTable.ajax.reload();
                            }
                        });
                    } else {
                        Swal.fire({
                            title: 'Error!',
                            text: response.message,
                            icon: 'error'
                        });
                    }
                },
                error: function (xhr, status, error) {
                    Swal.close();
                    Swal.fire({
                        title: 'Error!',
                        text: 'An error occurred while processing the request.',
                        icon: 'error'
                    });
                    console.error("AJAX Error:", status, error);
                }
            });
        }
        
        $('#viewRTSModal').on('hidden.bs.modal', function () {
            currentRTSNo = '';
            currentFormType = '';
            document.getElementById('modal-body-content').innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>`;
        });
    });
</script>