<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/includes/functions.php';
require_once APP_ROOT . '/assets/db/connection.php';

// Call the main initialization function.
$pageData = initializeScrapRTSPageData($_SESSION['user_id'] ?? null);

// Handle redirection based on the function's return value.
if (!$pageData['success']) {
    if (isset($pageData['redirect'])) {
        header('Location: ' . $pageData['redirect']);
    }
    $showErrorAlert = true;
    $errorMessage = $pageData['message'];
} else {
    // If successful, extract the data for use in the HTML.
    $user_name = $pageData['userData']['requestor_name'];
    $user_department = $pageData['userData']['department'];
    $user_role = $pageData['userData']['role'];
    $signature_base64 = $pageData['userData']['signature_base64'];
    $departments = $pageData['departments'];
    $sap_locations = $pageData['sap_locations'];
    $control_no = $pageData['control_no'];

    // Check for form submission alerts.
    $showSuccessAlert = isset($_GET['success']) && $_GET['success'] === '1' && !empty($_GET['control_no']);
    $showErrorAlert = isset($_GET['error']);
    $controlNo = $showSuccessAlert ? htmlspecialchars($_GET['control_no']) : '';
    $errorMessage = $showErrorAlert ? htmlspecialchars($_GET['message'] ?? 'An error occurred during submission.') : '';
}
?>

<style>
.form-group label,
.custom-control-label {
    color: #000000 !important;
}

/* Rest of your CSS goes here */
.font-weight-bold {
    color: #000000 !important;
}
.form-group label {
    font-weight: bold;
}
.form-control {
    color: #000000;
    border: 1px solid #ced4da;
    border-radius: 4px;
}
.form-control::placeholder {
    color: #000000;
    opacity: 0.7;
}
.checkbox-column {
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.custom-control-input {
    margin-right: 8px;
}
.custom-control-label {
    font-size: 0.95rem;
}
.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
.modal-content {
    border-radius: 8px;
}
.approval-table-container {
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-top: 15px;
}
.approval-table-container table {
    width: 100%;
    border-collapse: collapse;
}
.approval-table-container th {
    background-color: #f8f9fa;
    color: #000000;
    font-weight: 700;
    padding: 10px;
    text-align: center;
}
.approval-table-container td {
    background-color: #ffffff;
    color: #000000;
    padding: 15px;
    vertical-align: middle;
    border: 1px solid #dee2e6;
    text-align: center;
}
.signature-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
.signature-container img {
    max-width: 100%;
    height: auto;
    border-radius: 5px;
    margin-bottom: 5px;
}
.signature-container span {
    font-weight: 400;
    color: #000000;
}
.card-header {
    background-color: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
}
.card-title {
    font-weight: bold;
    color: #000000;
}
.btn-primary {
    background-color: #007bff;
    border: none;
}
.btn-primary:hover {
    background-color: #0056b3;
}
</style>


<?php include INCLUDES_PATH . '/header.php'; ?>
<div class="wrapper">
    <?php include INCLUDES_PATH . '/sidebar.php'; ?>
    <div class="main-panel">
        <?php include INCLUDES_PATH . '/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="row rts-header align-items-center">
                                    <div class="col-lg-4 col-md-12 text-lg-left text-center">
                                        <img src="<?php echo BASE_URL; ?>/assets/img/logo_black.png" alt="Logo"
                                            class="img-fluid" style="max-width: 150px;">
                                    </div>
                                    <div class="col-lg-4 col-md-12 text-center">
                                        <h4 class="card-title">Return / Transfer Slip</h4>
                                    </div>
                                    <div class="col-lg-4 col-md-12 text-lg-right text-center">
                                        <div class="form-group">
                                            <label for="control_no">Control No</label>
                                            <input type="text" id="control_no" name="control_no"
                                                value="<?= htmlspecialchars($control_no) ?>" class="form-control" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form id="rtsForm" method="POST" action="process_rts_form.php" id="rtsForm">
                                    <input type="hidden" name="requestor_id"
                                        value="<?php echo $_SESSION['user_id']; ?>">
                                    <input type="hidden" name="requestor_name"
                                        value="<?php echo htmlspecialchars($_SESSION['username']); ?>">
                                    <input type="hidden" name="requestor_department"
                                        value="<?php echo htmlspecialchars($user_department); ?>">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-12 checkbox-column">
                                            <div class="form-group">
                                                <label>Material Type</label>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="rawMaterial" name="material_type[]"
                                                        value="Raw Material">
                                                    <label class="custom-control-label" for="rawMaterial">Raw
                                                        Material</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="packagingMaterial" name="material_type[]"
                                                        value="Packaging Material">
                                                    <label class="custom-control-label"
                                                        for="packagingMaterial">Packaging Material</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 checkbox-column">
                                            <div class="form-group">
                                                <label>Material Status</label>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="good" name="material_status[]" value="Good">
                                                    <label class="custom-control-label" for="good">Good</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="materialDefect" name="material_status[]"
                                                        value="Material Defect">
                                                    <label class="custom-control-label"
                                                        for="materialDefect">Material Defect</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="humanError" name="material_status[]"
                                                        value="Human Error">
                                                    <label class="custom-control-label" for="humanError">Human
                                                        Error</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="endOfLife" name="material_status[]" value="EOL">
                                                    <label class="custom-control-label" for="endOfLife">EOL</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="othersNoGood" name="material_status[]"
                                                        value="NG/Others">
                                                    <label class="custom-control-label"
                                                        for="othersNoGood">NG/Others</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 checkbox-column">
                                            <div class="form-group">
                                                <label>Judgement</label>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox"
                                                        id="scrapdisposal" name="judgement[]" value="Scrap/Disposal"
                                                        disabled>
                                                    <label class="custom-control-label"
                                                        for="scrapdisposal">Scrap/Disposal</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox" id="rtv"
                                                        name="judgement[]" value="RTV" disabled>
                                                    <label class="custom-control-label" for="rtv">RTV</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox" id="hold"
                                                        name="judgement[]" value="Hold" disabled>
                                                    <label class="custom-control-label" for="hold">Hold</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox"
                                                        id="transfertogood" name="judgement[]"
                                                        value="Transfer to Good" disabled>
                                                    <label class="custom-control-label"
                                                        for="transfertogood">Transfer to Good</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>SAP Location Code</label>
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>From</th>
                                                            <th>To</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <select class="form-control" name="sap_location[from]">
                                                                    <option value="" disabled selected>Select From
                                                                        Location</option>
                                                                    <?php foreach ($sap_locations as $location): ?>
                                                                        <option
                                                                            value="<?php echo htmlspecialchars($location['LocationCode']); ?>">
                                                                            <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                        </option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </td>
                                                            <td>
                                                                <select class="form-control" name="sap_location[to]">
                                                                    <option value="" disabled selected>Select To
                                                                        Location</option>
                                                                    <?php foreach ($sap_locations as $location): ?>
                                                                        <option
                                                                            value="<?php echo htmlspecialchars($location['LocationCode']); ?>">
                                                                            <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                        </option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                <label for="details">Details (Others)</label>
                                                <textarea class="form-control" id="details" name="details" rows="3"
                                                    placeholder="Enter additional details" disabled></textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                <label for="remarks">Remarks</label>
                                                <textarea name="remark" id="remark" class="form-control"
                                                    placeholder="Enter remarks"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-lg-12 col-md-12">
                                            <div class="form-group">
                                                <label>Approval Details</label>
                                                <div class="approval-table-container">
                                                    <table class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th style="text-align: center;">Prepared By</th>
                                                                <th style="text-align: center;">Checked By</th>
                                                                <th style="text-align: center;">Approved By</th>
                                                                <th style="text-align: center;">Noted By</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <?php if (!empty($signature_base64)): ?>
                                                                            <img src="<?php echo $signature_base64; ?>" alt="E-Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                        <?php endif; ?>
                                                                        <span><?php echo $user_name; ?></span>
                                                                    </div>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                    </div>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                    </div>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <label for="return_date">Return Date</label>
                                                <input type="date" class="form-control" id="return_date"
                                                    name="return_date">
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <label for="department">Department</label>
                                                <select class="form-control" id="department" name="department">
                                                    <option value="<?php echo htmlspecialchars($user_department); ?>"
                                                        selected>
                                                        <?php echo htmlspecialchars($user_department); ?> (Current)
                                                    </option>
                                                    <?php
                                                    foreach ($departments as $dept) {
                                                        if ($dept !== $user_department) {
                                                            echo "<option value='" . htmlspecialchars($dept) . "'>" . htmlspecialchars($dept) . "</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <label for="model">Model</label>
                                                <input type="text" class="form-control" id="model" name="model"
                                                    placeholder="Enter Model">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-12 d-flex justify-content-between align-items-center">
                                            <label class="font-weight-bold">Material Details</label>
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                                data-target="#materialDetailsModal">Add/View Details</button>
                                        </div>
                                    </div>
                                    <div class="modal fade" id="materialDetailsModal" tabindex="-1" role="dialog"
                                        aria-labelledby="materialDetailsModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-xl" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="materialDetailsModalLabel">Material
                                                        Details</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="approval-table-container">
                                                        <table id="material_details_table"
                                                            class="table table-bordered table-striped">
                                                            <thead>
                                                                <tr>
                                                                    <th>No.</th>
                                                                    <th>Ref. No</th>
                                                                    <th>SAP Mat Doc Ref</th>
                                                                    <th>Invoice No</th>
                                                                    <th>Supplier</th>
                                                                    <th>Part Number</th>
                                                                    <th>Part Name</th>
                                                                    <th>Description</th>
                                                                    <th>Qty Returned</th>
                                                                    <th>Qty Received</th>
                                                                    <th>Amount</th>
                                                                    <th>Due Date</th>
                                                                    <th>Actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="modal-footer d-flex justify-content-between align-items-center">
                                                    <div class="d-flex align-items-center" style="column-gap:10px;">
                                                        <div class="input-group" style="width: 220px; min-width:160px;">
                                                            <input type="number" class="form-control form-control-sm"
                                                                id="numRowsInput" placeholder="Enter Number of Rows"
                                                                min="1" max="50">
                                                        </div>
                                                        <button type="button" class="btn btn-secondary btn-sm"
                                                            id="addRowsBtn" style="margin-left:8px;">Add Rows</button>
                                                    </div>
                                                    <button type="button" class="btn btn-primary"
                                                        data-dismiss="modal">Done</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-12 text-center">
                                            <button type="submit" class="btn btn-primary">Submit RTS Form</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include INCLUDES_PATH . '/footer.php'; ?>
    </div>
</div>


<script>
    // Global variable to keep track of the row count
    let totalRows = 0;

    // Function to generate editable table rows based on a number
    function generateTableRows(numberOfRows) {
        let rowsHtml = '';
        const startingIndex = $('#material_details_table tbody tr').length + 1;
        for (let i = 0; i < numberOfRows; i++) {
            const rowNumber = startingIndex + i;
            rowsHtml += `
                <tr data-row-number="${rowNumber}">
                    <td>${rowNumber}</td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[ref_no][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[sap_doc][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[invoice_no][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[supplier][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_number][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_name][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[description][]" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_returned][]" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_received][]" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm amount-input" name="material_details[amount][]" placeholder="..."></td>
                    <td><input type="date" class="form-control form-control-sm" name="material_details[due_date][]"></td>
                    <td><button type="button" class="btn btn-danger btn-sm remove-row-btn">Remove</button></td>
                </tr>`;
        }
        totalRows += numberOfRows;
        return rowsHtml;
    }

    // Function to update the display table on the main form
    function updateDisplayTable() {
        const $editableRows = $('#material_details_table tbody tr');
        const $displayTableBody = $('#material_display_table tbody');
        $displayTableBody.empty(); // Clear existing content

        $editableRows.each(function (index) {
            const $row = $(this);
            const refNo = $row.find('input[name="material_details[ref_no][]"]').val();
            const sapDoc = $row.find('input[name="material_details[sap_doc][]"]').val();
            const invoiceNo = $row.find('input[name="material_details[invoice_no][]"]').val();
            const supplier = $row.find('input[name="material_details[supplier][]"]').val();
            const partNumber = $row.find('input[name="material_details[part_number][]"]').val();
            const qtyReturned = $row.find('input[name="material_details[qty_returned][]"]').val();

            if (refNo || sapDoc || invoiceNo || supplier || partNumber || qtyReturned) {
                const displayRow = `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${refNo}</td>
                        <td>${sapDoc}</td>
                        <td>${invoiceNo}</td>
                        <td>${supplier}</td>
                        <td>${partNumber}</td>
                        <td>${qtyReturned}</td>
                    </tr>`;
                $displayTableBody.append(displayRow);
            }
        });

        if ($displayTableBody.children().length > 0) {
            $('#material_display_section').show();
        } else {
            $('#material_display_section').hide();
        }
    }

    // Function to calculate and display the total amount
    function calculateTotalAmount() {
        let total = 0;
        $('#material_details_table .amount-input').each(function () {
            const amount = parseFloat($(this).val()) || 0;
            total += amount;
        });
        $('#totalAmountDisplay').text(total.toFixed(2));
    }

    // Function to check and display a warning if material count is high
    function checkMaterialCount() {
        const rowCount = $('#material_details_table tbody tr').length;
        if (rowCount > 10) {
            $('#materialCountWarning').show();
        } else {
            $('#materialCountWarning').hide();
        }
    }

    $(document).ready(function () {
        // Initial load of 5 rows when the modal is first shown
        $('#materialDetailsModal').one('shown.bs.modal', function () {
            $('#material_details_table tbody').append(generateTableRows(5));
        });

        // Handle the "Add Rows" button click
        $('#addRowsBtn').on('click', function () {
            const numRows = parseInt($('#numRowsInput').val());
            if (numRows > 0 && numRows <= 50) {
                $('#material_details_table tbody').append(generateTableRows(numRows));
                calculateTotalAmount();
                checkMaterialCount();
            } else {
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Input',
                    text: 'Please enter a number between 1 and 50.'
                });
            }
        });

        // Remove a row and re-number
        $(document).on('click', '.remove-row-btn', function () {
            $(this).closest('tr').remove();
            $('#material_details_table tbody tr').each(function (index) {
                $(this).find('td:first').text(index + 1);
            });
            calculateTotalAmount();
            checkMaterialCount();
        });

        // Update the display table when the modal is hidden
        $('#materialDetailsModal').on('hidden.bs.modal', function () {
            updateDisplayTable();
        });

        // New event listener for the amount field to trigger total calculation
        $(document).on('input', '.amount-input', function () {
            calculateTotalAmount();
        });

        // Handle logic for material status and judgement checkboxes
        $('.material-status-checkbox, .judgement-checkbox').change(function () {
            const isChecked = $(this).is(':checked');
            const groupClass = $(this).hasClass('material-status-checkbox') ? '.material-status-checkbox' : '.judgement-checkbox';
            if (isChecked) {
                $(groupClass).not(this).prop('checked', false);
            }

            // Check if the changed checkbox belongs to the material status group
            if ($(this).hasClass('material-status-checkbox')) {
                const checkedStatus = $(this).val();
                const $allStatusCheckboxes = $('.material-status-checkbox');
                const $allJudgementCheckboxes = $('.judgement-checkbox');
                const $detailsField = $('#details');

                // Reset all judgement checkboxes and disable them initially
                $allJudgementCheckboxes.prop('checked', false).prop('disabled', true);

                // Always enable the details field if any material status is checked
                $detailsField.prop('disabled', !isChecked);
                if (!isChecked) {
                    $detailsField.val(''); // Clear the field if no status is checked
                }

                if (isChecked) {
                    // Disable all other status checkboxes
                    $allStatusCheckboxes.not(this).prop('disabled', true);

                    // Specific logic for the "NG/Others" checkbox
                    if (checkedStatus === 'NG/Others') {
                        $('#scrapdisposal').prop('disabled', false);
                        $('#hold').prop('disabled', false);
                    } else if (checkedStatus === 'Good') {
                        // This part is for other cases, like 'Good'
                        $('#transfertogood').prop('disabled', false);
                    } else {
                        // This handles the other defect cases
                        $('#scrapdisposal').prop('disabled', false);
                        $('#hold').prop('disabled', false);
                    }
                } else {
                    // If a material status checkbox is unchecked, enable all status checkboxes again
                    $allStatusCheckboxes.prop('disabled', false);
                }
            }
        });

        // The key change to handle the form submission with AJAX
        $('#rtsForm').on('submit', function (e) {
            e.preventDefault(); // Prevent the default form submission

            let isValid = true;
            let errorMessages = [];

            // Perform your existing validation checks here
            if ($('input[name="material_type[]"]:checked').length === 0) {
                isValid = false;
                errorMessages.push('Please select at least one Material Type.');
            }
            if ($('input[name="material_status[]"]:checked').length === 0) {
                isValid = false;
                errorMessages.push('Please select at least one Material Status.');
            }
            const selectedStatus = $('input[name="material_status[]"]:checked').val();
            const hasJudgement = $('input[name="judgement[]"]:checked').length > 0;

            if (selectedStatus === 'NG/Others' && !hasJudgement) {
                isValid = false;
                errorMessages.push('Please select a judgement (Scrap/Disposal or Hold) for NG/Others.');
            } else if (selectedStatus !== 'Good' && selectedStatus !== 'NG/Others' && selectedStatus !== undefined && !hasJudgement) {
                isValid = false;
                errorMessages.push('Please select at least one Judgement.');
            }

            if ($('#return_date').val().trim() === '') {
                isValid = false;
                errorMessages.push('Please select a Return Date.');
            }
            if ($('#department').val().trim() === '') {
                isValid = false;
                errorMessages.push('Please select a Department.');
            }
            
            // ⭐ NEW VALIDATION FOR SAP LOCATION CODE ⭐
            const sapFromLocation = $('select[name="sap_location[from]"]').val();
            const sapToLocation = $('select[name="sap_location[to]"]').val();
            if (!sapFromLocation || !sapToLocation) {
                isValid = false;
                errorMessages.push('Please select both a "From" and "To" SAP Location Code.');
            }
            
            let hasMaterialDetails = false;
            $('#material_details_table tbody tr').each(function () {
                const $rowInputs = $(this).find('input');
                let rowIsFilled = false;
                $rowInputs.each(function () {
                    if ($(this).val().trim() !== '' && !$(this).prop('disabled')) {
                        rowIsFilled = true;
                        return false;
                    }
                });
                if (rowIsFilled) {
                    hasMaterialDetails = true;
                    return false;
                }
            });
            if (!hasMaterialDetails) {
                isValid = false;
                errorMessages.push('Please enter details for at least one material.');
            }

            // If validation fails, show an alert and stop the process.
            if (!isValid) {
                Swal.fire({
                    icon: 'error',
                    title: 'Validation Error',
                    html: errorMessages.join('<br>')
                });
                return;
            }

            // Show the confirmation SweetAlert
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to submit this form?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, Submit!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // **START OF NEW CODE**
                    // Show a SweetAlert loading state before the AJAX call
                    Swal.fire({
                        title: 'Submitting Form...',
                        text: 'Please wait, sending approval request...',
                        icon: 'info',
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                    // **END OF NEW CODE**
                    
                    // Perform the AJAX submission inside the confirmation block
                    const form = $(this);
                    $.ajax({
                        url: form.attr('action'),
                        type: form.attr('method'),
                        data: form.serialize(),
                        dataType: 'json',
                        success: function (response) {
                            // **START OF UPDATED CODE**
                            Swal.close(); // Close the loading alert
                            // **END OF UPDATED CODE**
                            
                            if (response.status === 'success') {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'RTS Form Submitted Successfully!',
                                    html: 'Your RTS Control Number is: <strong>' + response.control_no + '</strong>',
                                    confirmButtonText: 'OK'
                                }).then(() => {
                                    window.location.href = `<?php echo BASE_URL; ?>/pages/requests/pending_requests.php`;
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Submission Failed!',
                                    text: response.message,
                                    confirmButtonText: 'Try Again'
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            // **START OF UPDATED CODE**
                            Swal.close(); // Close the loading alert on error
                            // **END OF UPDATED CODE**

                            Swal.fire({
                                icon: 'error',
                                title: 'An error occurred!',
                                text: 'Please try again. ' + xhr.responseText,
                                confirmButtonText: 'OK'
                            });
                        }
                    });
                }
            });
        });
    });
</script>