<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../../login.php');
    exit();
}
?>

<?php include '../../includes/header.php'; ?>

<div class="wrapper">
    <?php include '../../includes/sidebar.php'; ?>
    <div class="main-panel">
        <?php include '../../includes/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="card-title m-0">SAP Location Code Masterlist</h4>
                                <button class="btn btn-primary btn-round" id="addSapLocCodeButton">
                                    <span class="d-none d-lg-inline">Add New Location</span>
                                    <span class="d-lg-none"><i class="fa fa-plus"></i></span>
                                </button>
                            </div>
                            <div class="card-body">
                                <div id="loading" class="text-center">
                                    <i class="fa fa-spinner fa-spin fa-2x"></i>
                                    <p>Loading SAP location codes...</p>
                                </div>
                                <div id="error-message" class="alert alert-danger" style="display: none;"></div>
                                <div class="table-responsive" id="sap-loc-code-table-container" style="display: none;">
                                    <table id="sap-loc-code-table" class="table table-striped table-bordered" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Location Code</th>
                                                <th>Location Description</th>
                                                <th>Department</th> <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include '../../includes/footer.php'; ?>
    </div>
</div>

<!-- Add Sap Modal -->
<div class="modal fade" id="addSapLocCodeModal" tabindex="-1" role="dialog" aria-labelledby="addSapLocCodeModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addSapLocCodeModalLabel">Add New SAP Location Code</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="addSapLocCodeForm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="add_location_code">Location Code</label>
                        <input type="text" class="form-control" id="add_location_code" name="location_code" required>
                    </div>
                    <div class="form-group">
                        <label for="add_location_name">Location Name</label>
                        <input type="text" class="form-control" id="add_location_name" name="location_name" required>
                    </div>
                    <div class="form-group">
                        <label for="add_department">Department</label>
                        <input type="text" class="form-control" id="add_department" name="department" required>
                    </div>
                    <div id="add-loc-code-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" id="addSapLocCodeSubmitBtn">Save Location</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Sap Modal -->
<div class="modal fade" id="editSapLocCodeModal" tabindex="-1" role="dialog" aria-labelledby="editSapLocCodeModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editSapLocCodeModalLabel">Edit SAP Location Code</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editSapLocCodeForm">
                <div class="modal-body">
                    <input type="hidden" id="edit_location_code_original" name="original_location_code">
                    <div class="form-group">
                        <label for="edit_location_code">Location Code</label>
                        <input type="text" class="form-control" id="edit_location_code" name="location_code" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_location_name">Location Name</label>
                        <input type="text" class="form-control" id="edit_location_name" name="location_name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_department">Department</label>
                        <input type="text" class="form-control" id="edit_department" name="department" required>
                    </div>
                    <div id="edit-loc-code-message" class="alert mt-3" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" id="editSapLocCodeSubmitBtn">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Initialize DataTables
    $('#sap-loc-code-table').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "fetch_sap_loc_codes.php",
            "type": "POST",
            "dataSrc": function(json) {
                if (json.status === 'success') {
                    // Return the data array for DataTables to process
                    return json.data;
                } else {
                    // If there's an error, display it and return an empty array
                    $('#error-message').text(json.message).show();
                    return [];
                }
            }
        },
        "columns": [
            {
                "data": null,
                "orderable": false,
                "searchable": false,
                "render": function(data, type, row, meta) {
                    return meta.row + meta.settings._iDisplayStart + 1;
                }
            },
            { "data": "location_code" },
            { "data": "location_name" },
            { "data": "department" }, // New column for Department
            {
                "data": "location_code", // Use the location code as the ID for actions
                "orderable": false,
                "searchable": false,
                "render": function(data, type, row) {
                    return `
                        <button class="btn btn-warning btn-sm edit-btn" data-id="${data}"><i class="fa fa-edit"></i></button>
                        <button class="btn btn-danger btn-sm delete-btn" data-id="${data}"><i class="fa fa-trash"></i></button>
                    `;
                }
            }
        ],
        "initComplete": function(settings, json) {
            // Hide the loading spinner and show the table when it's done initializing
            $('#loading').hide();
            $('#sap-loc-code-table-container').show();
        }
    });

    // Handle Add Button Click to open the modal
    $('#addSapLocCodeButton').click(function() {
        $('#addSapLocCodeForm')[0].reset(); // Reset the form
        $('#add-loc-code-message').hide(); // Hide any previous messages
        $('#addSapLocCodeModal').modal('show'); // Show the modal
    });

    // Handle Form Submission for adding a new record
    $('#addSapLocCodeForm').submit(function(e) {
        e.preventDefault(); // Prevent the default form submission

        var formData = $(this).serialize(); // Serialize form data for AJAX
        const submitBtn = $('#addSapLocCodeSubmitBtn');
        submitBtn.prop('disabled', true).text('Saving...');

        // AJAX call to the PHP script that will save the data
        $.ajax({
            url: 'add_sap_loc_code.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        $('#addSapLocCodeModal').modal('hide');
                        $('#sap-loc-code-table').DataTable().ajax.reload(); // Reload the DataTable
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: response.message
                    });
                }
            },
            error: function(xhr, status, error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred. Please try again later.'
                });
                console.error("AJAX Error:", status, error, xhr.responseText);
            },
            complete: function() {
                submitBtn.prop('disabled', false).text('Save Location');
            }
        });
    });

    // Click handler for the edit button
    $('#sap-loc-code-table tbody').on('click', '.edit-btn', function() {
        // Use DataTables API to get the data for the clicked row
        var data = $('#sap-loc-code-table').DataTable().row($(this).parents('tr')).data();

        // Populate the modal fields with the row data
        $('#edit_location_code').val(data.location_code);
        $('#edit_location_name').val(data.location_name);
        $('#edit_department').val(data.department);
        // Store the original location code in a hidden field to use in the update query
        $('#edit_location_code_original').val(data.location_code);

        // Show the edit modal
        $('#editSapLocCodeModal').modal('show');
    });

    // Handle Form Submission for updating a record
    $('#editSapLocCodeForm').submit(function(e) {
        e.preventDefault(); // Prevent the default form submission

        var formData = $(this).serialize(); // Serialize form data for AJAX
        const submitBtn = $('#editSapLocCodeSubmitBtn');
        submitBtn.prop('disabled', true).text('Saving...');

        // AJAX call to the PHP script that will update the data
        $.ajax({
            url: 'edit_sap_loc_code.php', // The new PHP script to handle the update
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        $('#editSapLocCodeModal').modal('hide');
                        $('#sap-loc-code-table').DataTable().ajax.reload(); // Reload the DataTable
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: response.message
                    });
                }
            },
            error: function(xhr, status, error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred. Please try again later.'
                });
                console.error("AJAX Error:", status, error, xhr.responseText);
            },
            complete: function() {
                submitBtn.prop('disabled', false).text('Save Changes');
            }
        });
    });
});
// Click handler for the delete button
$('#sap-loc-code-table tbody').on('click', '.delete-btn', function() {
    var locationCode = $(this).data('id');

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33', 
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // Send an AJAX request to delete the record
            $.ajax({
                url: 'delete_sap_loc_code.php', // The new PHP script to handle the deletion
                type: 'POST',
                data: { location_code: locationCode },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire(
                            'Deleted!',
                            response.message,
                            'success'
                        ).then(() => {
                            $('#sap-loc-code-table').DataTable().ajax.reload(); // Reload the DataTable
                        });
                    } else {
                        Swal.fire(
                            'Error!',
                            response.message,
                            'error'
                        );
                    }
                },
                error: function(xhr, status, error) {
                    Swal.fire(
                        'Error!',
                        'An error occurred. Please try again.',
                        'error'
                    );
                    console.error("AJAX Error:", status, error, xhr.responseText);
                }
            });
        }
    });
});
</script>