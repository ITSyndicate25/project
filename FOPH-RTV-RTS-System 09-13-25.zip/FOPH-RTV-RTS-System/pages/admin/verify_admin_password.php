<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/includes/functions.php';

header('Content-Type: application/json');

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

$admin_password = $_POST['admin_password'] ?? '';
$current_user_id = $_SESSION['user_id'];

// Call the function
$result = verifyAdminPassword($current_user_id, $admin_password);

// Return the result as a JSON response
echo json_encode($result);