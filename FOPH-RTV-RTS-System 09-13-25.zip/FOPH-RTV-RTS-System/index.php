<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/assets/db/connection.php';

// Check if a user is NOT logged in. If not, redirect them to the login page.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// If the user IS logged in, let the respective dashboard page handle the redirection.
$role = $_SESSION['user_role'] ?? '';
if ($role === 'admin') {
    header('Location: pages/admin/admin_dashboard.php');
    exit();
} else {
    header('Location: pages/user/user_dashboard.php');
    exit();
}