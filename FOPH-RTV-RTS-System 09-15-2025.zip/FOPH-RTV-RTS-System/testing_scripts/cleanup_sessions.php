<?php
// cleanup_sessions.php - Run this to manually clean up sessions
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/assets/db/connection.php';

$conn = new Connection();

echo "<h2>Session Cleanup Tool</h2>";

// Show current sessions before cleanup
echo "<h3>Before Cleanup:</h3>";
$sql = "SELECT a.*, u.username FROM active_sessions a LEFT JOIN users u ON a.user_id = u.user_id";
$stmt = sqlsrv_query($conn->link, $sql);
$before_count = 0;
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $before_count++;
}
echo "<p>Total sessions: $before_count</p>";

// Clean up based on different criteria
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'all':
            // Delete all sessions
            $delete_sql = "DELETE FROM active_sessions";
            $result = sqlsrv_query($conn->link, $delete_sql);
            echo "<p style='color: green;'>Deleted all sessions</p>";
            break;
            
        case 'old':
            // Delete sessions older than 30 minutes
            $delete_sql = "DELETE FROM active_sessions WHERE last_activity < DATEADD(minute, -30, GETDATE())";
            $result = sqlsrv_query($conn->link, $delete_sql);
            echo "<p style='color: green;'>Deleted sessions older than 30 minutes</p>";
            break;
            
        case 'user':
            if (isset($_GET['user_id'])) {
                $user_id = intval($_GET['user_id']);
                $delete_sql = "DELETE FROM active_sessions WHERE user_id = ?";
                $result = sqlsrv_query($conn->link, $delete_sql, array($user_id));
                echo "<p style='color: green;'>Deleted sessions for user ID: $user_id</p>";
            }
            break;
    }
}

// Show current sessions after cleanup
echo "<h3>After Cleanup:</h3>";
$sql = "SELECT a.*, u.username, DATEDIFF(minute, a.last_activity, GETDATE()) as minutes_ago FROM active_sessions a LEFT JOIN users u ON a.user_id = u.user_id ORDER BY a.last_activity DESC";
$stmt = sqlsrv_query($conn->link, $sql);

echo "<table border='1' style='border-collapse: collapse;'>";
echo "<tr><th>Session ID</th><th>User ID</th><th>Username</th><th>Last Activity</th><th>Minutes Ago</th><th>Action</th></tr>";

$after_count = 0;
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $after_count++;
    $last_activity = $row['last_activity'];
    if ($last_activity instanceof DateTime) {
        $last_activity_str = $last_activity->format('Y-m-d H:i:s');
    } else {
        $last_activity_str = $last_activity;
    }
    
    echo "<tr>";
    echo "<td>" . substr($row['session_id'], 0, 20) . "...</td>";
    echo "<td>" . $row['user_id'] . "</td>";
    echo "<td>" . ($row['username'] ?? 'N/A') . "</td>";
    echo "<td>" . $last_activity_str . "</td>";
    echo "<td>" . $row['minutes_ago'] . " min</td>";
    echo "<td><a href='?action=user&user_id=" . $row['user_id'] . "'>Delete</a></td>";
    echo "</tr>";
}
echo "</table>";
echo "<p>Total sessions: $after_count</p>";

// Cleanup actions
echo "<h3>Cleanup Actions:</h3>";
echo "<p><a href='?action=old' onclick='return confirm(\"Delete sessions older than 30 minutes?\")'>Clean old sessions (>30 min)</a></p>";
echo "<p><a href='?action=all' onclick='return confirm(\"Delete ALL sessions?\")' style='color: red;'>Delete ALL sessions</a></p>";

$conn->close();
?>