<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/assets/db/connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<p style='color: red;'>You need to be logged in to run this test. <a href='login.php'>Login here</a></p>";
    exit;
}

$conn = new Connection();

echo "<h2>Active Sessions Debug</h2>";

// Check if table exists
$table_check = "SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'active_sessions'";
$result = sqlsrv_query($conn->link, $table_check);
if ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    echo "<p style='color: green;'>✓ Table 'active_sessions' exists</p>";
} else {
    echo "<p style='color: red;'>✗ Table 'active_sessions' does NOT exist</p>";
}

// Check if last_login column exists
$column_check = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'users' AND COLUMN_NAME = 'last_login'";
$col_result = sqlsrv_query($conn->link, $column_check);
if ($row = sqlsrv_fetch_array($col_result, SQLSRV_FETCH_ASSOC)) {
    echo "<p style='color: green;'>✓ Column 'last_login' exists in users table</p>";
} else {
    echo "<p style='color: red;'>✗ Column 'last_login' does NOT exist in users table</p>";
    echo "<p>Run this SQL: <code>ALTER TABLE users ADD last_login DATETIME NULL;</code></p>";
}

// Show all active sessions
echo "<h3>Current Active Sessions:</h3>";
$sql = "SELECT a.*, u.username, DATEDIFF(minute, a.last_activity, GETDATE()) as minutes_ago FROM active_sessions a LEFT JOIN users u ON a.user_id = u.user_id ORDER BY a.last_activity DESC";
$stmt = sqlsrv_query($conn->link, $sql);

if ($stmt === false) {
    echo "<p style='color: red;'>Query Error: " . print_r(sqlsrv_errors(), true) . "</p>";
} else {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Session ID</th><th>User ID</th><th>Username</th><th>Last Activity</th><th>Minutes Ago</th><th>Status</th></tr>";
    
    $count = 0;
    $active_count = 0;
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $count++;
        $last_activity = $row['last_activity'];
        if ($last_activity instanceof DateTime) {
            $last_activity_str = $last_activity->format('Y-m-d H:i:s');
        } else {
            $last_activity_str = $last_activity;
        }
        
        $minutes_ago = $row['minutes_ago'];
        $is_active = $minutes_ago <= 30;
        if ($is_active) $active_count++;
        
        $status_color = $is_active ? 'green' : 'red';
        $status_text = $is_active ? 'Active' : 'Inactive';
        
        echo "<tr>";
        echo "<td>" . substr($row['session_id'], 0, 20) . "...</td>";
        echo "<td>" . $row['user_id'] . "</td>";
        echo "<td>" . ($row['username'] ?? 'N/A') . "</td>";
        echo "<td>" . $last_activity_str . "</td>";
        echo "<td>" . $minutes_ago . " min</td>";
        echo "<td style='color: $status_color;'>$status_text</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "<p>Total sessions: $count</p>";
    echo "<p style='color: green;'>Active sessions (last 30 min): $active_count</p>";
}

// Check last_login in users table (only if column exists)
$col_exists = sqlsrv_query($conn->link, "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'users' AND COLUMN_NAME = 'last_login'");
if (sqlsrv_has_rows($col_exists)) {
    echo "<h3>Users with Recent Login (last 24 hours):</h3>";
    $sql2 = "SELECT user_id, username, last_login FROM users WHERE last_login >= DATEADD(hour, -24, GETDATE()) ORDER BY last_login DESC";
    $stmt2 = sqlsrv_query($conn->link, $sql2);

    if ($stmt2 === false) {
        echo "<p style='color: red;'>Query Error: " . print_r(sqlsrv_errors(), true) . "</p>";
    } else {
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>User ID</th><th>Username</th><th>Last Login</th></tr>";
        
        $count2 = 0;
        while ($row = sqlsrv_fetch_array($stmt2, SQLSRV_FETCH_ASSOC)) {
            $count2++;
            $last_login = $row['last_login'];
            if ($last_login instanceof DateTime) {
                $last_login_str = $last_login->format('Y-m-d H:i:s');
            } else {
                $last_login_str = $last_login ?? 'Never';
            }
            
            echo "<tr>";
            echo "<td>" . $row['user_id'] . "</td>";
            echo "<td>" . $row['username'] . "</td>";
            echo "<td>" . $last_login_str . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "<p>Total users logged in last 24 hours: $count2</p>";
    }
}

// Current session info
echo "<h3>Current Session Info:</h3>";
echo "<p>Session ID: " . session_id() . "</p>";
echo "<p>User ID: " . ($_SESSION['user_id'] ?? 'Not set') . "</p>";
echo "<p>Username: " . ($_SESSION['username'] ?? 'Not set') . "</p>";

// Test inserting/updating current session
echo "<h3>Testing Session Update:</h3>";
if (isset($_SESSION['user_id'])) {
    $session_id = session_id();
    $user_id = $_SESSION['user_id'];
    
    // Delete existing
    $delete_sql = "DELETE FROM active_sessions WHERE session_id = ?";
    $del_result = sqlsrv_query($conn->link, $delete_sql, array($session_id));
    echo "<p>Delete result: " . ($del_result ? 'Success' : 'Failed') . "</p>";
    
    // Insert new
    $insert_sql = "INSERT INTO active_sessions (session_id, user_id, last_activity) VALUES (?, ?, GETDATE())";
    $ins_result = sqlsrv_query($conn->link, $insert_sql, array($session_id, $user_id));
    echo "<p>Insert result: " . ($ins_result ? 'Success' : 'Failed: ' . print_r(sqlsrv_errors(), true)) . "</p>";
}

$conn->close();
?>