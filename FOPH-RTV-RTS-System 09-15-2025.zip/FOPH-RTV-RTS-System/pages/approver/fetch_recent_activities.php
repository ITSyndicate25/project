<?php
session_start();
header('Content-Type: application/json');
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not authenticated.']);
    exit();
}

$current_user_id = $_SESSION['user_id'];

try {
    $db = new Connection();
    $conn = $db->link;

    $draw = $_POST['draw'] ?? 1;
    $start = intval($_POST['start'] ?? 0);
    $length = intval($_POST['length'] ?? 10);
    $search_value = $_POST['search']['value'] ?? '';

    // Build query for recent activities with corrected action labels
    $base_query = "
        SELECT 
            rf.id,
            rf.control_no,
            rf.requestor_name,
            rf.material_status,
            CASE 
                WHEN rf.noted_by_id = ? AND rf.noted_status = 'Approved' AND rf.noted_at = (
                    SELECT MAX(action_date) FROM (
                        SELECT checked_at as action_date FROM rts_forms WHERE id = rf.id AND checked_by_id = ?
                        UNION ALL
                        SELECT approved_at as action_date FROM rts_forms WHERE id = rf.id AND approved_by_id = ?
                        UNION ALL
                        SELECT noted_at as action_date FROM rts_forms WHERE id = rf.id AND noted_by_id = ?
                    ) as actions
                ) THEN 'Noted'
                WHEN rf.noted_by_id = ? AND rf.noted_status = 'Disapproved' THEN 'Disapproved (as Noter)'
                WHEN rf.approved_by_id = ? AND rf.approved_status = 'Approved' AND rf.approved_at = (
                    SELECT MAX(action_date) FROM (
                        SELECT checked_at as action_date FROM rts_forms WHERE id = rf.id AND checked_by_id = ?
                        UNION ALL
                        SELECT approved_at as action_date FROM rts_forms WHERE id = rf.id AND approved_by_id = ?
                    ) as actions
                ) THEN 'Approved'
                WHEN rf.approved_by_id = ? AND rf.approved_status = 'Disapproved' THEN 'Disapproved (as Approver)'
                WHEN rf.checked_by_id = ? AND rf.checked_status = 'Approved' AND rf.checked_at = (
                    SELECT MAX(checked_at) FROM rts_forms WHERE id = rf.id AND checked_by_id = ?
                ) THEN 'Checked'
                WHEN rf.checked_by_id = ? AND rf.checked_status = 'Disapproved' THEN 'Disapproved (as Checker)'
            END as action_taken,
            CASE 
                WHEN rf.noted_by_id = ? AND rf.noted_at IS NOT NULL THEN rf.noted_at
                WHEN rf.approved_by_id = ? AND rf.approved_at IS NOT NULL AND (rf.noted_at IS NULL OR rf.approved_at > rf.noted_at) THEN rf.approved_at
                WHEN rf.checked_by_id = ? AND rf.checked_at IS NOT NULL THEN rf.checked_at
            END as action_date
        FROM rts_forms rf
        WHERE (rf.checked_by_id = ? OR rf.approved_by_id = ? OR rf.noted_by_id = ?)
        AND (
            (rf.checked_by_id = ? AND rf.checked_at IS NOT NULL) OR
            (rf.approved_by_id = ? AND rf.approved_at IS NOT NULL) OR
            (rf.noted_by_id = ? AND rf.noted_at IS NOT NULL)
        )
    ";

    $user_params = array_fill(0, 21, $current_user_id);
    
    // Add search
    if (!empty($search_value)) {
        $base_query .= " AND (rf.control_no LIKE ? OR rf.requestor_name LIKE ?)";
        $search_param = '%' . $search_value . '%';
        $user_params[] = $search_param;
        $user_params[] = $search_param;
    }

    // Count total
    $count_query = "SELECT COUNT(*) FROM (" . $base_query . ") as count_table";
    $stmt_count = sqlsrv_query($conn, $count_query, $user_params);
    $total_records = 0;
    if ($stmt_count && sqlsrv_fetch($stmt_count)) {
        $total_records = sqlsrv_get_field($stmt_count, 0);
    }

    // Final query with pagination
    $final_query = $base_query . " ORDER BY action_date DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
    $user_params[] = $start;
    $user_params[] = $length;

    $stmt = sqlsrv_query($conn, $final_query, $user_params);

    if ($stmt === false) {
        throw new Exception("Database query failed: " . print_r(sqlsrv_errors(), true));
    }

    $data = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if (isset($row['action_date']) && $row['action_date'] instanceof DateTime) {
            $row['action_date'] = $row['action_date']->format('Y-m-d H:i:s');
        }
        $data[] = $row;
    }

    echo json_encode([
        'status' => 'success',
        'draw' => intval($draw),
        'recordsTotal' => intval($total_records),
        'recordsFiltered' => intval($total_records),
        'data' => $data
    ]);

    $db->close();

} catch (Exception $e) {
    error_log("Error in fetch_recent_activities: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'An internal server error occurred.']);
}
?>