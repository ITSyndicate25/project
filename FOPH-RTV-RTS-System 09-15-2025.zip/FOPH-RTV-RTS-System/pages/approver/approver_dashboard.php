<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

// Check if user is logged in and has approver role(s)
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

$allowed_roles = ['checker', 'approver', 'noter'];
$user_roles = explode(',', $_SESSION['user_role']); // Handle multiple roles
$has_approver_role = false;

foreach ($user_roles as $role) {
    if (in_array(trim($role), $allowed_roles)) {
        $has_approver_role = true;
        break;
    }
}

if (!$has_approver_role) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

// Get dashboard data for the logged-in approver
$user_id = $_SESSION['user_id'];
$dashboard_data = getApproverDashboardData($user_id, $user_roles);

include INCLUDES_PATH . '/header.php';
?>

<div class="wrapper">
    <?php include INCLUDES_PATH . '/sidebar.php'; ?>
    <div class="main-panel">
        <?php include INCLUDES_PATH . '/navbar.php'; ?>
        <div class="content">
            <!-- Welcome Section -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card card-stats">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Welcome, <?php echo htmlspecialchars(ucfirst($dashboard_data['username'])); ?>!</h5>
                            <p class="card-category mb-0">Today is <?php echo $dashboard_data['today']; ?></p>
                            <p class="card-category mb-0">
                                <i class="nc-icon nc-badge"></i> Your roles: 
                                <?php 
                                $roleLabels = array_map(function($role) {
                                    $trimmedRole = trim($role);
                                    $badgeClass = 'badge-secondary';
                                    if ($trimmedRole === 'checker') $badgeClass = 'badge-info';
                                    elseif ($trimmedRole === 'approver') $badgeClass = 'badge-success';
                                    elseif ($trimmedRole === 'noter') $badgeClass = 'badge-warning';
                                    return '<span class="badge ' . $badgeClass . '">' . ucfirst($trimmedRole) . '</span>';
                                }, $user_roles);
                                echo implode(' ', $roleLabels);
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pending Actions Cards -->
            <div class="row">
                <?php if (in_array('checker', $user_roles)): ?>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-ruler-pencil text-info"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers text-center">
                                        <p class="card-category">Pending for Checking</p>
                                        <p class="card-title text-info" style="font-size: 2rem; font-weight: bold;">
                                            <?php echo $dashboard_data['pending_checking']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(23, 162, 184, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <?php if ($dashboard_data['pending_checking'] > 0): ?>
                                    <i class="fa fa-clock text-info"></i>
                                    <span class="text-info">Awaiting your review</span>
                                <?php else: ?>
                                    <i class="fa fa-check text-success"></i>
                                    <span class="text-success">All checked</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (in_array('approver', $user_roles)): ?>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-badge text-success"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers text-center">
                                        <p class="card-category">Pending for Approval</p>
                                        <p class="card-title text-success" style="font-size: 2rem; font-weight: bold;">
                                            <?php echo $dashboard_data['pending_approval']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(40, 167, 69, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <?php if ($dashboard_data['pending_approval'] > 0): ?>
                                    <i class="fa fa-clock text-success"></i>
                                    <span class="text-success">Awaiting your approval</span>
                                <?php else: ?>
                                    <i class="fa fa-check text-success"></i>
                                    <span class="text-success">All approved</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (in_array('noter', $user_roles)): ?>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-5 col-md-4">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-notes text-warning"></i>
                                    </div>
                                </div>
                                <div class="col-7 col-md-8">
                                    <div class="numbers text-center">
                                        <p class="card-category">Pending for Noting</p>
                                        <p class="card-title text-warning" style="font-size: 2rem; font-weight: bold;">
                                            <?php echo $dashboard_data['pending_noting']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(255, 193, 7, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <?php if ($dashboard_data['pending_noting'] > 0): ?>
                                    <i class="fa fa-clock text-warning"></i>
                                    <span class="text-warning">Awaiting your notation</span>
                                <?php else: ?>
                                    <i class="fa fa-check text-success"></i>
                                    <span class="text-success">All noted</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Request Status Overview -->
            <div class="row">
                <!-- Total Processed This Month -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-check-2 text-success"></i>
                                    </div>
                                    <div class="numbers text-center">
                                        <p class="card-category mb-0">Total Processed</p>
                                        <p class="card-title text-success" style="font-size: 2rem; font-weight: bold;">
                                            <?php echo $dashboard_data['total_processed']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(40, 167, 69, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <i class="fa fa-calendar text-success"></i> This month
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Disapproved -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-simple-remove text-danger"></i>
                                    </div>
                                    <div class="numbers text-center">
                                        <p class="card-category mb-0">Disapproved</p>
                                        <p class="card-title text-danger" style="font-size: 2rem; font-weight: bold;">
                                            <?php echo $dashboard_data['total_disapproved']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(220, 53, 69, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <i class="fa fa-calendar text-danger"></i> This month
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Today's Actions -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-calendar-60 text-primary"></i>
                                    </div>
                                    <div class="numbers text-center">
                                        <p class="card-category mb-0">Today's Actions</p>
                                        <p class="card-title text-primary" style="font-size: 2rem; font-weight: bold;">
                                            <?php echo $dashboard_data['today_actions']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(0, 123, 255, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <i class="fa fa-calendar-day text-primary"></i> <?php echo date('M d, Y'); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Average Processing Time -->
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="icon-big text-center">
                                        <i class="nc-icon nc-time-alarm text-secondary"></i>
                                    </div>
                                    <div class="numbers text-center">
                                        <p class="card-category mb-0">Avg. Processing Time</p>
                                        <p class="card-title text-secondary" style="font-size: 2rem; font-weight: bold;">
                                            <?php echo $dashboard_data['avg_processing_time']; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer" style="background-color: rgba(108, 117, 125, 0.1);">
                            <hr class="mb-2 mt-0">
                            <div class="stats text-center">
                                <i class="fa fa-clock text-secondary"></i> Hours average
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row">
                <!-- Request Flow Chart -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Request Flow Status</h5>
                            <p class="card-category">Current approval pipeline</p>
                        </div>
                        <div class="card-body">
                            <canvas id="requestFlowChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Monthly Activity Chart -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Monthly Activity</h5>
                            <p class="card-category">Your actions this month</p>
                        </div>
                        <div class="card-body">
                            <canvas id="monthlyActivityChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Request Types Distribution -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Request Types Distribution</h5>
                            <p class="card-category">Processed by type</p>
                        </div>
                        <div class="card-body">
                            <canvas id="formTypesChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Monthly Trend Chart -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Monthly Processing Trends</h5>
                            <p class="card-category">Last 6 months overview</p>
                        </div>
                        <div class="card-body">
                            <canvas id="monthlyTrendChart" height="100"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pending Actions Table -->
            <div class="row" id="pendingActionsSection">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Pending Actions</h5>
                            <p class="card-category">
                                <?php if (($dashboard_data['pending_checking'] ?? 0) > 0 || 
                                         ($dashboard_data['pending_approval'] ?? 0) > 0 || 
                                         ($dashboard_data['pending_noting'] ?? 0) > 0): ?>
                                    Forms requiring your action
                                <?php else: ?>
                                    No pending actions at this time
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover" id="approverPendingTable">
                                    <thead class="text-primary">
                                        <th>Request ID</th>
                                        <th>Form Type</th>
                                        <th>Requestor</th>
                                        <th>Department</th>
                                        <th>Action Required</th>
                                        <th>Submitted At</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activities Table -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Recent Activities</h5>
                            <p class="card-category">Your recent approvals and actions</p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover" id="approverRecentTable">
                                    <thead class="text-primary">
                                        <th>Control No</th>
                                        <th>Requestor</th>
                                        <th>Your Action</th>
                                        <th>Action Date</th>
                                        <th>Current Status</th>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include INCLUDES_PATH . '/footer.php'; ?>
    </div>
</div>

<style>
    /* Enhanced card styling */
    .card-stats {
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        overflow: hidden;
    }
    
    .card-stats:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
    }
    
    .card-stats .card-body {
        padding: 20px 15px;
    }
    
    .card-stats .icon-big {
        font-size: 3rem;
        margin-bottom: 10px;
        opacity: 0.8;
    }
    
    .card-stats .card-title {
        margin-bottom: 0;
        line-height: 1;
    }
    
    .card-stats .card-category {
        font-size: 0.875rem;
        text-transform: uppercase;
        font-weight: 500;
        letter-spacing: 0.5px;
        opacity: 0.8;
    }
    
    .card-stats .card-footer {
        padding: 10px 15px;
        background-color: rgba(0, 0, 0, 0.03);
    }
    
    .card-stats .card-footer hr {
        margin: 0 -15px 10px;
        border-top-color: rgba(0, 0, 0, 0.1);
    }
    
    .card-stats .stats {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 500;
    }
    
    /* Animated number counter effect */
    @keyframes countUp {
        from {
            opacity: 0;
            transform: scale(0.5);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
    
    .card-stats .card-title {
        animation: countUp 0.5s ease-out;
    }
    
    #approverPendingTable_wrapper, #approverRecentTable_wrapper {
        width: 100%;
    }
    
    #approverPendingTable, #approverRecentTable {
        width: 100% !important;
    }
</style>

<script>
$(document).ready(function() {
    // Check if there are any pending actions based on the dashboard stats
    const hasPendingActions = <?php echo json_encode(
        ($dashboard_data['pending_checking'] ?? 0) > 0 || 
        ($dashboard_data['pending_approval'] ?? 0) > 0 || 
        ($dashboard_data['pending_noting'] ?? 0) > 0
    ); ?>;
    
    // Hide the pending actions table if no pending actions
    if (!hasPendingActions) {
        $('#pendingActionsSection').hide();
    }
    
    // Request Flow Chart
    const requestFlowCtx = document.getElementById('requestFlowChart').getContext('2d');
    new Chart(requestFlowCtx, {
        type: 'doughnut',
        data: {
            labels: ['Pending Check', 'Pending Approval', 'Pending Note', 'Completed'],
            datasets: [{
                data: [
                    <?php echo $dashboard_data['pending_checking']; ?>,
                    <?php echo $dashboard_data['pending_approval']; ?>,
                    <?php echo $dashboard_data['pending_noting']; ?>,
                    <?php echo $dashboard_data['total_processed']; ?>
                ],
                backgroundColor: [
                    'rgba(23, 162, 184, 0.8)',
                    'rgba(40, 167, 69, 0.8)',
                    'rgba(255, 193, 7, 0.8)',
                    'rgba(130, 183, 243, 0.8)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            }
        }
    });

    // Monthly Activity Chart
    const monthlyActivityCtx = document.getElementById('monthlyActivityChart').getContext('2d');
    new Chart(monthlyActivityCtx, {
        type: 'bar',
        data: {
            labels: ['Checked', 'Approved', 'Noted', 'Disapproved'],
            datasets: [{
                label: 'Actions',
                data: [
                    <?php echo $dashboard_data['monthly_checked'] ?? 0; ?>,
                    <?php echo $dashboard_data['monthly_approved'] ?? 0; ?>,
                    <?php echo $dashboard_data['monthly_noted'] ?? 0; ?>,
                    <?php echo $dashboard_data['total_disapproved']; ?>
                ],
                backgroundColor: [
                    'rgba(23, 162, 184, 0.8)',
                    'rgba(40, 167, 69, 0.8)',
                    'rgba(255, 193, 7, 0.8)',
                    'rgba(220, 53, 69, 0.8)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Form Types Chart - Changed to Bar Chart
    const formTypesCtx = document.getElementById('formTypesChart').getContext('2d');
    new Chart(formTypesCtx, {
        type: 'bar',
        data: {
            labels: ['RTS Forms', 'NG Forms', 'Coil & Solder'],
            datasets: [{
                label: 'Forms Processed',
                data: [
                    <?php echo $dashboard_data['form_types']['rts'] ?? 0; ?>,
                    <?php echo $dashboard_data['form_types']['ng'] ?? 0; ?>,
                    <?php echo $dashboard_data['form_types']['coil_solder'] ?? 0; ?>
                ],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 206, 86, 0.8)',
                    'rgba(75, 192, 192, 0.8)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Monthly Trend Chart
    const monthlyData = <?php echo json_encode($dashboard_data['monthly_trend']); ?>;
    const monthlyTrendCtx = document.getElementById('monthlyTrendChart').getContext('2d');
    new Chart(monthlyTrendCtx, {
        type: 'line',
        data: {
            labels: monthlyData.labels,
            datasets: [{
                label: 'Checked',
                data: monthlyData.checked,
                borderColor: 'rgba(23, 162, 184, 1)',
                backgroundColor: 'rgba(23, 162, 184, 0.1)',
                tension: 0.1
            }, {
                label: 'Approved',
                data: monthlyData.approved,
                borderColor: 'rgba(40, 167, 69, 1)',
                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                tension: 0.1
            }, {
                label: 'Noted',
                data: monthlyData.noted,
                borderColor: 'rgba(255, 193, 7, 1)',
                backgroundColor: 'rgba(255, 193, 7, 0.1)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    
    // Pending actions table
    $('#approverPendingTable').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo BASE_URL; ?>/pages/approver/fetch_pending_approvals.php",
            "type": "POST",
            "dataSrc": function(json) {
                // If no data, hide the table section
                if (!json.data || json.data.length === 0) {
                    $('#pendingActionsSection').fadeOut();
                } else {
                    $('#pendingActionsSection').fadeIn();
                }
                return json.data;
            }
        },
        "columns": [
            {"data": "control_no"},
            {
                "data": "form_type",
                "render": function(data) {
                    let badgeClass = 'badge-secondary';
                    if (data === 'RTS Form') badgeClass = 'badge-primary';
                    else if (data === 'NG Form') badgeClass = 'badge-warning';
                    else if (data === 'Coil & Solder Form') badgeClass = 'badge-info';
                    return `<span class="badge ${badgeClass}">${data}</span>`;
                }
            },
            {"data": "requestor_name"},
            {"data": "requestor_department"},
            {
                "data": "action_required",
                "render": function(data, type, row) {
                    let badgeClass = 'badge-secondary';
                    if (data === 'Check') badgeClass = 'badge-info';
                    else if (data === 'Approve') badgeClass = 'badge-success';
                    else if (data === 'Note') badgeClass = 'badge-warning';
                    return `<span class="badge ${badgeClass}">${data}</span>`;
                }
            },
            {
                "data": "created_at",
                "render": function(data, type, row) {
                    if (type === 'display' && data) {
                        const date = new Date(data);
                        return date.toLocaleString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: 'numeric',
                            minute: 'numeric',
                            hour12: true
                        });
                    }
                    return data;
                }
            },
            {
                "data": null,
                "orderable": false,
                "render": function(data, type, row) {
                    let redirectUrl = '';
                    let redirectParams = '';
                    
                    if (row.action_required === 'Check') {
                        redirectUrl = '<?php echo BASE_URL; ?>/pages/requests/pending_requests.php';
                    } else if (row.action_required === 'Approve' || row.action_required === 'Note') {
                        redirectUrl = '<?php echo BASE_URL; ?>/pages/requests/ongoing_requests.php';
                    }
                    
                    redirectParams = `?id=${row.id}&type=${encodeURIComponent(row.form_type)}&action=${encodeURIComponent(row.action_required)}`;
        
                    return `<a href="${redirectUrl}${redirectParams}" 
                    class="btn btn-sm btn-primary">
                    <i class="fa fa-eye"></i> View
                </a>`;
                }
            }
        ],
        "order": [[5, "desc"]],
        "pageLength": 10,
        "drawCallback": function(settings) {
            const api = this.api();
            const rowCount = api.rows({page: 'current'}).count();
            if (rowCount === 0) {
                                $('#approverPendingTable tbody').html(
                    '<tr><td colspan="7" class="text-center text-muted">No pending actions at this time</td></tr>'
                );
            }
        }
    });

    // Recent activities table
    $('#approverRecentTable').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo BASE_URL; ?>/pages/approver/fetch_recent_activities.php",
            "type": "POST"
        },
        "columns": [
            {"data": "control_no"},
            {"data": "requestor_name"},
            {
                "data": "action_taken",
                "render": function(data, type, row) {
                    let badgeClass = 'badge-secondary';
                    if (data.includes('Disapproved')) badgeClass = 'badge-danger';
                    else if (data === 'Checked' || data.includes('Checked')) badgeClass = 'badge-info';
                    else if (data === 'Approved' || data.includes('Approved')) badgeClass = 'badge-success';
                    else if (data === 'Noted' || data.includes('Noted')) badgeClass = 'badge-warning';
                    return `<span class="badge ${badgeClass}">${data}</span>`;
                }
            },
            {
                "data": "action_date",
                "render": function(data, type, row) {
                    if (type === 'display' && data) {
                        const date = new Date(data);
                        return date.toLocaleString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: 'numeric',
                            minute: 'numeric',
                            hour12: true
                        });
                    }
                    return data;
                }
            },
            {
                "data": "material_status",
                "render": function(data, type, row) {
                    let badgeClass = 'badge-secondary';
                    if (data === 'Completed') badgeClass = 'badge-success';
                    else if (data === 'In-Progress') badgeClass = 'badge-info';
                    else if (data === 'Disapproved') badgeClass = 'badge-danger';
                    else if (data === 'Pending') badgeClass = 'badge-warning';
                    return `<span class="badge ${badgeClass}">${data}</span>`;
                }
            }
        ],
        "order": [[3, "desc"]],
        "pageLength": 10
    });
});
</script>
