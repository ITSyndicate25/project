<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

$rts_id = $_GET['id'] ?? null;

// User role and ID from session for dynamic display
$user_role = $_SESSION['user_role'] ?? '';
$user_id = $_SESSION['user_id'] ?? null;

// The function to get all RTS details
$rts_data = getRTSDetails($rts_id);

$rts = $rts_data['rts'];
$items = $rts_data['items'];
$error_message = $rts_data['error_message'];

if ($error_message) {
    echo "<div class='alert alert-danger'>$error_message</div>";
    exit();
}

// Extract signatures if they exist
$prepared_by_signature_base64 = $rts['prepared_by_signature_base64'] ?? null;
$checked_by_signature_base64 = $rts['checked_by_signature_base64'] ?? null;
$approved_by_signature_base64 = $rts['approved_by_signature_base64'] ?? null;
$noted_by_signature_base64 = $rts['noted_by_signature_base64'] ?? null;

// Calculate material details pagination
$items_per_page = 15; // Adjust based on your needs
$total_items = count($items);
$total_pages = $total_items > 0 ? ceil($total_items / $items_per_page) : 1;
?>

<style>
    /* Enhanced A4 Print Optimized Styles with Wider Layout */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        padding: 0;
    }

    .rts-document {
        font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        max-width: 95vw; /* Much wider for better viewing */
        width: 100%;
        min-height: 100vh;
        margin: 0 auto;
        padding: 20px;
        background: white;
        color: #1a1a1a;
        line-height: 1.4;
        font-size: 11pt;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }

    /* Corporate Header */
    .document-header {
        border-bottom: 3px solid #264c7eff;
        padding-bottom: 15px;
        margin-bottom: 25px;
        position: relative;
    }

    .company-info {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 15px;
    }

    .company-logo {
        max-height: 45px;
        width: auto;
    }

    .company-details {
        text-align: right;
        font-size: 9pt;
        color: #666;
        line-height: 1.3;
    }

    .document-title {
        text-align: center;
        margin: 15px 0 10px 0;
    }

    .document-title h1 {
        font-size: 20pt;
        font-weight: 700;
        color: #1a1a1a;
        margin: 0;
        letter-spacing: 0.5px;
        text-transform: uppercase;
    }

    .document-title .subtitle {
        font-size: 11pt;
        color: #666;
        font-weight: 400;
        margin-top: 3px;
    }

    /* Control Number Box */
    .control-number-box {
        position: absolute;
        right: 0;
        top: 0;
        border: 2px solid #080808ff;
        padding: 10px 15px;
        background: #fff;
        min-width: 140px;
    }

    .control-number-box .label {
        font-size: 8pt;
        color: #666;
        font-weight: 600;
        text-transform: uppercase;
        margin-bottom: 2px;
        display: block;
    }

    .control-number-box .value {
        font-size: 14pt;
        font-weight: 700;
        color: #0a0a0aff;
        font-family: 'Courier New', monospace;
    }

    /* Form Sections */
    .form-section {
        margin-bottom: 25px;
        page-break-inside: avoid;
    }

    .section-header {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        border-left: 4px solid #264c7eff;
        padding: 10px 20px;
        margin-bottom: 15px;
        font-weight: 600;
        font-size: 12pt;
        color: #2c3e50;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        border-radius: 0 4px 4px 0;
    }

    /* Field Grid - Enhanced for wider layout */
    .field-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 20px;
    }

    .field-group {
        display: flex;
        flex-direction: column;
    }

    .field-label {
        font-size: 9pt;
        font-weight: 600;
        color: #495057;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        margin-bottom: 5px;
        border-bottom: 1px solid #dee2e6;
        padding-bottom: 3px;
    }

    .field-value {
        font-size: 11pt;
        color: #1a1a1a;
        padding: 8px 0;
        min-height: 25px;
        word-wrap: break-word;
        font-weight: 400;
    }

    .field-value.large {
        font-size: 12pt;
        font-weight: 500;
    }

    /* Special Field Types */
    .field-value.status {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 15px;
        font-size: 10pt;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.2px;
    }

    .status.good { background: #d4edda; color: #155724; }
    .status.defect { background: #f8d7da; color: #721c24; }
    .status.error { background: #fff3cd; color: #856404; }
    .status.eol { background: #e2e3e5; color: #383d41; }

    /* Approval Matrix */
    .approval-matrix {
        margin: 25px 0;
        border: 1px solid #dee2e6;
        border-radius: 6px;
        overflow: hidden;
        page-break-inside: avoid;
    }

    .approval-matrix table {
        width: 100%;
        border-collapse: collapse;
        font-size: 10pt;
    }

    .approval-matrix th {
        background: #f8f9fa;
        padding: 12px 10px;
        text-align: center;
        font-weight: 600;
        color: #495057;
        border-right: 1px solid #dee2e6;
        text-transform: uppercase;
        letter-spacing: 0.2px;
    }

    .approval-matrix td {
        padding: 20px 10px;
        text-align: center;
        vertical-align: middle;
        border-right: 1px solid #dee2e6;
        border-bottom: 1px solid #dee2e6;
        min-height: 100px;
    }

    .approval-matrix th:last-child,
    .approval-matrix td:last-child {
        border-right: none;
    }

    .signature-area {
        display: flex;
        flex-direction: column;
        align-items: center;
        min-height: 90px;
        justify-content: space-between;
    }

    .signature-image {
        max-width: 100px;
        max-height: 50px;
        margin-bottom: 8px;
        border: 1px solid #e9ecef;
        border-radius: 4px;
        padding: 3px;
    }

    .signature-name {
        font-weight: 600;
        color: #1a1a1a;
        font-size: 10pt;
        text-align: center;
        margin-bottom: 3px;
    }

    .signature-date {
        font-size: 8pt;
        color: #6c757d;
        text-align: center;
    }

    /* Enhanced Material Details Table for Multiple Items */
    .materials-section {
        margin-top: 30px;
        page-break-inside: avoid;
    }

    .materials-container {
        width: 100%;
        overflow-x: auto;
        border: 1px solid #dee2e6;
        border-radius: 6px;
        margin-top: 15px;
    }

    .materials-table {
        width: 100%;
        min-width: 1400px; /* Ensure proper width for all columns */
        border-collapse: collapse;
        font-size: 9pt;
        background: white;
    }

    .materials-table th {
        background: #f8f9fa;
        padding: 10px 8px;
        text-align: center;
        font-weight: 600;
        color: #495057;
        border: 1px solid #dee2e6;
        text-transform: uppercase;
        letter-spacing: 0.1px;
        line-height: 1.2;
        position: sticky;
        top: 0;
        z-index: 10;
    }

    .materials-table td {
        padding: 8px;
        border: 1px solid #dee2e6;
        text-align: left;
        vertical-align: top;
        word-wrap: break-word;
        font-size: 9pt;
    }

    .materials-table td.number {
        text-align: center;
        font-weight: 500;
    }

    .materials-table td.amount {
        text-align: right;
        font-family: 'Courier New', monospace;
        font-weight: 500;
    }

    /* Zebra striping for better readability */
    .materials-table tbody tr:nth-child(even) {
        background: #f9f9f9;
    }

    .materials-table tbody tr:hover {
        background: #e3f2fd;
    }

    /* Summary row styling */
    .materials-table .summary-row {
        background: #f8f9fa !important;
        font-weight: 600;
        border-top: 2px solid #264c7eff !important;
    }

    .materials-table .summary-row td {
        font-weight: 600;
        background: #f8f9fa !important;
    }

    /* Page break handling for large material lists */
    .materials-page-break {
        page-break-before: always;
    }

    /* Material count indicator */
    .material-count-info {
        background: #e3f2fd;
        border: 1px solid #2196f3;
        border-radius: 4px;
        padding: 8px 12px;
        margin-bottom: 10px;
        font-size: 9pt;
        color: #1565c0;
    }

    /* Status Alert */
    .status-alert {
        background: #e3f2fd;
        border: 1px solid #2196f3;
        border-radius: 6px;
        padding: 15px 20px;
        margin: 20px 0;
        font-size: 11pt;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .status-alert.completed {
        background: #d4edda;
        border-color: #28a745;
        color: #155724;
    }

    .status-alert.disapproved {
        background: #f8d7da;
        border-color: #dc3545;
        color: #721c24;
    }

    .action-buttons {
        display: flex;
        gap: 10px;
    }

    .btn {
        padding: 8px 16px;
        border: none;
        border-radius: 4px;
        font-size: 10pt;
        font-weight: 500;
        cursor: pointer;
        text-transform: uppercase;
        letter-spacing: 0.2px;
    }

    .btn-approve {
        background: #28a745;
        color: white;
    }

    .btn-disapprove {
        background: #dc3545;
        color: white;
    }

    /* Footer */
    .document-footer {
        margin-top: 40px;
        padding-top: 20px;
        border-top: 1px solid #dee2e6;
        font-size: 9pt;
        color: #6c757d;
        text-align: center;
        page-break-inside: avoid;
    }

    /* Enhanced Print Optimizations */
    @media print {
        body {
            margin: 0 !important;
            padding: 0 !important;
            background: white !important;
        }

        /* Hide everything except the document */
        body * {
            visibility: hidden;
        }

        #pdf-content, 
        #pdf-content * {
            visibility: visible;
        }

        #pdf-content {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 210mm !important;
            max-width: 210mm !important;
            margin: 0 !important;
            padding: 15mm !important;
            box-shadow: none !important;
            page-break-after: auto;
        }

        /* Hide interactive elements */
        .status-alert,
        .action-buttons,
        .modal-footer,
        .approval-alert {
            display: none !important;
            visibility: hidden !important;
        }

        /* Optimize table for print */
        .materials-container {
            overflow: visible !important;
            border: none !important;
        }

        .materials-table {
            min-width: auto !important;
            width: 100% !important;
            font-size: 7pt !important;
        }

        .materials-table th,
        .materials-table td {
            padding: 4px 2px !important;
            font-size: 7pt !important;
            border: 0.5pt solid #000 !important;
        }

        /* Approval matrix print optimization */
        .approval-matrix td {
            min-height: 60px !important;
            padding: 10px 5px !important;
        }

        .signature-image {
            max-width: 60px !important;
            max-height: 30px !important;
        }

        /* Page breaks for large material lists */
        .materials-page-break {
            page-break-before: always !important;
        }

        /* Ensure proper page margins */
        @page {
            margin: 15mm;
            size: A4;
        }

        /* Print-specific font sizes */
        .document-title h1 {
            font-size: 16pt !important;
        }

        .section-header {
            font-size: 10pt !important;
            padding: 8px 15px !important;
        }

        .field-value {
            font-size: 9pt !important;
        }
    }

    /* Responsive Design */
    @media (max-width: 1200px) {
        .rts-document {
            max-width: 98vw;
            padding: 15px;
        }

        .materials-table {
            min-width: 1200px;
        }
    }

    @media (max-width: 768px) {
        .rts-document {
            padding: 10px;
            margin: 5px;
        }

        .company-info {
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .company-details {
            text-align: center;
            margin-top: 10px;
        }

        .control-number-box {
            position: relative;
            margin: 10px auto;
        }

        .field-grid {
            grid-template-columns: 1fr;
        }

        .materials-container {
            border-radius: 0;
        }

        .materials-table {
            font-size: 8pt;
            min-width: 1000px;
        }

        .approval-matrix {
            overflow-x: auto;
        }

        .status-alert {
            flex-direction: column;
            gap: 10px;
            text-align: center;
        }

        .action-buttons {
            width: 100%;
            justify-content: center;
        }
    }

    /* Disapproval Reason */
    .disapproval-reason {
        background: #fff5f5;
        border-left: 4px solid #dc3545;
        padding: 12px 18px;
        margin: 15px 0;
        font-size: 10pt;
        color: #721c24;
        border-radius: 0 4px 4px 0;
    }

    .disapproval-reason .label {
        font-weight: 600;
        text-transform: uppercase;
        font-size: 9pt;
        margin-bottom: 5px;
        display: block;
    }

    /* Loading and scroll indicators */
    .scroll-indicator {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #264c7eff;
        color: white;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 9pt;
        z-index: 1000;
        display: none;
    }

    .scroll-indicator.show {
        display: block;
    }
</style>

<div class="rts-document" id="pdf-content">
    <!-- Document Header -->
    <div class="document-header no-page-break">
        <div class="company-info">
            <img src="<?php echo BASE_URL; ?>/assets/img/logo_black.png" alt="Fujifilm Logo" class="company-logo">
            <div class="company-details">
                <div><strong>FUJIFILM Corporation</strong></div>
                <div>Manufacturing Operations</div>
                <div>Quality Assurance Department</div>
                <div>Document Control System</div>
            </div>
        </div>
        
        <div class="control-number-box">
            <span class="label">Control No.</span>
            <div class="value"><?= htmlspecialchars($rts['control_no'] ?? 'N/A') ?></div>
        </div>

        <div class="document-title">
            <h1>Return / Transfer Slip</h1>
            <div class="subtitle">Centralized Return to Vendor & Return To Stock Monitoring System</div>
        </div>
    </div>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error_message); ?></div>
    <?php elseif ($rts): ?>

        <!-- Request Information -->
        <div class="form-section no-page-break">
            <div class="section-header">
                <i class="fas fa-info-circle"></i> Request Information
            </div>
            <div class="field-grid">
                <div class="field-group">
                    <div class="field-label">Submitted By</div>
                    <div class="field-value large"><?= htmlspecialchars($rts['submitted_by'] ?? 'N/A') ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Department</div>
                    <div class="field-value"><?= htmlspecialchars($rts['department'] ?? 'N/A') ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Date Submitted</div>
                    <div class="field-value"><?= $rts['created_at'] instanceof DateTime ? $rts['created_at']->format('M d, Y') : 'N/A' ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Return Date</div>
                    <div class="field-value"><?= ($rts['return_date'] instanceof DateTime) ? $rts['return_date']->format('M d, Y') : 'N/A' ?></div>
                </div>
            </div>
        </div>

        <!-- Material Classification -->
        <div class="form-section no-page-break">
            <div class="section-header">
                <i class="fas fa-boxes"></i> Material Classification
            </div>
            <div class="field-grid">
                <div class="field-group">
                    <div class="field-label">Material Type</div>
                    <div class="field-value"><?= htmlspecialchars($rts['material_type'] ?? 'N/A') ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Material Status</div>
                    <div class="field-value">
                        <?php
                        $status_value = strtolower($rts['material_status'] ?? '');
                        $status_display = $status_value === 'defective' ? 'Material Defect' : htmlspecialchars($rts['material_status'] ?? 'N/A');
                        $status_class = match($status_value) {
                            'good' => 'good',
                            'defective', 'material defect' => 'defect',
                            'human error' => 'error',
                            'eol' => 'eol',
                            default => 'defect'
                        };
                        ?>
                        <span class="status <?= $status_class ?>"><?= $status_display ?></span>
                    </div>
                </div>
                <div class="field-group">
                    <div class="field-label">Judgement</div>
                    <div class="field-value"><?= htmlspecialchars($rts['judgement'] ?? 'N/A') ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Model</div>
                    <div class="field-value"><?= htmlspecialchars($rts['model'] ?? 'N/A') ?></div>
                </div>
            </div>
        </div>

        <!-- SAP Location & Additional Information -->
        <div class="form-section no-page-break">
            <div class="section-header">
                <i class="fas fa-map-marker-alt"></i> Location & Additional Information
            </div>
            <div class="field-grid">
                <div class="field-group" style="grid-column: 1 / -1;">
                    <div class="field-label">SAP Location Details</div>
                    <div class="field-value">
                        <strong>Code:</strong> <?= htmlspecialchars($rts['sap_loc_code'] ?? 'N/A') ?> | 
                        <strong>Description:</strong> <?= htmlspecialchars($rts['LocationDescription'] ?? 'N/A') ?> | 
                        <strong>Department:</strong> <?= htmlspecialchars($rts['sap_department'] ?? 'N/A') ?>
                    </div>
                </div>
                <div class="field-group">
                    <div class="field-label">Details (Others)</div>
                    <div class="field-value">
                        <?= nl2br(htmlspecialchars(empty($rts['details']) ? 'N/A' : $rts['details'])) ?>
                    </div>
                </div>
                <div class="field-group">
                    <div class="field-label">Remarks</div>
                    <div class="field-value">
                        <?= nl2br(htmlspecialchars(empty($rts['remark']) ? 'N/A' : $rts['remark'])) ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Status Alert -->
        <?php
        $show_buttons = false;
        $action_role = '';
        $action_message = '';
        
        $current_status_from_db = $rts['material_status'] ?? 'N/A';

        if ($current_status_from_db === 'Completed') {
            $action_message = 'This request has been successfully completed and approved.';
            $alert_class = 'completed';
        } elseif ($current_status_from_db === 'Disapproved') {
            $disapproved_by_role = $rts['disapproved_by_role'] ?? '';
            $action_message = 'This request has been disapproved.';
            $alert_class = 'disapproved';
        } else {
            $alert_class = '';
            if (str_contains($user_role, 'checker') && ($rts['checked_status'] ?? '') === 'Pending') {
                $show_buttons = true;
                $action_role = 'checker';
                $action_message = 'This request is pending your review as a Checker.';
            } elseif (str_contains($user_role, 'approver') && ($rts['checked_status'] ?? '') === 'Approved' && ($rts['approved_status'] ?? '') === 'Pending') {
                $show_buttons = true;
                $action_role = 'approver';
                $action_message = 'This request is pending your approval as an Approver.';
            } elseif (str_contains($user_role, 'noter') && ($rts['checked_status'] ?? '') === 'Approved' && ($rts['approved_status'] ?? '') === 'Approved' && ($rts['noted_status'] ?? '') === 'Pending') {
                $show_buttons = true;
                $action_role = 'noter';
                $action_message = 'This request is pending your notes as a Noter.';
            } else {
                $action_message = 'This request is currently pending review in the approval workflow.';
            }
        }
        ?>

        <div class="status-alert <?= $alert_class ?> approval-alert">
            <span><strong>Status:</strong> <?= htmlspecialchars($action_message) ?></span>
            <?php if ($show_buttons): ?>
                <div class="action-buttons">
                    <button type="button" class="btn btn-approve approve-btn" 
                            data-rts-id="<?= $rts['id'] ?>" data-role="<?= htmlspecialchars($action_role) ?>">
                        <i class="fa fa-check"></i> Approve
                    </button>
                    <button type="button" class="btn btn-disapprove disapprove-btn" 
                            data-rts-id="<?= $rts['id'] ?>" data-role="<?= htmlspecialchars($action_role) ?>">
                        <i class="fa fa-times"></i> Disapprove
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <!-- Approval Matrix -->
        <div class="form-section no-page-break">
            <div class="section-header">
                <i class="fas fa-clipboard-check"></i> Approval Matrix
            </div>
            
            <div class="approval-matrix">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 25%;">Prepared By</th>
                            <th style="width: 25%;">Checked By</th>
                            <th style="width: 25%;">Approved By</th>
                            <th style="width: 25%;">Noted By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="signature-area">
                                    <?php if (!empty($prepared_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($prepared_by_signature_base64) ?>" 
                                             alt="Prepared By Signature" class="signature-image">
                                    <?php endif; ?>
                                    <div class="signature-name"><?= htmlspecialchars($rts['submitted_by'] ?? 'N/A') ?></div>
                                    <div class="signature-date">
                                        <?= $rts['created_at'] instanceof DateTime ? $rts['created_at']->format('M d, Y \a\t g:i A') : 'N/A' ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="signature-area">
                                    <?php if (($rts['checked_status'] ?? '') === 'Disapproved'): ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/not-approved.jpg'; ?>" 
                                             alt="Disapproved" class="signature-image">
                                    <?php elseif (!empty($checked_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($checked_by_signature_base64) ?>" 
                                             alt="Checked By Signature" class="signature-image">
                                    <?php else: ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" 
                                             alt="Pending" class="signature-image">
                                    <?php endif; ?>
                                    <div class="signature-name"><?= htmlspecialchars($rts['checked_by_name'] ?? 'Pending') ?></div>
                                    <div class="signature-date">
                                        <?= ($rts['checked_at'] ?? null) instanceof DateTime ? $rts['checked_at']->format('M d, Y \a\t g:i A') : 'Pending' ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="signature-area">
                                    <?php if (($rts['approved_status'] ?? '') === 'Disapproved'): ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/not-approved.jpg'; ?>" 
                                             alt="Disapproved" class="signature-image">
                                                                        <?php elseif (!empty($approved_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($approved_by_signature_base64) ?>" 
                                             alt="Approved By Signature" class="signature-image">
                                    <?php else: ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" 
                                             alt="Pending" class="signature-image">
                                    <?php endif; ?>
                                    <div class="signature-name"><?= htmlspecialchars($rts['approved_by_name'] ?? 'Pending') ?></div>
                                    <div class="signature-date">
                                        <?= ($rts['approved_at'] ?? null) instanceof DateTime ? $rts['approved_at']->format('M d, Y \a\t g:i A') : 'Pending' ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="signature-area">
                                    <?php if (($rts['noted_status'] ?? '') === 'Disapproved'): ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/not-approved.jpg'; ?>" 
                                             alt="Disapproved" class="signature-image">
                                    <?php elseif (!empty($noted_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($noted_by_signature_base64) ?>" 
                                             alt="Noted By Signature" class="signature-image">
                                    <?php else: ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" 
                                             alt="Pending" class="signature-image">
                                    <?php endif; ?>
                                    <div class="signature-name"><?= htmlspecialchars($rts['noted_by_name'] ?? 'Pending') ?></div>
                                    <div class="signature-date">
                                        <?= ($rts['noted_at'] ?? null) instanceof DateTime ? $rts['noted_at']->format('M d, Y \a\t g:i A') : 'Pending' ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <?php if (!empty($rts['disapproval_reason'])): ?>
                <div class="disapproval-reason">
                    <span class="label">Disapproval Reason:</span>
                    <?= htmlspecialchars($rts['disapproval_reason']) ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Material Details with Enhanced Handling for Multiple Items -->
        <div class="materials-section">
            <div class="section-header">
                <i class="fas fa-list-alt"></i> Material Details
            </div>
            
            <?php if (!empty($items)): ?>
                <div class="material-count-info">
                    <strong>Total Materials:</strong> <?= $total_items ?> items
                    <?php if ($total_pages > 1): ?>
                        | <strong>Pages:</strong> <?= $total_pages ?> pages for printing
                    <?php endif ?>
                </div>
            <?php endif; ?>
            
            <div class="materials-container">
                <table class="materials-table">
                    <thead>
                        <tr>
                            <th style="width: 4%;">No.</th>
                            <th style="width: 10%;">Ref. No</th>
                            <th style="width: 12%;">SAP Mat Doc Ref</th>
                            <th style="width: 10%;">Invoice No</th>
                            <th style="width: 12%;">Supplier</th>
                            <th style="width: 10%;">Part Number</th>
                            <th style="width: 12%;">Part Name</th>
                            <th style="width: 15%;">Description</th>
                            <th style="width: 6%;">Qty Returned</th>
                            <th style="width: 6%;">Qty Received</th>
                            <th style="width: 8%;">Amount</th>
                            <th style="width: 8%;">Due Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($items)): ?>
                            <tr>
                                <td colspan="12" style="text-align: center; font-style: italic; color: #6c757d; padding: 30px;">
                                    <i class="fas fa-inbox" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                                    No material details found for this request.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php 
                            $counter = 1; 
                            $total_amount = 0;
                            $total_qty_returned = 0;
                            $total_qty_received = 0;
                            ?>
                            <?php foreach ($items as $index => $item): ?>
                                <?php
                                // Add page break every 15 items for print optimization
                                if ($index > 0 && $index % $items_per_page === 0): ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="materials-container materials-page-break">
                                <table class="materials-table">
                                    <thead>
                                        <tr>
                                            <th style="width: 4%;">No.</th>
                                            <th style="width: 10%;">Ref. No</th>
                                            <th style="width: 12%;">SAP Mat Doc Ref</th>
                                            <th style="width: 10%;">Invoice No</th>
                                            <th style="width: 12%;">Supplier</th>
                                            <th style="width: 10%;">Part Number</th>
                                            <th style="width: 12%;">Part Name</th>
                                            <th style="width: 15%;">Description</th>
                                            <th style="width: 6%;">Qty Returned</th>
                                            <th style="width: 6%;">Qty Received</th>
                                            <th style="width: 8%;">Amount</th>
                                            <th style="width: 8%;">Due Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                <?php endif; ?>
                                
                                <tr>
                                    <td class="number"><?= $counter++ ?></td>
                                    <td><?= htmlspecialchars($item['ref_no'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($item['sap_doc'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($item['invoice_no'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($item['supplier'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($item['part_number'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($item['part_name'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($item['description'] ?? '') ?></td>
                                    <td class="number"><?= is_numeric($item['qty_returned']) ? number_format($item['qty_returned']) : '' ?></td>
                                    <td class="number"><?= is_numeric($item['qty_received']) ? number_format($item['qty_received']) : '' ?></td>
                                    <td class="amount"><?= is_numeric($item['amount']) ? '₱' . number_format($item['amount'], 2) : '' ?></td>
                                    <td class="number"><?= ($item['due_date'] instanceof DateTime) ? $item['due_date']->format('M d, Y') : '' ?></td>
                                </tr>
                                
                                <?php
                                // Calculate totals
                                if (is_numeric($item['amount'])) $total_amount += $item['amount'];
                                if (is_numeric($item['qty_returned'])) $total_qty_returned += $item['qty_returned'];
                                if (is_numeric($item['qty_received'])) $total_qty_received += $item['qty_received'];
                                ?>
                            <?php endforeach; ?>
                            
                            <!-- Summary Row -->
                            <tr class="summary-row">
                                <td colspan="8" style="text-align: right; padding-right: 15px;">
                                    <strong>GRAND TOTALS:</strong>
                                </td>
                                <td class="number" style="font-weight: 700; color: #264c7eff;">
                                    <?= number_format($total_qty_returned) ?>
                                </td>
                                <td class="number" style="font-weight: 700; color: #264c7eff;">
                                    <?= number_format($total_qty_received) ?>
                                </td>
                                <td class="amount" style="color: #264c7eff; font-weight: 700; font-size: 10pt;">
                                    ₱<?= number_format($total_amount, 2) ?>
                                </td>
                                <td></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Document Footer -->
        <div class="document-footer">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <div>
                    <strong>Generated:</strong> <?= date('M d, Y \a\t g:i A') ?><br>
                    <strong>System:</strong> FOPH-RTV-RTS System v1.0<br>
                </div>
                <div style="text-align: right;">
                    <strong>Document ID:</strong> <?= htmlspecialchars($rts['control_no'] ?? 'N/A') ?><br>
                    <strong>Print Pages:</strong> <?= $total_pages ?><br>
                </div>
            </div>
            <div style="text-align: center; border-top: 1px solid #dee2e6; padding-top: 15px; color: #6c757d;">
                <small>
                    This document is generated electronically and contains <?= $total_items ?> material entries.<br>
                    For questions or concerns, please contact the IT Department.
                </small>
            </div>
        </div>

    <?php endif; ?>
</div>

<!-- Scroll Indicator for Large Material Lists -->
<?php if ($total_items > 10): ?>
<div class="scroll-indicator" id="scrollIndicator">
    <i class="fas fa-scroll"></i> Large material list - scroll to view all items
</div>
<?php endif; ?>

<!-- Enhanced Modal Footer with Actions -->
<div class="modal-footer" style="background: #f8f9fa; border-top: 2px solid #dee2e6; padding: 20px;">
    <div style="display: flex; justify-content: space-between; width: 100%; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div style="font-size: 10pt; color: #6c757d;">
            <i class="fas fa-info-circle"></i> 
            Document optimized for viewing and printing | <?= $total_items ?> materials
        </div>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <button type="button" class="btn" id="downloadPdfBtn" 
                    style="background: #088be2ff; color: white; padding: 10px 20px; border-radius: 4px; font-weight: 500; border: none;">
                <i class="fas fa-download"></i> Save as PDF
            </button>
            <button type="button" class="btn" onclick="window.print()" 
                    style="background: #6c757d; color: white; margin-right: 10px; padding: 8px 16px; border-radius: 4px; font-weight: 500;">
                <i class="fas fa-print"></i> Print
            </button>
            <button type="button" class="btn" data-dismiss="modal" 
                    style="background: #f8f9fa; color: #495057; border: 1px solid #dee2e6; padding: 10px 20px; border-radius: 4px; font-weight: 500;">
                <i class="fas fa-times"></i> Close
            </button>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
            // Enhanced print functionality
            const printBtn = document.querySelector('button[onclick="window.print()"]');
            if (printBtn) {
                printBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Add print-specific styles before printing
                    const printStyles = document.createElement('style');
                    printStyles.id = 'print-styles';
                    printStyles.textContent = `
                        @media print {
                            body * { visibility: hidden; }
                            #pdf-content, #pdf-content * { visibility: visible; }
                            #pdf-content { 
                                position: absolute; 
                                left: 0; 
                                top: 0; 
                                width: 100% !important;
                                margin: 0 !important;
                                padding: 15mm !important;
                            }
                            .modal-footer { display: none !important; }
                            .status-alert { display: none !important; }
                            .action-buttons { display: none !important; }
                        }
                    `;
                    document.head.appendChild(printStyles);
                    
                    // Print the document
                    window.print();
                    
                    // Remove print styles after printing
                    setTimeout(() => {
                        const styleElement = document.getElementById('print-styles');
                        if (styleElement) {
                            styleElement.remove();
                        }
                    }, 1000);
                });
            }

    // PDF download functionality
    const pdfBtn = document.getElementById('downloadPdfBtn');
    if (pdfBtn) {
        pdfBtn.addEventListener('click', function() {
            const rtsId = new URLSearchParams(window.location.search).get('id') || 
                         document.querySelector('[data-rts-id]')?.dataset.rtsId;
            
            if (rtsId) {
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating PDF...';
                this.disabled = true;
                
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '<?php echo BASE_URL; ?>/generate_pdf.php';
                form.target = '_blank';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'rts_id';
                input.value = rtsId;
                
                const materialCountInput = document.createElement('input');
                materialCountInput.type = 'hidden';
                materialCountInput.name = 'material_count';
                materialCountInput.value = '<?= $total_items ?>';
                
                form.appendChild(input);
                form.appendChild(materialCountInput);
                document.body.appendChild(form);
                form.submit();
                document.body.removeChild(form);
                
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                }, 2000);
            } else {
                alert('Unable to generate PDF. RTS ID not found.');
            }
        });
    }

    // Scroll indicator for large material lists
    const scrollIndicator = document.getElementById('scrollIndicator');
    if (scrollIndicator) {
        let timeout;
        
        window.addEventListener('scroll', function() {
            scrollIndicator.classList.add('show');
            
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                scrollIndicator.classList.remove('show');
            }, 2000);
        });
        
        setTimeout(() => {
            scrollIndicator.classList.remove('show');
        }, 3000);
    }

    // Enhanced table responsiveness
    function handleResponsiveTable() {
        const materialsContainer = document.querySelector('.materials-container');
        const table = document.querySelector('.materials-table');
        
        if (materialsContainer && table) {
            if (window.innerWidth <= 1200) {
                materialsContainer.style.overflowX = 'auto';
                materialsContainer.style.webkitOverflowScrolling = 'touch';
                
                if (!materialsContainer.querySelector('.scroll-hint')) {
                    const scrollHint = document.createElement('div');
                    scrollHint.className = 'scroll-hint';
                    scrollHint.style.cssText = `
                        position: absolute;
                        top: 50%;
                        right: 10px;
                        background: rgba(0,0,0,0.7);
                        color: white;
                        padding: 5px 10px;
                        border-radius: 15px;
                        font-size: 10px;
                        pointer-events: none;
                        opacity: 0.8;
                        z-index: 10;
                    `;
                    scrollHint.textContent = '← Scroll horizontally →';
                    materialsContainer.style.position = 'relative';
                    materialsContainer.appendChild(scrollHint);
                    
                    setTimeout(() => {
                        scrollHint.style.display = 'none';
                    }, 5000);
                }
            }
        }
    }

    // Approval button functionality
    document.querySelectorAll('.approve-btn, .disapprove-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.classList.contains('approve-btn') ? 'approve' : 'disapprove';
            const rtsId = this.dataset.rtsId;
            const role = this.dataset.role;
            
            console.log(`${action} action for RTS ${rtsId} by ${role}`);
        });
    });

    // Initial setup
    handleResponsiveTable();
    window.addEventListener('resize', handleResponsiveTable);
    
    <?php if ($total_items > 10): ?>
    const materialsSection = document.querySelector('.materials-section');
    if (materialsSection) {
        materialsSection.style.animation = 'subtle-pulse 2s ease-in-out';
        
        const style = document.createElement('style');
        style.textContent = `
            @keyframes subtle-pulse {
                0%, 100% { background-color: transparent; }
                50% { background-color: rgba(38, 76, 126, 0.05); }
            }
        `;
        document.head.appendChild(style);
    }
    <?php endif; ?>
});
</script>