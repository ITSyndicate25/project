<?php
session_start();

require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once INCLUDES_PATH . '/functions.php';

// Authentication check: If the user is not logged in, redirect them to the login page.
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

// Permission check: Get the user's department and verify they have permission to access this page.
$user_department = $_SESSION['department'] ?? getUserDepartment($_SESSION['user_id']);
if (!checkScrapPermission($user_department, $_SESSION['user_role'])) {
    // If permission is denied, redirect the user based on their role.
    if ($_SESSION['user_role'] === 'admin') {
        header('Location: ' . BASE_URL . '/pages/admin/admin_dashboard.php');
    } else {
        header('Location: ' . BASE_URL . '/pages/user/user_dashboard.php');
    }
    exit();
}
?>

<?php include INCLUDES_PATH . '/header.php'; ?>

<style>
    /* Custom Dashboard Styling */
    .scrap-dashboard {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
        padding: 20px;
    }

    .scrap-card {
        width: 300px;
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        overflow: hidden;
    }

    .scrap-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
    }

    .scrap-card-header {
        background-color: #f8f9fa;
        padding: 15px;
        text-align: center;
        border-bottom: 1px solid #e0e0e0;
    }

    .scrap-card-body {
        padding: 20px;
        text-align: center;
    }

    .scrap-card-icon {
        font-size: 3rem;
        margin-bottom: 15px;
        color: #007bff;
    }

    .scrap-card-title {
        font-size: 1.2rem;
        font-weight: bold;
        margin-bottom: 15px;
        color: #333;
    }

    .scrap-card-btn {
        width: 100%;
        padding: 10px;
        background-color: #51cbce;
        color: white;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .scrap-card-btn:hover {
        background-color: #51cbce;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .scrap-dashboard {
            flex-direction: column;
            align-items: center;
        }

        .scrap-card {
            width: 90%;
            max-width: 350px;
        }
    }
</style>

<body>
    <div class="wrapper">
        <?php include INCLUDES_PATH . '/sidebar.php'; ?>

        <div class="main-panel">
            <?php include INCLUDES_PATH . '/navbar.php'; ?>

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title text-center">Scrap Management Dashboard</h4>
                                </div>

                                <div class="card-body">
                                    <div class="scrap-dashboard">
                                        <!-- RTS Form Card -->
                                        <div class="scrap-card">
                                            <div class="scrap-card-header">
                                                <i class="fas fa-recycle scrap-card-icon"></i>
                                            </div>
                                            <div class="scrap-card-body">
                                                <div class="scrap-card-title">Return / Transfer Slip (RTS) Form</div>
                                                <p class="text-muted">Create a new Return or Transfer Slip for material
                                                    management</p>
                                                <a href="rts_form.php" class="btn scrap-card-btn">Create RTS Form</a>
                                            </div>
                                        </div>

                                        <!-- NG Disposal Form Card -->
                                        <div class="scrap-card">
                                            <div class="scrap-card-header">
                                                <i class="fas fa-trash-alt scrap-card-icon"></i>
                                            </div>
                                            <div class="scrap-card-body">
                                                <div class="scrap-card-title">NG (No Good) Disposal Form</div>
                                                <p class="text-muted">Process and document NG material disposal</p>
                                                <a href="ng_disposal_form.php" class="btn scrap-card-btn">Create NG
                                                    Disposal Form</a>
                                            </div>
                                        </div>

                                        <!-- Coil & Solder Endorsement Form Card -->
                                        <div class="scrap-card">
                                            <div class="scrap-card-header">
                                                <i class="fas fa-industry scrap-card-icon"></i>
                                            </div>
                                            <div class="scrap-card-body">
                                                <div class="scrap-card-title">Coil & Solder Endorsement Form</div>
                                                <p class="text-muted">Create endorsement for Coil and Solder materials
                                                </p>
                                                <a href="coil_solder_form.php" class="btn scrap-card-btn">Create
                                                    Endorsement Form</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include INCLUDES_PATH . '/footer.php'; ?>
        </div>
    </div>
</body>