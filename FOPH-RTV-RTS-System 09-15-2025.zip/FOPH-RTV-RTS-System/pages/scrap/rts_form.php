<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/includes/functions.php';
require_once APP_ROOT . '/assets/db/connection.php';

// Call the main initialization function.
$pageData = initializeScrapRTSPageData($_SESSION['user_id'] ?? null);

// Handle redirection based on the function's return value.
if (!$pageData['success']) {
    if (isset($pageData['redirect'])) {
        header('Location: ' . $pageData['redirect']);
    }
    $showErrorAlert = true;
    $errorMessage = $pageData['message'];
} else {
    // If successful, extract the data for use in the HTML.
    $user_name = $pageData['userData']['requestor_name'];
    $user_department = $pageData['userData']['department'];
    $user_role = $pageData['userData']['role'];
    $signature_base64 = $pageData['userData']['signature_base64'];
    $departments = $pageData['departments'];
    $sap_locations = $pageData['sap_locations'];
    $control_no = $pageData['control_no'];

    // Check for form submission alerts.
    $showSuccessAlert = isset($_GET['success']) && $_GET['success'] === '1' && !empty($_GET['control_no']);
    $showErrorAlert = isset($_GET['error']);
    $controlNo = $showSuccessAlert ? htmlspecialchars($_GET['control_no']) : '';
    $errorMessage = $showErrorAlert ? htmlspecialchars($_GET['message'] ?? 'An error occurred during submission.') : '';
}
?>

<style>
    /* Enhanced Professional Corporate Styling */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
    
    :root {
        --primary-color: #264c7e;
        --secondary-color: #f8f9fa;
        --accent-color: #0066cc;
        --success-color: #28a745;
        --warning-color: #ffc107;
        --danger-color: #dc3545;
        --dark-color: #2c3e50;
        --light-color: #ecf0f1;
        --border-color: #dee2e6;
        --shadow-sm: 0 2px 4px rgba(0,0,0,0.1);
        --shadow-md: 0 4px 8px rgba(0,0,0,0.12);
        --shadow-lg: 0 8px 16px rgba(0,0,0,0.15);
        --radius-sm: 4px;
        --radius-md: 8px;
        --radius-lg: 12px;
    }

    /* Global Form Styling */
    .form-group label,
    .custom-control-label {
        color: var(--dark-color) !important;
        font-weight: 600;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        margin-bottom: 8px;
    }

    .font-weight-bold {
        color: var(--dark-color) !important;
        font-weight: 700;
    }

    .form-control {
        color: var(--dark-color);
        border: 2px solid var(--border-color);
        border-radius: var(--radius-md);
        padding: 12px 16px;
        font-size: 0.95rem;
        transition: all 0.3s ease;
        background: white;
        font-family: 'Inter', sans-serif;
    }

    .form-control::placeholder {
        color: #6c757d;
        opacity: 0.8;
        font-style: italic;
    }

    .form-control:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 0.2rem rgba(38, 76, 126, 0.15);
        background: #fafbfc;
    }

    .form-control:hover:not(:focus) {
        border-color: #adb5bd;
    }

    /* Enhanced Card Design */
    .card {
        border: none;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
    }

    .card-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, #1a3a5c 100%);
        border-bottom: none;
        padding: 25px 30px;
        position: relative;
        overflow: hidden;
    }

    .card-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="0.5"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
        opacity: 0.3;
    }

    .card-header .row {
        position: relative;
        z-index: 1;
    }

    .card-title {
        font-weight: 700;
        color: white !important;
        font-size: 1.8rem;
        text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        margin: 0;
        font-family: 'Inter', sans-serif;
        letter-spacing: 0.5px;
    }

    .card-header img {
        filter: brightness(0%) invert(100%);
        max-width: 140px;
        height: auto;
    }

    .card-header .form-group {
        margin-bottom: 0;
    }

    .card-header .form-group label {
        color: rgba(255,255,255,0.9) !important;
        font-size: 0.8rem;
        margin-bottom: 5px;
    }

    .card-header .form-control {
        background: rgba(255,255,255,0.95);
        border: 2px solid rgba(255,255,255,0.3);
        color: var(--dark-color);
        font-family: 'JetBrains Mono', monospace;
        font-weight: 600;
        font-size: 1rem;
        text-align: center;
        letter-spacing: 1px;
    }

    .card-body {
        padding: 40px;
        background: white;
    }

    /* Enhanced Section Styling */
    .form-section {
        background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-lg);
        padding: 30px;
        margin-bottom: 30px;
        position: relative;
        box-shadow: var(--shadow-sm);
    }

    .form-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
        background: linear-gradient(to bottom, var(--primary-color), var(--accent-color));
        border-radius: 2px 0 0 2px;
    }

    .section-title {
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--primary-color);
        margin-bottom: 25px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        position: relative;
        padding-left: 15px;
    }

    /* Enhanced Checkbox Styling */
    .checkbox-column {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .custom-control {
        position: relative;
        padding-left: 2rem;
        margin-bottom: 8px;
    }

    .custom-control-input {
        position: absolute;
        left: 0;
        z-index: -1;
        width: 1.25rem;
        height: 1.25rem;
        opacity: 0;
    }

    .custom-control-label {
        position: relative;
        margin-bottom: 0;
        vertical-align: top;
        color: var(--dark-color) !important;
        font-weight: 500 !important;
        font-size: 0.95rem !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .custom-control-label::before {
        position: absolute;
        top: 0;
        left: -2rem;
        display: block;
        width: 1.25rem;
        height: 1.25rem;
        pointer-events: none;
        content: "";
        background-color: white;
        border: 2px solid var(--border-color);
        border-radius: var(--radius-sm);
        transition: all 0.3s ease;
        box-shadow: var(--shadow-sm);
    }

    .custom-control-label::after {
        position: absolute;
        top: 0;
        left: -2rem;
        display: block;
        width: 1.25rem;
        height: 1.25rem;
        content: "";
        background: no-repeat 50%/50% 50%;
        transition: all 0.3s ease;
    }

    .custom-control-input:checked ~ .custom-control-label::before {
        color: white;
        border-color: var(--primary-color);
        background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
        box-shadow: 0 2px 4px rgba(38, 76, 126, 0.3);
        transform: scale(1.05);
    }

    .custom-control-input:checked ~ .custom-control-label::after {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8' viewBox='0 0 8 8'%3e%3cpath fill='%23fff' d='m6.564.75-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3e%3c/svg%3e");
    }

    .custom-control-input:focus ~ .custom-control-label::before {
        box-shadow: 0 0 0 0.2rem rgba(38, 76, 126, 0.25);
    }

    .custom-control-input:disabled ~ .custom-control-label {
        color: #6c757d !important;
        opacity: 0.6;
    }

    .custom-control-input:disabled ~ .custom-control-label::before {
        background-color: #f8f9fa;
        border-color: #dee2e6;
    }

    /* Enhanced Table Styling */
    .table-enhanced {
        background: white;
        border-radius: var(--radius-lg);
        overflow: hidden;
        box-shadow: var(--shadow-md);
        border: none;
    }

    .table-enhanced th {
        background: linear-gradient(135deg, var(--primary-color) 0%, #1a3a5c 100%);
        color: white;
        font-weight: 600;
        padding: 18px 15px;
        text-align: center;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        font-size: 0.9rem;
        border: none;
    }

    .table-enhanced td {
        padding: 15px;
        vertical-align: middle;
        border: 1px solid #f1f3f4;
        background: white;
    }

    .table-enhanced tbody tr:hover {
        background: #f8f9fa;
        transform: scale(1.001);
        transition: all 0.2s ease;
    }

    /* Enhanced Approval Table */
    .approval-table-container {
        border-radius: var(--radius-lg);
        overflow: hidden;
        box-shadow: var(--shadow-lg);
        margin-top: 20px;
        background: white;
    }

    .approval-table-container table {
        width: 100%;
        border-collapse: collapse;
        margin: 0;
    }

    .approval-table-container th {
        background: linear-gradient(135deg, var(--primary-color) 0%, #1a3a5c 100%);
        color: white;
        font-weight: 700;
        padding: 20px 15px;
        text-align: center;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-size: 0.95rem;
        position: relative;
    }

    .approval-table-container th::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    }

    .approval-table-container td {
        background-color: #ffffff;
        color: var(--dark-color);
        padding: 25px 15px;
        vertical-align: middle;
        border: 1px solid #f1f3f4;
        text-align: center;
        transition: all 0.3s ease;
    }

    .approval-table-container tbody tr:hover td {
        background: #f8f9fa;
    }

    .signature-container {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        min-height: 120px;
        padding: 10px;
    }

    .signature-container img {
        max-width: 140px;
        height: auto;
        border: 2px solid var(--border-color);
        border-radius: var(--radius-md);
        margin-bottom: 10px;
        box-shadow: var(--shadow-sm);
        transition: all 0.3s ease;
    }

    .signature-container img:hover {
        transform: scale(1.05);
        box-shadow: var(--shadow-md);
    }

    .signature-container span {
        font-weight: 600;
        color: var(--dark-color);
        font-size: 0.95rem;
        text-align: center;
    }

    /* Enhanced Button Styling */
    .btn {
        font-weight: 600;
        padding: 12px 24px;
        border-radius: var(--radius-md);
        text-transform: uppercase;
        letter-spacing: 0.3px;
        transition: all 0.3s ease;
        border: none;
        position: relative;
        overflow: hidden;
    }

    .btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.5s;
    }

    .btn:hover::before {
        left: 100%;
    }

    .btn-primary {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--accent-color) 100%);
        color: white;
        box-shadow: var(--shadow-md);
    }

    .btn-primary:hover {
        background: linear-gradient(135deg, #1a3a5c 0%, #004499 100%);
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(38, 76, 126, 0.3);
    }

    .btn-secondary {
        background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%);
        color: white;
    }

    .btn-secondary:hover {
        background: linear-gradient(135deg, #5a6268 0%, #495057 100%);
        transform: translateY(-2px);
    }

    .btn-danger {
        background: linear-gradient(135deg, var(--danger-color) 0%, #c82333 100%);
        color: white;
    }

    .btn-danger:hover {
        background: linear-gradient(135deg, #c82333 0%, #bd2130 100%);
        transform: translateY(-2px);
    }

    /* Enhanced Modal Styling */
    .modal-content {
        border: none;
        border-radius: var(--radius-lg);
        box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        overflow: hidden;
    }

    .modal-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, #1a3a5c 100%);
        color: white;
        padding: 20px 30px;
        border-bottom: none;
    }

    .modal-title {
        font-weight: 700;
        font-size: 1.3rem;
        text-shadow: 0 1px 2px rgba(0,0,0,0.3);
    }

    .modal-body {
        padding: 30px;
        background: #fafbfc;
    }

    .modal-footer {
        background: white;
        padding: 20px 30px;
        border-top: 1px solid var(--border-color);
    }

    /* Enhanced Select Styling */
    select.form-control {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
        background-position: right 12px center;
        background-repeat: no-repeat;
        background-size: 16px 12px;
        padding-right: 40px;
        appearance: none;
    }

    /* Enhanced Textarea Styling */
    .form-control[type="textarea"],
    textarea.form-control {
        resize: vertical;
        min-height: 100px;
        font-family: 'Inter', sans-serif;
    }

    /* Enhanced Date Input */
    .form-control[type="date"] {
        font-family: 'JetBrains Mono', monospace;
    }

    /* Responsive Design Enhancements */
    @media (max-width: 768px) {
        .card-body {
            padding: 20px;
        }
        
        .form-section {
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .card-title {
            font-size: 1.4rem;
        }
        
        .checkbox-column {
            margin-bottom: 25px;
        }
        
        .approval-table-container {
            overflow-x: auto;
        }
        
        .signature-container {
            min-height: 100px;
            padding: 8px;
        }
        
        .signature-container img {
            max-width: 100px;
        }
    }

    /* Loading States */
    .btn.loading {
        position: relative;
        color: transparent;
    }

    .btn.loading::after {
        content: '';
        position: absolute;
        width: 16px;
        height: 16px;
        top: 50%;
        left: 50%;
        margin-left: -8px;
        margin-top: -8px;
        border: 2px solid transparent;
        border-top-color: currentColor;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Focus Indicators */
    .form-control:focus,
    .custom-control-input:focus ~ .custom-control-label::before,
    .btn:focus {
        outline: 2px solid var(--primary-color);
        outline-offset: 2px;
    }
</style>

<?php include INCLUDES_PATH . '/header.php'; ?>
<div class="wrapper">
    <?php include INCLUDES_PATH . '/sidebar.php'; ?>
    <div class="main-panel">
        <?php include INCLUDES_PATH . '/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <!-- Enhanced Header -->
                            <div class="card-header">
                                <div class="row rts-header align-items-center">
                                    <div class="col-lg-4 col-md-12 text-lg-left text-center">
                                        <img src="<?php echo BASE_URL; ?>/assets/img/logo_black.png" alt="Fujifilm Logo"
                                            class="img-fluid">
                                    </div>
                                    <div class="col-lg-4 col-md-12 text-center">
                                        <h4 class="card-title">Return / Transfer Slip</h4>
                                        <small style="color: rgba(255,255,255,0.8); font-size: 0.9rem;">Centralized RTV/RTS Management System</small>
                                    </div>
                                    <div class="col-lg-4 col-md-12 text-lg-right text-center">
                                        <div class="form-group">
                                            <label for="control_no">Control Number</label>
                                            <input type="text" id="control_no" name="control_no"
                                                value="<?= htmlspecialchars($control_no) ?>" class="form-control" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card-body">
                                <form id="rtsForm" method="POST" action="process_rts_form.php">
                                    <!-- Hidden Fields -->
                                    <input type="hidden" name="requestor_id" value="<?php echo $_SESSION['user_id']; ?>">
                                    <input type="hidden" name="requestor_name" value="<?php echo htmlspecialchars($_SESSION['username']); ?>">
                                    <input type="hidden" name="requestor_department" value="<?php echo htmlspecialchars($user_department); ?>">

                                    <!-- Material Classification Section -->
                                    <div class="form-section">
                                        <div class="section-title">
                                            <i class="fas fa-boxes" style="margin-right: 8px; color: var(--accent-color);"></i>
                                            Material Classification
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                    <label>Material Type</label>
                                                    <div class="checkbox-column">
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input"
                                                                id="rawMaterial" name="material_type[]" value="Raw Material">
                                                            <label class="custom-control-label" for="rawMaterial">Raw Material</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input"
                                                                id="packagingMaterial" name="material_type[]" value="Packaging Material">
                                                            <label class="custom-control-label" for="packagingMaterial">Packaging Material</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                    <label>Material Status</label>
                                                    <div class="checkbox-column">
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input material-status-checkbox"
                                                                id="good" name="material_status[]" value="Good">
                                                            <label class="custom-control-label" for="good">Good</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input material-status-checkbox"
                                                                id="materialDefect" name="material_status[]" value="Material Defect">
                                                            <label class="custom-control-label" for="materialDefect">Material Defect</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input material-status-checkbox"
                                                                id="humanError" name="material_status[]" value="Human Error">
                                                            <label class="custom-control-label" for="humanError">Human Error</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input material-status-checkbox"
                                                                id="endOfLife" name="material_status[]" value="EOL">
                                                            <label class="custom-control-label" for="endOfLife">End of Life (EOL)</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input material-status-checkbox"
                                                                id="othersNoGood" name="material_status[]" value="NG/Others">
                                                            <label class="custom-control-label" for="othersNoGood">NG/Others</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                    <label>Judgement Decision</label>
                                                    <div class="checkbox-column">
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input judgement-checkbox"
                                                                id="scrapdisposal" name="judgement[]" value="Scrap/Disposal" disabled>
                                                            <label class="custom-control-label" for="scrapdisposal">Scrap/Disposal</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input judgement-checkbox"
                                                                id="rtv" name="judgement[]" value="RTV" disabled>
                                                            <label class="custom-control-label" for="rtv">Return to Vendor (RTV)</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input judgement-checkbox"
                                                                id="hold" name="judgement[]" value="Hold" disabled>
                                                            <label class="custom-control-label" for="hold">Hold</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input judgement-checkbox"
                                                                id="transfertogood" name="judgement[]" value="Transfer to Good" disabled>
                                                            <label class="custom-control-label" for="transfertogood">Transfer to Good</label> 
                                                                                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- SAP Location Section -->
                                    <div class="form-section">
                                        <div class="section-title">
                                            <i class="fas fa-map-marker-alt" style="margin-right: 8px; color: var(--accent-color);"></i>
                                            SAP Location Management
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="table-responsive">
                                                    <table class="table table-enhanced">
                                                        <thead>
                                                            <tr>
                                                                <th style="width: 50%;">
                                                                    <i class="fas fa-arrow-right" style="margin-right: 8px;"></i>
                                                                    From Location
                                                                </th>
                                                                <th style="width: 50%;">
                                                                    <i class="fas fa-arrow-left" style="margin-right: 8px;"></i>
                                                                    To Location
                                                                </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <select class="form-control" name="sap_location[from]" required>
                                                                        <option value="" disabled selected>Select Source Location</option>
                                                                        <?php foreach ($sap_locations as $location): ?>
                                                                            <option value="<?php echo htmlspecialchars($location['LocationCode']); ?>">
                                                                                <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                            </option>
                                                                        <?php endforeach; ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select class="form-control" name="sap_location[to]" required>
                                                                        <option value="" disabled selected>Select Destination Location</option>
                                                                        <?php foreach ($sap_locations as $location): ?>
                                                                            <option value="<?php echo htmlspecialchars($location['LocationCode']); ?>">
                                                                                <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                            </option>
                                                                        <?php endforeach; ?>
                                                                    </select>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Additional Information Section -->
                                    <div class="form-section">
                                        <div class="section-title">
                                            <i class="fas fa-edit" style="margin-right: 8px; color: var(--accent-color);"></i>
                                            Additional Information
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group">
                                                    <label for="details">
                                                        <i class="fas fa-info-circle" style="margin-right: 5px;"></i>
                                                        Details (Others)
                                                    </label>
                                                    <textarea class="form-control" id="details" name="details" rows="4"
                                                        placeholder="Enter additional details, special instructions, or notes..." disabled></textarea>
                                                    <small class="form-text text-muted">This field will be enabled based on material status selection</small>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-md-12">
                                                <div class="form-group">
                                                    <label for="remarks">
                                                        <i class="fas fa-comment" style="margin-right: 5px;"></i>
                                                        Remarks
                                                    </label>
                                                    <textarea name="remark" id="remark" class="form-control" rows="4"
                                                        placeholder="Enter any remarks, observations, or comments..."></textarea>
                                                    <small class="form-text text-muted">Optional field for additional comments</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Request Details Section -->
                                    <div class="form-section">
                                        <div class="section-title">
                                            <i class="fas fa-calendar-alt" style="margin-right: 8px; color: var(--accent-color);"></i>
                                            Request Details
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                    <label for="return_date">
                                                        <i class="fas fa-calendar" style="margin-right: 5px;"></i>
                                                        Return Date
                                                    </label>
                                                    <input type="date" class="form-control" id="return_date" name="return_date" required>
                                                    <small class="form-text text-muted">Expected return or transfer date</small>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                    <label for="department">
                                                        <i class="fas fa-building" style="margin-right: 5px;"></i>
                                                        Department
                                                    </label>
                                                    <select class="form-control" id="department" name="department" required>
                                                        <option value="<?php echo htmlspecialchars($user_department); ?>" selected>
                                                            <?php echo htmlspecialchars($user_department); ?> (Current)
                                                        </option>
                                                        <?php
                                                        foreach ($departments as $dept) {
                                                            if ($dept !== $user_department) {
                                                                echo "<option value='" . htmlspecialchars($dept) . "'>" . htmlspecialchars($dept) . "</option>";
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                    <label for="model">
                                                        <i class="fas fa-tag" style="margin-right: 5px;"></i>
                                                        Model
                                                    </label>
                                                    <input type="text" class="form-control" id="model" name="model"
                                                        placeholder="Enter product model or identifier..." required>
                                                    <small class="form-text text-muted">Product model or part identifier</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Enhanced Approval Matrix -->
                                    <div class="form-section">
                                        <div class="section-title">
                                            <i class="fas fa-clipboard-check" style="margin-right: 8px; color: var(--accent-color);"></i>
                                            Approval Workflow
                                        </div>
                                        <div class="approval-table-container">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>
                                                            <i class="fas fa-user-edit" style="margin-right: 5px;"></i>
                                                            Prepared By
                                                        </th>
                                                        <th>
                                                            <i class="fas fa-user-check" style="margin-right: 5px;"></i>
                                                            Checked By
                                                        </th>
                                                        <th>
                                                            <i class="fas fa-user-shield" style="margin-right: 5px;"></i>
                                                            Approved By
                                                        </th>
                                                        <th>
                                                            <i class="fas fa-user-tie" style="margin-right: 5px;"></i>
                                                            Noted By
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div class="signature-container">
                                                                <?php if (!empty($signature_base64)): ?>
                                                                    <img src="<?php echo $signature_base64; ?>" alt="Digital Signature">
                                                                <?php else: ?>
                                                                    <div style="width: 140px; height: 60px; border: 2px dashed var(--border-color); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; color: #6c757d; font-size: 0.8rem;">
                                                                        <i class="fas fa-signature" style="margin-right: 5px;"></i>
                                                                        No Signature
                                                                    </div>
                                                                <?php endif; ?>
                                                                <span><?php echo htmlspecialchars($user_name); ?></span>
                                                                <small style="color: #6c757d; font-size: 0.8rem;">Requestor</small>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="signature-container">
                                                                <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Approval">
                                                                <span style="color: #6c757d;">Pending</span>
                                                                <small style="color: #6c757d; font-size: 0.8rem;">Quality Control</small>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="signature-container">
                                                                <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Approval">
                                                                <span style="color: #6c757d;">Pending</span>
                                                                <small style="color: #6c757d; font-size: 0.8rem;">Management</small>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="signature-container">
                                                                <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Approval">
                                                                <span style="color: #6c757d;">Pending</span>
                                                                <small style="color: #6c757d; font-size: 0.8rem;">Final Review</small>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <!-- Enhanced Material Details Section -->
                                    <div class="form-section">
                                        <div class="row align-items-center mb-3">
                                            <div class="col">
                                                <div class="section-title mb-0">
                                                    <i class="fas fa-list-alt" style="margin-right: 8px; color: var(--accent-color);"></i>
                                                    Material Details Management
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#materialDetailsModal">
                                                    <i class="fas fa-plus-circle" style="margin-right: 5px;"></i>
                                                    Manage Material Details
                                                </button>
                                            </div>
                                        </div>
                                        <div class="alert alert-info" style="border-left: 4px solid var(--accent-color);">
                                            <i class="fas fa-info-circle" style="margin-right: 8px;"></i>
                                            <strong>Note:</strong> Click "Manage Material Details" to add, edit, or view material information. 
                                            This is required to complete the RTS form submission.
                                        </div>
                                    </div>

                                    <!-- Enhanced Material Details Modal -->
                                    <div class="modal fade" id="materialDetailsModal" tabindex="-1" role="dialog" aria-labelledby="materialDetailsModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-xl" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="materialDetailsModalLabel">
                                                        <i class="fas fa-table" style="margin-right: 8px;"></i>
                                                        Material Details Management
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: white;">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="alert alert-warning mb-3">
                                                        <i class="fas fa-exclamation-triangle" style="margin-right: 8px;"></i>
                                                        <strong>Instructions:</strong> Fill in the material details for each item. 
                                                        Use the "Add Rows" function to add more entries as needed.
                                                    </div>
                                                    <div class="table-responsive">
                                                        <table id="material_details_table" class="table table-enhanced">
                                                            <thead>
                                                                <tr>
                                                                    <th style="width: 4%;">No.</th>
                                                                    <th style="width: 8%;">Ref. No</th>
                                                                    <th style="width: 10%;">SAP Mat Doc Ref</th>
                                                                    <th style="width: 8%;">Invoice No</th>
                                                                    <th style="width: 12%;">Supplier</th>
                                                                    <th style="width: 10%;">Part Number</th>
                                                                    <th style="width: 12%;">Part Name</th>
                                                                    <th style="width: 15%;">Description</th>
                                                                    <th style="width: 7%;">Qty Returned</th>
                                                                    <th style="width: 7%;">Qty Received</th>
                                                                    <th style="width: 8%;">Amount</th>
                                                                    <th style="width: 8%;">Due Date</th>
                                                                    <th style="width: 6%;">Actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <!-- Dynamic rows will be added here -->
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <div class="row w-100 align-items-center">
                                                        <div class="col-md-6">
                                                            <div class="input-group">
                                                                <div class="input-group-prepend">
                                                                    <span class="input-group-text">
                                                                        <i class="fas fa-plus"></i>
                                                                    </span>
                                                                </div>
                                                                <input type="number" class="form-control" id="numRowsInput" 
                                                                       placeholder="Number of rows to add" min="1" max="50" value="5">
                                                                <div class="input-group-append">
                                                                    <button type="button" class="btn btn-secondary" id="addRowsBtn">
                                                                        <i class="fas fa-plus-circle"></i> Add Rows
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6 text-right">
                                                            <button type="button" class="btn btn-primary" data-dismiss="modal">
                                                                <i class="fas fa-check"></i> Done
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Enhanced Submit Section -->
                                    <div class="form-section text-center">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="d-flex justify-content-center align-items-center" style="gap: 20px;">
                                                    <button type="button" class="btn btn-secondary" onclick="window.location.reload();">
                                                        <i class="fas fa-undo" style="margin-right: 8px;"></i>
                                                        Reset Form
                                                    </button>
                                                    <button type="submit" class="btn btn-primary" style="padding: 15px 40px; font-size: 1.1rem;">
                                                        <i class="fas fa-paper-plane" style="margin-right: 8px;"></i>
                                                        Submit RTS Form
                                                    </button>
                                                </div>
                                                <small class="form-text text-muted mt-3">
                                                    <i class="fas fa-info-circle"></i>
                                                    Please review all information before submitting. Once submitted, the form will enter the approval workflow.
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include INCLUDES_PATH . '/footer.php'; ?>
    </div>
</div>

<script>
    // Enhanced Material Details Management
    let totalRows = 0;

    function generateTableRows(numberOfRows) {
        let rowsHtml = '';
        const startingIndex = $('#material_details_table tbody tr').length + 1;
        
        for (let i = 0; i < numberOfRows; i++) {
            const rowNumber = startingIndex + i;
            rowsHtml += `
                <tr data-row-number="${rowNumber}" class="material-row">
                    <td class="text-center font-weight-bold">${rowNumber}</td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[ref_no][]" placeholder="Reference number"></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[sap_doc][]" placeholder="SAP document"></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[invoice_no][]" placeholder="Invoice number"></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[supplier][]" placeholder="Supplier name"></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_number][]" placeholder="Part number"></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_name][]" placeholder="Part name"></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[description][]" placeholder="Description"></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_returned][]" placeholder="0" min="0"></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_received][]" placeholder="0" min="0"></td>
                    <td><input type="number" class="form-control form-control-sm amount-input" name="material_details[amount][]" placeholder="0.00" min="0" step="0.01"></td>
                    <td><input type="date" class="form-control form-control-sm" name="material_details[due_date][]"></td>
                    <td class="text-center">
                        <button type="button" class="btn btn-danger btn-sm remove-row-btn" title="Remove this row">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>`;
        }
        totalRows += numberOfRows;
        return rowsHtml;
    }

    $(document).ready(function() {
        // Initialize with 5 rows when modal opens
        $('#materialDetailsModal').one('shown.bs.modal', function() {
            $('#material_details_table tbody').append(generateTableRows(5));
        });

        // Add rows functionality
        $('#addRowsBtn').on('click', function() {
            const numRows = parseInt($('#numRowsInput').val());
            if (numRows > 0 && numRows <= 50) {
                $('#material_details_table tbody').append(generateTableRows(numRows));                $('#numRowsInput').val(''); // Clear input
                
                // Show success message
                Swal.fire({
                    icon: 'success',
                    title: 'Rows Added!',
                    text: `Successfully added ${numRows} rows to the table.`,
                    timer: 1500,
                    showConfirmButton: false
                });
            } else {
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Input',
                    text: 'Please enter a number between 1 and 50.',
                    confirmButtonText: 'OK'
                });
            }
        });

        // Remove row functionality
        $(document).on('click', '.remove-row-btn', function() {
            const $row = $(this).closest('tr');
            
            Swal.fire({
                title: 'Remove Row?',
                text: 'Are you sure you want to remove this material entry?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, remove it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $row.remove();
                    
                    // Re-number all rows
                    $('#material_details_table tbody tr').each(function(index) {
                        $(this).find('td:first').text(index + 1);
                        $(this).attr('data-row-number', index + 1);
                    });
                    
                    Swal.fire({
                        icon: 'success',
                        title: 'Removed!',
                        text: 'Material entry has been removed.',
                        timer: 1000,
                        showConfirmButton: false
                    });
                }
            });
        });

        // Enhanced Material Status Logic
        $('.material-status-checkbox, .judgement-checkbox').change(function() {
            const isChecked = $(this).is(':checked');
            const groupClass = $(this).hasClass('material-status-checkbox') ? '.material-status-checkbox' : '.judgement-checkbox';
            
            if (isChecked) {
                $(groupClass).not(this).prop('checked', false);
            }

            if ($(this).hasClass('material-status-checkbox')) {
                const checkedStatus = $(this).val();
                const $allStatusCheckboxes = $('.material-status-checkbox');
                const $allJudgementCheckboxes = $('.judgement-checkbox');
                const $detailsField = $('#details');

                // Reset judgement checkboxes
                $allJudgementCheckboxes.prop('checked', false).prop('disabled', true);

                // Enable/disable details field
                $detailsField.prop('disabled', !isChecked);
                if (!isChecked) {
                    $detailsField.val('');
                }

                if (isChecked) {
                    // Disable other status checkboxes
                    $allStatusCheckboxes.not(this).prop('disabled', true);

                    // Enable appropriate judgement options
                    if (checkedStatus === 'NG/Others') {
                        $('#scrapdisposal, #hold').prop('disabled', false);
                    } else if (checkedStatus === 'Good') {
                        $('#transfertogood').prop('disabled', false);
                    } else {
                        $('#scrapdisposal, #hold').prop('disabled', false);
                    }
                } else {
                    $allStatusCheckboxes.prop('disabled', false);
                }
            }
        });

        // Enhanced Form Submission with Better Validation
        $('#rtsForm').on('submit', function(e) {
            e.preventDefault();

            let isValid = true;
            let errorMessages = [];

            // Material Type validation
            if ($('input[name="material_type[]"]:checked').length === 0) {
                isValid = false;
                errorMessages.push('• Please select at least one Material Type.');
            }

            // Material Status validation
            if ($('input[name="material_status[]"]:checked').length === 0) {
                isValid = false;
                errorMessages.push('• Please select a Material Status.');
            }

            // Judgement validation
            const selectedStatus = $('input[name="material_status[]"]:checked').val();
            const hasJudgement = $('input[name="judgement[]"]:checked').length > 0;

            if (selectedStatus === 'NG/Others' && !hasJudgement) {
                isValid = false;
                errorMessages.push('• Please select a judgement (Scrap/Disposal or Hold) for NG/Others.');
            } else if (selectedStatus !== 'Good' && selectedStatus !== 'NG/Others' && selectedStatus !== undefined && !hasJudgement) {
                isValid = false;
                errorMessages.push('• Please select a judgement for the selected material status.');
            }

            // SAP Location validation
            const sapFromLocation = $('select[name="sap_location[from]"]').val();
            const sapToLocation = $('select[name="sap_location[to]"]').val();
            if (!sapFromLocation || !sapToLocation) {
                isValid = false;
                errorMessages.push('• Please select both "From" and "To" SAP Location codes.');
            }

            // Basic field validations
            if ($('#return_date').val().trim() === '') {
                isValid = false;
                errorMessages.push('• Please select a Return Date.');
            }

            if ($('#department').val().trim() === '') {
                isValid = false;
                errorMessages.push('• Please select a Department.');
            }

            if ($('#model').val().trim() === '') {
                isValid = false;
                errorMessages.push('• Please enter a Model.');
            }

            // Material details validation
            let hasMaterialDetails = false;
            let materialRowCount = 0;
            $('#material_details_table tbody tr').each(function() {
                const $rowInputs = $(this).find('input');
                let rowIsFilled = false;
                
                $rowInputs.each(function() {
                    if ($(this).val().trim() !== '' && !$(this).prop('disabled')) {
                        rowIsFilled = true;
                        return false;
                    }
                });
                
                if (rowIsFilled) {
                    hasMaterialDetails = true;
                    materialRowCount++;
                }
            });

            if (!hasMaterialDetails) {
                isValid = false;
                errorMessages.push('• Please enter details for at least one material item.');
            }

            // Show validation errors
            if (!isValid) {
                Swal.fire({
                    icon: 'error',
                    title: 'Validation Errors',
                    html: `<div style="text-align: left;">${errorMessages.join('<br>')}</div>`,
                    confirmButtonText: 'Fix Issues',
                    customClass: {
                        htmlContainer: 'text-left'
                    }
                });
                return;
            }

            // Show confirmation dialog
            Swal.fire({
                title: 'Submit RTS Form?',
                html: `
                    <div style="text-align: left; margin: 10px 0;">
                        <p><strong>Please confirm the following details:</strong></p>
                        <ul style="list-style-type: none; padding-left: 0;">
                            <li>📋 <strong>Material Items:</strong> ${materialRowCount} entries</li>
                            <li>📅 <strong>Return Date:</strong> ${$('#return_date').val()}</li>
                            <li>🏢 <strong>Department:</strong> ${$('#department option:selected').text()}</li>
                            <li>🏷️ <strong>Model:</strong> ${$('#model').val()}</li>
                        </ul>
                        <p style="color: #666; font-size: 0.9rem; margin-top: 15px;">
                            <i class="fas fa-info-circle"></i> Once submitted, this form will enter the approval workflow.
                        </p>
                    </div>
                `,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#264c7e',
                cancelButtonColor: '#6c757d',
                confirmButtonText: '<i class="fas fa-paper-plane"></i> Yes, Submit Form',
                cancelButtonText: '<i class="fas fa-times"></i> Cancel',
                customClass: {
                    confirmButton: 'btn btn-primary',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show loading state
                    Swal.fire({
                        title: 'Submitting Form...',
                        html: `
                            <div class="text-center">
                                <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                                    <span class="sr-only">Loading...</span>
                                </div>
                                <p class="mt-3">Please wait while we process your request...</p>
                            </div>
                        `,
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        customClass: {
                            htmlContainer: 'text-center'
                        }
                    });

                    // Submit form via AJAX
                    const form = $(this);
                    $.ajax({
                        url: form.attr('action'),
                        type: form.attr('method'),
                        data: form.serialize(),
                        dataType: 'json',
                        success: function(response) {
                            Swal.close();
                            
                            if (response.status === 'success') {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Form Submitted Successfully!',
                                    html: `
                                        <div class="text-center">
                                            <div style="background: #e8f5e8; border: 2px solid #4caf50; border-radius: 8px; padding: 20px; margin: 15px 0;">
                                                <h5 style="color: #2e7d32; margin-bottom: 10px;">
                                                    <i class="fas fa-check-circle"></i> RTS Control Number
                                                </h5>
                                                <h3 style="color: #1b5e20; font-family: 'Courier New', monospace; font-weight: bold;">
                                                    ${response.control_no}
                                                </h3>
                                            </div>
                                            <p style="color: #666; margin-top: 15px;">
                                                Your request has been sent for approval. You can track its progress in the Pending Requests section.
                                            </p>
                                        </div>
                                    `,
                                    confirmButtonText: '<i class="fas fa-arrow-right"></i> Go to Pending Requests',
                                    confirmButtonColor: '#264c7e'
                                }).then(() => {
                                    window.location.href = `<?php echo BASE_URL; ?>/pages/requests/pending_requests.php`;
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Submission Failed',
                                    text: response.message || 'An error occurred while submitting the form.',
                                    confirmButtonText: 'Try Again',
                                    confirmButtonColor: '#dc3545'
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            Swal.close();
                            
                            let errorMessage = 'An unexpected error occurred. Please try again.';
                            if (xhr.responseText) {
                                try {
                                    const response = JSON.parse(xhr.responseText);
                                    errorMessage = response.message || errorMessage;
                                } catch (e) {
                                    console.error('Non-JSON response:', xhr.responseText);
                                }
                            }

                            Swal.fire({
                                icon: 'error',
                                title: 'Submission Error',
                                text: errorMessage,
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#dc3545'
                            });
                        }
                    });
                }
            });
        });

        // Auto-save functionality (optional)
        let autoSaveTimeout;
        $('input, select, textarea').on('input change', function() {
            clearTimeout(autoSaveTimeout);
            autoSaveTimeout = setTimeout(function() {
                // You can implement auto-save to localStorage here
                console.log('Auto-saving form data...');
            }, 2000);
        });

        // Form reset confirmation
        $('button[onclick*="reload"]').on('click', function(e) {
            e.preventDefault();
            
            Swal.fire({
                title: 'Reset Form?',
                text: 'This will clear all entered data. Are you sure?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, reset form',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.reload();
                }
            });
        });

        // Enhanced tooltips for form fields
        $('[title]').tooltip({
            placement: 'top',
            trigger: 'hover focus'
        });

        // Form field animations
        $('.form-control').on('focus', function() {
            $(this).closest('.form-group').addClass('focused');
        }).on('blur', function() {
            $(this).closest('.form-group').removeClass('focused');
        });
    });
</script>