<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/includes/functions.php';
require_once APP_ROOT . '/assets/db/connection.php';

// Check if this is a valid resubmission request
$resubmit_id = isset($_GET['id']) ? intval($_GET['id']) : null;

if (!$resubmit_id) {
    $_SESSION['error_message'] = "Invalid resubmission request.";
    header('Location: ' . BASE_URL . '/pages/scrap/disapproved_requests.php');
    exit();
}

$form_data = null;
$form_items = array();
$previous_disapproval_info = null;

// Fetch the disapproved form data
try {
    $db = new Connection();
    $conn = $db->link;
    
    // Fetch the disapproved form data
    $sql = "SELECT * FROM rts_forms WHERE id = ? AND requestor_id = ? AND overall_status = 'Disapproved'";
    $params = array($resubmit_id, $_SESSION['user_id']);
    $stmt = sqlsrv_query($conn, $sql, $params);
    
    if ($stmt && $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $form_data = $row;
        
        // Store disapproval info
        $previous_disapproval_info = array(
            'reason' => $row['disapproval_reason'] ?? 'Not specified',
            'by_role' => $row['disapproved_by_role'] ?? 'Not specified',
            'date' => isset($row['disapproved_date']) ? $row['disapproved_date'] : (isset($row['created_at']) ? $row['created_at'] : date('Y-m-d H:i:s'))
        );
        
        // Convert dates if they are DateTime objects
        if ($form_data['return_date'] instanceof DateTime) {
            $form_data['return_date'] = $form_data['return_date']->format('Y-m-d');
        }
        
        // Parse SAP location codes
        if (strpos($form_data['sap_loc_code'], ' to ') !== false) {
            list($form_data['sap_location_from'], $form_data['sap_location_to']) = explode(' to ', $form_data['sap_loc_code']);
        } else {
            $form_data['sap_location_from'] = $form_data['sap_loc_code'];
            $form_data['sap_location_to'] = '';
        }
        
        // Parse comma-separated values back to arrays for checkboxes
        $form_data['material_type_array'] = !empty($form_data['material_type']) ? explode(', ', $form_data['material_type']) : [];
        $form_data['material_status_array'] = !empty($form_data['material_status']) ? explode(', ', $form_data['material_status']) : [];
        $form_data['judgement_array'] = !empty($form_data['judgement']) ? explode(', ', $form_data['judgement']) : [];
        
        // Fetch the items/materials for this form
        $items_sql = "SELECT * FROM rts_materials WHERE rts_form_id = ?";
        $items_stmt = sqlsrv_query($conn, $items_sql, array($resubmit_id));
        
        while ($item = sqlsrv_fetch_array($items_stmt, SQLSRV_FETCH_ASSOC)) {
            // Convert dates if needed
            if ($item['due_date'] instanceof DateTime) {
                $item['due_date'] = $item['due_date']->format('Y-m-d');
            }
            
            $form_items[] = $item;
        }
    } else {
        // Invalid resubmit request
        $_SESSION['error_message'] = "Form not found or not eligible for resubmission.";
        header('Location: ' . BASE_URL . '/pages/scrap/disapproved_requests.php');
        exit();
    }
    
    $db->close();
} catch (Exception $e) {
    error_log("Error fetching resubmit data: " . $e->getMessage());
    $_SESSION['error_message'] = "Error loading form data.";
    header('Location: ' . BASE_URL . '/pages/scrap/disapproved_requests.php');
    exit();
}

// Call the main initialization function
$pageData = initializeScrapRTSPageData($_SESSION['user_id'] ?? null);

// Handle redirection based on the function's return value
if (!$pageData['success']) {
    if (isset($pageData['redirect'])) {
        header('Location: ' . $pageData['redirect']);
    }
    $showErrorAlert = true;
    $errorMessage = $pageData['message'];
} else {
    // Extract the data for use in the HTML
    $user_name = $pageData['userData']['requestor_name'];
    $user_department = $pageData['userData']['department'];
    $user_role = $pageData['userData']['role'];
    $signature_base64 = $pageData['userData']['signature_base64'];
    $departments = $pageData['departments'];
    $sap_locations = $pageData['sap_locations'];
    $control_no = $form_data['control_no']; // Keep original control number
}
?>

<style>
.form-group label,
.custom-control-label {
    color: #000000 !important;
}

/* Include all your existing styles */
.font-weight-bold {
    color: #000000 !important;
}
.form-group label {
    font-weight: bold;
}
.form-control {
    color: #000000;
    border: 1px solid #ced4da;
    border-radius: 4px;
}
.form-control::placeholder {
    color: #000000;
    opacity: 0.7;
}
.checkbox-column {
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.custom-control-input {
    margin-right: 8px;
}
.custom-control-label {
    font-size: 0.95rem;
}
.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
.modal-content {
    border-radius: 8px;
}
.approval-table-container {
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-top: 15px;
}
.approval-table-container table {
    width: 100%;
    border-collapse: collapse;
}
.approval-table-container th {
    background-color: #f8f9fa;
    color: #000000;
    font-weight: 700;
    padding: 10px;
    text-align: center;
}
.approval-table-container td {
    background-color: #ffffff;
    color: #000000;
    padding: 15px;
    vertical-align: middle;
    border: 1px solid #dee2e6;
    text-align: center;
}
.signature-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
.signature-container img {
    max-width: 100%;
    height: auto;
    border-radius: 5px;
    margin-bottom: 5px;
}
.signature-container span {
    font-weight: 400;
    color: #000000;
}
.card-header {
    background-color: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
}
.card-title {
    font-weight: bold;
    color: #000000;
}
.btn-primary {
    background-color: #007bff;
    border: none;
}
.btn-primary:hover {
    background-color: #0056b3;
}

/* Additional styles for resubmission */
.resubmit-alert {
    background-color: #fff3cd;
    border: 1px solid #ffeeba;
    color: #856404;
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 20px;
}
.resubmit-alert h5 {
    margin-bottom: 10px;
    font-weight: bold;
}
.resubmit-badge {
    background-color: #ffc107;
    color: #212529;
    padding: 5px 10px;
    border-radius: 4px;
    font-size: 14px;
    font-weight: bold;
}
</style>

<?php include INCLUDES_PATH . '/header.php'; ?>
<div class="wrapper">
    <?php include INCLUDES_PATH . '/sidebar.php'; ?>
    <div class="main-panel">
        <?php include INCLUDES_PATH . '/navbar.php'; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="row rts-header align-items-center">
                                    <div class="col-lg-4 col-md-12 text-lg-left text-center">
                                        <img src="<?php echo BASE_URL; ?>/assets/img/logo_black.png" alt="Logo"
                                            class="img-fluid" style="max-width: 150px;">
                                    </div>
                                    <div class="col-lg-4 col-md-12 text-center">
                                        <h4 class="card-title">Return / Transfer Slip</h4>
                                        <span class="resubmit-badge">RESUBMISSION</span>
                                    </div>
                                    <div class="col-lg-4 col-md-12 text-lg-right text-center">
                                        <div class="form-group">
                                            <label for="control_no">Control No</label>
                                            <input type="text" id="control_no" name="control_no"
                                                value="<?= htmlspecialchars($control_no) ?>" class="form-control" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <!-- Disapproval Information Alert -->
                                <div class="resubmit-alert">
                                    <h5><i class="fa fa-exclamation-triangle"></i> Previous Disapproval Information</h5>
                                    <p><strong>Disapproved By:</strong> <?php echo ucfirst(htmlspecialchars($previous_disapproval_info['by_role'])); ?></p>
                                    <p><strong>Reason:</strong> <?php echo htmlspecialchars($previous_disapproval_info['reason']); ?></p>
                                    <p><strong>Date:</strong> <?php 
                                        if ($previous_disapproval_info['date'] instanceof DateTime) {
                                            echo $previous_disapproval_info['date']->format('Y-m-d H:i');
                                        } else {
                                            echo date('Y-m-d H:i', strtotime($previous_disapproval_info['date']));
                                        }
                                    ?></p>
                                </div>
                                
                                <form id="rtsForm" method="POST" action="process_rts_form.php">
                                    <input type="hidden" name="is_resubmit" value="1">
                                    <input type="hidden" name="original_form_id" value="<?php echo $resubmit_id; ?>">
                                    <input type="hidden" name="requestor_id" value="<?php echo $_SESSION['user_id']; ?>">
                                    <input type="hidden" name="requestor_name" value="<?php echo htmlspecialchars($_SESSION['username']); ?>">
                                    <input type="hidden" name="requestor_department" value="<?php echo htmlspecialchars($user_department); ?>">
                                    
                                    <div class="row">
                                        <div class="col-lg-4 col-md-12 checkbox-column">
                                            <div class="form-group">
                                                <label>Material Type</label>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="rawMaterial" name="material_type[]"
                                                        value="Raw Material" <?php echo in_array('Raw Material', $form_data['material_type_array']) ? 'checked' : ''; ?>>
                                                    <label class="custom-control-label" for="rawMaterial">Raw Material</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="packagingMaterial" name="material_type[]"
                                                        value="Packaging Material" <?php echo in_array('Packaging Material', $form_data['material_type_array']) ? 'checked' : ''; ?>>
                                                    <label class="custom-control-label" for="packagingMaterial">Packaging Material</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 checkbox-column">
                                            <div class="form-group">
                                                <label>Material Status</label>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="good" name="material_status[]" value="Good" <?php echo in_array('Good', $form_data['material_status_array']) ? 'checked' : ''; ?>>
                                                    <label class="custom-control-label" for="good">Good</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="materialDefect" name="material_status[]"
                                                        value="Material Defect" <?php echo in_array('Material Defect', $form_data['material_status_array']) ? 'checked' : ''; ?>>
                                                    <label class="custom-control-label" for="materialDefect">Material Defect</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="humanError" name="material_status[]"
                                                        value="Human Error" <?php echo in_array('Human Error', $form_data['material_status_array']) ? 'checked' : ''; ?>>
                                                    <label class="custom-control-label" for="humanError">Human Error</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="endOfLife" name="material_status[]" value="EOL" <?php echo in_array('EOL', $form_data['material_status_array']) ? 'checked' : ''; ?>>
                                                    <label class="custom-control-label" for="endOfLife">EOL</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input material-status-checkbox"
                                                        id="othersNoGood" name="material_status[]"
                                                        value="NG/Others" <?php echo in_array('NG/Others', $form_data['material_status_array']) ? 'checked' : ''; ?>>
                                                    <label class="custom-control-label" for="othersNoGood">NG/Others</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 checkbox-column">
                                            <div class="form-group">
                                                <label>Judgement</label>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox"
                                                        id="scrapdisposal" name="judgement[]" value="Scrap/Disposal"
                                                        <?php echo in_array('Scrap/Disposal', $form_data['judgement_array']) ? 'checked' : ''; ?>
                                                        <?php echo !in_array('Scrap/Disposal', $form_data['judgement_array']) ? 'disabled' : ''; ?>>
                                                    <label class="custom-control-label" for="scrapdisposal">Scrap/Disposal</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox" id="rtv"
                                                        name="judgement[]" value="RTV" 
                                                        <?php echo in_array('RTV', $form_data['judgement_array']) ? 'checked' : ''; ?>
                                                        <?php echo !in_array('RTV', $form_data['judgement_array']) ? 'disabled' : ''; ?>>
                                                    <label class="custom-control-label" for="rtv">RTV</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox" id="hold"
                                                        name="judgement[]" value="Hold" 
                                                        <?php echo in_array('Hold', $form_data['judgement_array']) ? 'checked' : ''; ?>
                                                        <?php echo !in_array('Hold', $form_data['judgement_array']) ? 'disabled' : ''; ?>>
                                                    <label class="custom-control-label" for="hold">Hold</label>
                                                </div>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox"
                                                        class="custom-control-input judgement-checkbox"
                                                        id="transfertogood" name="judgement[]"
                                                        value="Transfer to Good" 
                                                        <?php echo in_array('Transfer to Good', $form_data['judgement_array']) ? 'checked' : ''; ?>
                                                        <?php echo !in_array('Transfer to Good', $form_data['judgement_array']) ? 'disabled' : ''; ?>>
                                                    <label class="custom-control-label" for="transfertogood">Transfer to Good</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>SAP Location Code</label>
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>From</th>
                                                            <th>To</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <select class="form-control" name="sap_location[from]">
                                                                    <option value="" disabled>Select From Location</option>
                                                                    <?php foreach ($sap_locations as $location): ?>
                                                                        <option value="<?php echo htmlspecialchars($location['LocationCode']); ?>"
                                                                            <?php echo ($form_data['sap_location_from'] == $location['LocationCode']) ? 'selected' : ''; ?>>
                                                                            <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                        </option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </td>
                                                            <td>
                                                                <select class="form-control" name="sap_location[to]">
                                                                    <option value="" disabled>Select To Location</option>
                                                                    <?php foreach ($sap_locations as $location): ?>
                                                                        <option value="<?php echo htmlspecialchars($location['LocationCode']); ?>"
                                                                            <?php echo ($form_data['sap_location_to'] == $location['LocationCode']) ? 'selected' : ''; ?>>
                                                                            <?php echo htmlspecialchars($location['LocationCode'] . ' - ' . $location['LocationDescription'] . ' (' . $location['Department'] . ')'); ?>
                                                                        </option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                <label for="details">Details (Others)</label>
                                                <textarea class="form-control" id="details" name="details" rows="3"
                                                    placeholder="Enter additional details" <?php echo empty($form_data['details']) ? 'disabled' : ''; ?>><?php echo htmlspecialchars($form_data['details'] ?? ''); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div class="form-group">
                                                <label for="remarks">Remarks</label>
                                                <textarea name="remark" id="remark" class="form-control"
                                                    placeholder="Enter remarks"><?php echo htmlspecialchars($form_data['remark'] ?? ''); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-lg-12 col-md-12">
                                            <div class="form-group">
                                                <label>Approval Details</label>
                                                <div class="approval-table-container">
                                                    <table class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th style="text-align: center;">Prepared By</th>
                                                                <th style="text-align: center;">Checked By</th>
                                                                <th style="text-align: center;">Approved By</th>
                                                                <th style="text-align: center;">Noted By</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <?php if (!empty($signature_base64)): ?>
                                                                            <img src="<?php echo $signature_base64; ?>" alt="E-Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                        <?php endif; ?>
                                                                        <span><?php echo $user_name; ?></span>
                                                                    </div>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                    </div>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                    </div>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <div class="signature-container">
                                                                        <img src="<?php echo BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" alt="Pending Signature" style="max-width: 150px; border: 1px solid #ced4da; border-radius: 5px;">
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <label for="return_date">Return Date</label>
                                                <input type="date" class="form-control" id="return_date"
                                                    name="return_date" value="<?php echo htmlspecialchars($form_data['return_date'] ?? ''); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <label for="department">Department</label>
                                                <select class="form-control" id="department" name="department">
                                                    <option value="<?php echo htmlspecialchars($user_department); ?>"
                                                        <?php echo ($form_data['department'] == $user_department) ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($user_department); ?> (Current)
                                                    </option>
                                                    <?php
                                                    foreach ($departments as $dept) {
                                                        if ($dept !== $user_department) {
                                                            $selected = ($form_data['department'] == $dept) ? 'selected' : '';
                                                            echo "<option value='" . htmlspecialchars($dept) . "' $selected>" . htmlspecialchars($dept) . "</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12">
                                            <div class="form-group">
                                                <label for="model">Model</label>
                                                <input type="text" class="form-control" id="model" name="model"
                                                    placeholder="Enter Model" value="<?php echo htmlspecialchars($form_data['model'] ?? ''); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-12 d-flex justify-content-between align-items-center">
                                            <label class="font-weight-bold">Material Details</label>
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                                data-target="#materialDetailsModal">Add/View Details</button>
                                        </div>
                                    </div>
                                    <div class="modal fade" id="materialDetailsModal" tabindex="-1" role="dialog"
                                        aria-labelledby="materialDetailsModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-xl" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="materialDetailsModalLabel">Material Details</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="approval-table-container">
                                                        <table id="material_details_table"
                                                            class="table table-bordered table-striped">
                                                            <thead>
                                                                <tr>
                                                                    <th>No.</th>
                                                                    <th>Ref. No</th>
                                                                    <th>SAP Mat Doc Ref</th>
                                                                    <th>Invoice No</th>
                                                                    <th>Supplier</th>
                                                                    <th>Part Number</th>
                                                                    <th>Part Name</th>
                                                                    <th>Description</th>
                                                                    <th>Qty Returned</th>
                                                                    <th>Qty Received</th>
                                                                    <th>Amount</th>
                                                                    <th>Due Date</th>
                                                                    <th>Actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="modal-footer d-flex justify-content-between align-items-center">
                                                    <div class="d-flex align-items-center" style="column-gap:10px;">
                                                                                                                <div class="input-group" style="width: 220px; min-width:160px;">
                                                            <input type="number" class="form-control form-control-sm"
                                                                id="numRowsInput" placeholder="Enter Number of Rows"
                                                                min="1" max="50">
                                                        </div>
                                                        <button type="button" class="btn btn-secondary btn-sm"
                                                            id="addRowsBtn" style="margin-left:8px;">Add Rows</button>
                                                    </div>
                                                    <button type="button" class="btn btn-primary"
                                                        data-dismiss="modal">Done</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-12 text-center">
                                            <button type="submit" class="btn btn-primary">Resubmit RTS Form</button>
                                            <a href="<?php echo BASE_URL; ?>/pages/requests/disapproved_requests.php" class="btn btn-secondary">Cancel</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include INCLUDES_PATH . '/footer.php'; ?>
    </div>
</div>

<script>
    // Global variable to keep track of the row count
    let totalRows = 0;
    
    // Pre-populate existing materials
    const existingMaterials = <?php echo json_encode($form_items); ?>;

    // Function to generate editable table rows based on a number
    function generateTableRows(numberOfRows) {
        let rowsHtml = '';
        const startingIndex = $('#material_details_table tbody tr').length + 1;
        for (let i = 0; i < numberOfRows; i++) {
            const rowNumber = startingIndex + i;
            rowsHtml += `
                <tr data-row-number="${rowNumber}">
                    <td>${rowNumber}</td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[ref_no][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[sap_doc][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[invoice_no][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[supplier][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_number][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_name][]" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[description][]" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_returned][]" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_received][]" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm amount-input" name="material_details[amount][]" placeholder="..."></td>
                    <td><input type="date" class="form-control form-control-sm" name="material_details[due_date][]"></td>
                    <td><button type="button" class="btn btn-danger btn-sm remove-row-btn">Remove</button></td>
                </tr>`;
        }
        totalRows += numberOfRows;
        return rowsHtml;
    }
    
    // Function to populate existing materials
    function populateExistingMaterials() {
        let rowsHtml = '';
        existingMaterials.forEach((material, index) => {
            const rowNumber = index + 1;
            rowsHtml += `
                <tr data-row-number="${rowNumber}">
                    <td>${rowNumber}</td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[ref_no][]" value="${material.ref_no || ''}" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[sap_doc][]" value="${material.sap_mat_doc_ref || ''}" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[invoice_no][]" value="${material.invoice_no || ''}" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[supplier][]" value="${material.supplier || ''}" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_number][]" value="${material.part_number || ''}" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[part_name][]" value="${material.part_name || ''}" placeholder="..."></td>
                    <td><input type="text" class="form-control form-control-sm" name="material_details[description][]" value="${material.description || ''}" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_returned][]" value="${material.qty_returned || ''}" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm" name="material_details[qty_received][]" value="${material.qty_received || ''}" placeholder="..."></td>
                    <td><input type="number" class="form-control form-control-sm amount-input" name="material_details[amount][]" value="${material.amount || ''}" placeholder="..."></td>
                    <td><input type="date" class="form-control form-control-sm" name="material_details[due_date][]" value="${material.due_date || ''}"></td>
                    <td><button type="button" class="btn btn-danger btn-sm remove-row-btn">Remove</button></td>
                </tr>`;
        });
        totalRows = existingMaterials.length;
        return rowsHtml;
    }

    // Function to update the display table on the main form
    function updateDisplayTable() {
        const $editableRows = $('#material_details_table tbody tr');
        const $displayTableBody = $('#material_display_table tbody');
        $displayTableBody.empty(); // Clear existing content

        $editableRows.each(function (index) {
            const $row = $(this);
            const refNo = $row.find('input[name="material_details[ref_no][]"]').val();
            const sapDoc = $row.find('input[name="material_details[sap_doc][]"]').val();
            const invoiceNo = $row.find('input[name="material_details[invoice_no][]"]').val();
            const supplier = $row.find('input[name="material_details[supplier][]"]').val();
            const partNumber = $row.find('input[name="material_details[part_number][]"]').val();
            const qtyReturned = $row.find('input[name="material_details[qty_returned][]"]').val();

            if (refNo || sapDoc || invoiceNo || supplier || partNumber || qtyReturned) {
                const displayRow = `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${refNo}</td>
                        <td>${sapDoc}</td>
                        <td>${invoiceNo}</td>
                        <td>${supplier}</td>
                        <td>${partNumber}</td>
                        <td>${qtyReturned}</td>
                    </tr>`;
                $displayTableBody.append(displayRow);
            }
        });

        if ($displayTableBody.children().length > 0) {
            $('#material_display_section').show();
        } else {
            $('#material_display_section').hide();
        }
    }

    // Function to calculate and display the total amount
    function calculateTotalAmount() {
        let total = 0;
        $('#material_details_table .amount-input').each(function () {
            const amount = parseFloat($(this).val()) || 0;
            total += amount;
        });
        $('#totalAmountDisplay').text(total.toFixed(2));
    }

    // Function to check and display a warning if material count is high
    function checkMaterialCount() {
        const rowCount = $('#material_details_table tbody tr').length;
        if (rowCount > 10) {
            $('#materialCountWarning').show();
        } else {
            $('#materialCountWarning').hide();
        }
    }

    $(document).ready(function () {
        // Populate existing materials when modal is first shown
        $('#materialDetailsModal').one('shown.bs.modal', function () {
            if (existingMaterials.length > 0) {
                $('#material_details_table tbody').append(populateExistingMaterials());
            } else {
                $('#material_details_table tbody').append(generateTableRows(5));
            }
            calculateTotalAmount();
            checkMaterialCount();
        });

        // Handle the "Add Rows" button click
        $('#addRowsBtn').on('click', function () {
            const numRows = parseInt($('#numRowsInput').val());
            if (numRows > 0 && numRows <= 50) {
                $('#material_details_table tbody').append(generateTableRows(numRows));
                calculateTotalAmount();
                checkMaterialCount();
            } else {
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Input',
                    text: 'Please enter a number between 1 and 50.'
                });
            }
        });

        // Remove a row and re-number
        $(document).on('click', '.remove-row-btn', function () {
            $(this).closest('tr').remove();
            $('#material_details_table tbody tr').each(function (index) {
                $(this).find('td:first').text(index + 1);
            });
            calculateTotalAmount();
            checkMaterialCount();
        });

        // Update the display table when the modal is hidden
        $('#materialDetailsModal').on('hidden.bs.modal', function () {
            updateDisplayTable();
        });

        // New event listener for the amount field to trigger total calculation
        $(document).on('input', '.amount-input', function () {
            calculateTotalAmount();
        });

        // Trigger material status change to enable/disable appropriate judgement checkboxes
        $('.material-status-checkbox:checked').trigger('change');

        // Handle logic for material status and judgement checkboxes
        $('.material-status-checkbox, .judgement-checkbox').change(function () {
            const isChecked = $(this).is(':checked');
            const groupClass = $(this).hasClass('material-status-checkbox') ? '.material-status-checkbox' : '.judgement-checkbox';
            if (isChecked) {
                $(groupClass).not(this).prop('checked', false);
            }

            // Check if the changed checkbox belongs to the material status group
            if ($(this).hasClass('material-status-checkbox')) {
                const checkedStatus = $(this).val();
                const $allStatusCheckboxes = $('.material-status-checkbox');
                const $allJudgementCheckboxes = $('.judgement-checkbox');
                const $detailsField = $('#details');

                // Reset all judgement checkboxes and disable them initially
                $allJudgementCheckboxes.prop('checked', false).prop('disabled', true);

                // Always enable the details field if any material status is checked
                $detailsField.prop('disabled', !isChecked);
                if (!isChecked) {
                    $detailsField.val(''); // Clear the field if no status is checked
                }

                if (isChecked) {
                    // Disable all other status checkboxes
                    $allStatusCheckboxes.not(this).prop('disabled', true);

                    // Specific logic for the "NG/Others" checkbox
                    if (checkedStatus === 'NG/Others') {
                        $('#scrapdisposal').prop('disabled', false);
                        $('#hold').prop('disabled', false);
                    } else if (checkedStatus === 'Good') {
                        // This part is for other cases, like 'Good'
                        $('#transfertogood').prop('disabled', false);
                    } else {
                        // This handles the other defect cases
                        $('#scrapdisposal').prop('disabled', false);
                        $('#hold').prop('disabled', false);
                    }
                } else {
                    // If a material status checkbox is unchecked, enable all status checkboxes again
                    $allStatusCheckboxes.prop('disabled', false);
                }
            }
        });

        // The key change to handle the form submission with AJAX
        $('#rtsForm').on('submit', function (e) {
            e.preventDefault(); // Prevent the default form submission

            let isValid = true;
            let errorMessages = [];

            // Perform your existing validation checks here
            if ($('input[name="material_type[]"]:checked').length === 0) {
                isValid = false;
                errorMessages.push('Please select at least one Material Type.');
            }
            if ($('input[name="material_status[]"]:checked').length === 0) {
                isValid = false;
                errorMessages.push('Please select at least one Material Status.');
            }
            const selectedStatus = $('input[name="material_status[]"]:checked').val();
            const hasJudgement = $('input[name="judgement[]"]:checked').length > 0;

            if (selectedStatus === 'NG/Others' && !hasJudgement) {
                isValid = false;
                errorMessages.push('Please select a judgement (Scrap/Disposal or Hold) for NG/Others.');
            } else if (selectedStatus !== 'Good' && selectedStatus !== 'NG/Others' && selectedStatus !== undefined && !hasJudgement) {
                isValid = false;
                errorMessages.push('Please select at least one Judgement.');
            }

            if ($('#return_date').val().trim() === '') {
                isValid = false;
                errorMessages.push('Please select a Return Date.');
            }
            if ($('#department').val().trim() === '') {
                isValid = false;
                errorMessages.push('Please select a Department.');
            }
            
            // SAP LOCATION CODE VALIDATION
            const sapFromLocation = $('select[name="sap_location[from]"]').val();
            const sapToLocation = $('select[name="sap_location[to]"]').val();
            if (!sapFromLocation || !sapToLocation) {
                isValid = false;
                errorMessages.push('Please select both a "From" and "To" SAP Location Code.');
            }
            
            let hasMaterialDetails = false;
            $('#material_details_table tbody tr').each(function () {
                const $rowInputs = $(this).find('input');
                let rowIsFilled = false;
                $rowInputs.each(function () {
                    if ($(this).val().trim() !== '' && !$(this).prop('disabled')) {
                        rowIsFilled = true;
                        return false;
                    }
                });
                if (rowIsFilled) {
                    hasMaterialDetails = true;
                    return false;
                }
            });
            if (!hasMaterialDetails) {
                isValid = false;
                errorMessages.push('Please enter details for at least one material.');
            }

            // If validation fails, show an alert and stop the process.
            if (!isValid) {
                Swal.fire({
                    icon: 'error',
                    title: 'Validation Error',
                    html: errorMessages.join('<br>')
                });
                return;
            }

            // Show the confirmation SweetAlert
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to resubmit this form?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, Resubmit!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show a SweetAlert loading state before the AJAX call
                    Swal.fire({
                        title: 'Resubmitting Form...',
                        text: 'Please wait, sending approval request...',
                        icon: 'info',
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                    
                    // Perform the AJAX submission inside the confirmation block
                    const form = $(this);
                    $.ajax({
                        url: form.attr('action'),
                        type: form.attr('method'),
                        data: form.serialize(),
                        dataType: 'json',
                        success: function (response) {
                            Swal.close(); // Close the loading alert
                            
                            if (response.status === 'success') {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'RTS Form Resubmitted Successfully!',
                                    html: 'Your RTS Control Number is: <strong>' + response.control_no + '</strong>',
                                    confirmButtonText: 'OK'
                                }).then(() => {
                                    window.location.href = `<?php echo BASE_URL; ?>/pages/requests/pending_requests.php`;
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Resubmission Failed!',
                                    text: response.message,
                                    confirmButtonText: 'Try Again'
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.close(); // Close the loading alert on error

                            Swal.fire({
                                icon: 'error',
                                title: 'An error occurred!',
                                text: 'Please try again. ' + xhr.responseText,
                                confirmButtonText: 'OK'
                            });
                        }
                    });
                }
            });
        });
    });
</script>