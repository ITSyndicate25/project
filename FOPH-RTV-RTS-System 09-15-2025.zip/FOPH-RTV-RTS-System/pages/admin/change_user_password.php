<?php
ob_start();
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/includes/functions.php';

header('Content-Type: application/json');
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

// Check for POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    ob_end_flush();
    exit();
}

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied.']);
    ob_end_flush();
    exit();
}

// Retrieve and sanitize data from the POST request
$userId = $_POST['user_id'] ?? null;
$newPassword = $_POST['new_password'] ?? null;

// Basic validation
if (empty($userId) || empty($newPassword)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'User ID and new password are required.']);
    ob_end_flush();
    exit();
}

// Call the function to change the password
$result = changePassword($userId, $newPassword);

// Return the JSON response
echo json_encode($result);

ob_end_flush();
?>