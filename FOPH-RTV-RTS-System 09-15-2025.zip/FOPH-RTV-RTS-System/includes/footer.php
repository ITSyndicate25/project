<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
?>

<footer class="footer footer-black footer-white">
    <div class="container-fluid">
        <div class="row">
            <nav class="footer-nav">
                &copy; 2025 IT Department - Fujifilm Optics Philippines Inc.
            </nav>
        </div>
    </div>
</footer>
</div>
</div>

<script src="<?php echo BASE_URL; ?>/assets/js/core/jquery.min.js"></script>
<script src="<?php echo BASE_URL; ?>/assets/js/core/popper.min.js"></script>
<script src="<?php echo BASE_URL; ?>/assets/js/core/bootstrap.min.js"></script>

<script src="<?php echo BASE_URL; ?>/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<script src="<?php echo BASE_URL; ?>/assets/js/plugins/chartjs.min.js"></script>
<script src="<?php echo BASE_URL; ?>/assets/js/plugins/bootstrap-notify.js"></script>

<script src="<?php echo BASE_URL; ?>/assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.5/dist/sweetalert2.all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.25/datatables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.colVis.min.js"></script>

<script>

    // Keep session active by sending heartbeat every 5 minutes
    function sendHeartbeat() {
        fetch('<?php echo BASE_URL; ?>/includes/heartbeat.php', {
            method: 'POST',
            credentials: 'same-origin'
        })
        .then(response => response.json())
        .then(data => {
            if (data.status !== 'success') {
                console.error('Heartbeat failed:', data.message);
            }
        })
        .catch(error => console.error('Heartbeat error:', error));
    }

    // Send heartbeat every 5 minutes
    setInterval(sendHeartbeat, 300000);

    // Send heartbeat on page load
    sendHeartbeat();

    // Fix mobile sidebar toggle 
    $('.navbar-toggle .navbar-toggler').click(function (e) {
        e.preventDefault();
        console.log("Sidebar toggle clicked");

        // Toggle sidebar visibility
        $('.sidebar').toggleClass('show');
        $('body').toggleClass('nav-open');

        // Toggle burger menu animation
        $(this).toggleClass('toggled');
    });

    // Close sidebar when clicking outside on mobile
    $(document).click(function (e) {
        if (!$(e.target).closest('.sidebar, .navbar-toggle .navbar-toggler').length) {
            $('.sidebar').removeClass('show');
            $('body').removeClass('nav-open');
            $('.navbar-toggle .navbar-toggler').removeClass('toggled');
        }
    });

</script>
</body>

</html>