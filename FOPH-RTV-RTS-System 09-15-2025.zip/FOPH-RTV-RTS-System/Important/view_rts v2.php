<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/FOPH-RTV-RTS-System/config.php';
require_once APP_ROOT . '/assets/db/connection.php';
require_once APP_ROOT . '/includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit();
}

$rts_id = $_GET['id'] ?? null;

// User role and ID from session for dynamic display
$user_role = $_SESSION['user_role'] ?? '';
$user_id = $_SESSION['user_id'] ?? null;

// The function to get all RTS details
$rts_data = getRTSDetails($rts_id);

$rts = $rts_data['rts'];
$items = $rts_data['items'];
$error_message = $rts_data['error_message'];

if ($error_message) {
    echo "<div class='alert alert-danger'>$error_message</div>";
    exit();
}

// Extract signatures if they exist
$prepared_by_signature_base64 = $rts['prepared_by_signature_base64'] ?? null;
$checked_by_signature_base64 = $rts['checked_by_signature_base64'] ?? null;
$approved_by_signature_base64 = $rts['approved_by_signature_base64'] ?? null;
$noted_by_signature_base64 = $rts['noted_by_signature_base64'] ?? null;
?>

<style>
    /* A4 Print Optimized Styles */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    * {
        box-sizing: border-box;
    }

    .rts-document {
        font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        max-width: 210mm;
        min-height: 297mm;
        margin: 0 auto;
        padding: 15mm;
        background: white;
        color: #1a1a1a;
        line-height: 1.4;
        font-size: 11pt;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }

    /* Corporate Header */
    .document-header {
        border-bottom: 3px solid #264c7eff;
        padding-bottom: 15px;
        margin-bottom: 25px;
        position: relative;
    }

    .company-info {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 15px;
    }

    .company-logo {
        max-height: 45px;
        width: auto;
    }

    .company-details {
        text-align: right;
        font-size: 9pt;
        color: #666;
        line-height: 1.3;
    }

    .document-title {
        text-align: center;
        margin: 15px 0 10px 0;
    }

    .document-title h1 {
        font-size: 18pt;
        font-weight: 700;
        color: #1a1a1a;
        margin: 0;
        letter-spacing: 0.5px;
        text-transform: uppercase;
    }

    .document-title .subtitle {
        font-size: 10pt;
        color: #666;
        font-weight: 400;
        margin-top: 3px;
    }

    /* Control Number Box */
    .control-number-box {
        position: absolute;
        right: 0;
        top: 0;
        border: 2px solid #080808ff;
        padding: 8px 12px;
        background: #fff;
        min-width: 120px;
    }

    .control-number-box .label {
        font-size: 8pt;
        color: #666;
        font-weight: 600;
        text-transform: uppercase;
        margin-bottom: 2px;
        display: block;
    }

    .control-number-box .value {
        font-size: 12pt;
        font-weight: 700;
        color: #0a0a0aff;
        font-family: 'Courier New', monospace;
    }

    /* Form Sections */
    .form-section {
        margin-bottom: 20px;
        page-break-inside: avoid;
    }

    .section-header {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        border-left: 4px solid #264c7eff;
        padding: 8px 15px;
        margin-bottom: 12px;
        font-weight: 600;
        font-size: 11pt;
        color: #2c3e50;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    /* Field Grid */
    .field-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 15px;
    }

    .field-group {
        display: flex;
        flex-direction: column;
    }

    .field-label {
        font-size: 8pt;
        font-weight: 600;
        color: #495057;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        margin-bottom: 3px;
        border-bottom: 1px solid #dee2e6;
        padding-bottom: 2px;
    }

    .field-value {
        font-size: 10pt;
        color: #1a1a1a;
        padding: 5px 0;
        min-height: 20px;
        word-wrap: break-word;
        font-weight: 400;
    }

    .field-value.large {
        font-size: 11pt;
        font-weight: 500;
    }

    /* Special Field Types */
    .field-value.status {
        display: inline-block;
        padding: 3px 8px;
        border-radius: 12px;
        font-size: 9pt;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.2px;
    }

    .status.good { background: #d4edda; color: #155724; }
    .status.defect { background: #f8d7da; color: #721c24; }
    .status.error { background: #fff3cd; color: #856404; }
    .status.eol { background: #e2e3e5; color: #383d41; }

    /* Approval Matrix */
    .approval-matrix {
        margin: 20px 0;
        border: 1px solid #dee2e6;
        border-radius: 4px;
        overflow: hidden;
        page-break-inside: avoid;
    }

    .approval-matrix table {
        width: 100%;
        border-collapse: collapse;
        font-size: 9pt;
    }

    .approval-matrix th {
        background: #f8f9fa;
        padding: 10px 8px;
        text-align: center;
        font-weight: 600;
        color: #495057;
        border-right: 1px solid #dee2e6;
        text-transform: uppercase;
        letter-spacing: 0.2px;
    }

    .approval-matrix td {
        padding: 15px 8px;
        text-align: center;
        vertical-align: middle;
        border-right: 1px solid #dee2e6;
        border-bottom: 1px solid #dee2e6;
        min-height: 80px;
    }

    .approval-matrix th:last-child,
    .approval-matrix td:last-child {
        border-right: none;
    }

    .signature-area {
        display: flex;
        flex-direction: column;
        align-items: center;
        min-height: 70px;
        justify-content: space-between;
    }

    .signature-image {
        max-width: 80px;
        max-height: 40px;
        margin-bottom: 5px;
        border: 1px solid #e9ecef;
        border-radius: 3px;
        padding: 2px;
    }

    .signature-name {
        font-weight: 600;
        color: #1a1a1a;
        font-size: 9pt;
        text-align: center;
        margin-bottom: 2px;
    }

    .signature-date {
        font-size: 7pt;
        color: #6c757d;
        text-align: center;
    }

    /* Material Details Table */
    .materials-section {
        margin-top: 25px;
        page-break-inside: avoid;
    }

    .materials-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 8pt;
        margin-top: 10px;
    }

    .materials-table th {
        background: #f8f9fa;
        padding: 8px 6px;
        text-align: center;
        font-weight: 600;
        color: #495057;
        border: 1px solid #dee2e6;
        text-transform: uppercase;
        letter-spacing: 0.1px;
        line-height: 1.2;
    }

    .materials-table td {
        padding: 6px;
        border: 1px solid #dee2e6;
        text-align: left;
        vertical-align: top;
        word-wrap: break-word;
        max-width: 0;
    }

    .materials-table td.number {
        text-align: center;
        font-weight: 500;
    }

    .materials-table td.amount {
        text-align: right;
        font-family: 'Courier New', monospace;
        font-weight: 500;
    }

    .materials-table tbody tr:nth-child(even) {
        background: #f9f9f9;
    }

    .materials-table tbody tr:hover {
        background: #e3f2fd;
    }

    /* Status Alert */
    .status-alert {
        background: #e3f2fd;
        border: 1px solid #2196f3;
        border-radius: 4px;
        padding: 12px 15px;
        margin: 15px 0;
        font-size: 10pt;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .status-alert.completed {
        background: #d4edda;
        border-color: #28a745;
        color: #155724;
    }

    .status-alert.disapproved {
        background: #f8d7da;
        border-color: #dc3545;
        color: #721c24;
    }

    .action-buttons {
        display: flex;
        gap: 8px;
    }

    .btn {
        padding: 6px 12px;
        border: none;
        border-radius: 3px;
        font-size: 9pt;
        font-weight: 500;
        cursor: pointer;
        text-transform: uppercase;
        letter-spacing: 0.2px;
    }

    .btn-approve {
        background: #28a745;
        color: white;
    }

    .btn-disapprove {
        background: #dc3545;
        color: white;
    }

    /* Footer */
    .document-footer {
        margin-top: 30px;
        padding-top: 15px;
        border-top: 1px solid #dee2e6;
        font-size: 8pt;
        color: #6c757d;
        text-align: center;
    }

    /* Print Optimizations */
    @media print {
        .rts-document {
            box-shadow: none;
            margin: 0;
            padding: 15mm;
            max-width: none;
            width: 210mm;
            min-height: 297mm;
        }

        .status-alert,
        .action-buttons,
        .modal-footer {
            display: none !important;
        }

        .approval-matrix td {
            min-height: 60px;
        }

        .materials-table {
            font-size: 7pt;
        }

        .materials-table th,
        .materials-table td {
            padding: 4px;
        }

        .page-break {
            page-break-before: always;
        }

        .no-page-break {
            page-break-inside: avoid;
        }
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .rts-document {
            padding: 10px;
            margin: 10px;
        }

        .company-info {
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .company-details {
            text-align: center;
            margin-top: 10px;
        }

        .control-number-box {
            position: relative;
            margin: 10px auto;
        }

        .field-grid {
            grid-template-columns: 1fr;
        }

        .materials-table {
            font-size: 7pt;
        }

        .approval-matrix {
            overflow-x: auto;
        }
    }

    /* Disapproval Reason */
    .disapproval-reason {
        background: #fff5f5;
        border-left: 4px solid #dc3545;
        padding: 10px 15px;
        margin: 10px 0;
        font-size: 9pt;
        color: #721c24;
    }

    .disapproval-reason .label {
        font-weight: 600;
        text-transform: uppercase;
        font-size: 8pt;
        margin-bottom: 5px;
        display: block;
    }
</style>

<div class="rts-document" id="pdf-content">
    <!-- Document Header -->
    <div class="document-header no-page-break">
        <div class="company-info">
            <img src="<?php echo BASE_URL; ?>/assets/img/logo_black.png" alt="Fujifilm Logo" class="company-logo">
            <div class="company-details">
                <div><strong>FUJIFILM Corporation</strong></div>
                <div>Manufacturing Operations</div>
                <div>Quality Assurance Department</div>
                <div>Document Control System</div>
            </div>
        </div>
        
        <div class="control-number-box">
            <span class="label">Control No.</span>
            <div class="value"><?= htmlspecialchars($rts['control_no'] ?? 'N/A') ?></div>
        </div>

        <div class="document-title">
            <h1>Return / Transfer Slip</h1>
            <div class="subtitle">Centralized Return to Vendor & Return To Stock Monitoring System</div>
        </div>
    </div>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error_message); ?></div>
    <?php elseif ($rts): ?>

        <!-- Request Information -->
        <div class="form-section no-page-break">
            <div class="section-header">
                <i class="fas fa-info-circle"></i> Request Information
            </div>
            <div class="field-grid">
                <div class="field-group">
                    <div class="field-label">Submitted By</div>
                    <div class="field-value large"><?= htmlspecialchars($rts['submitted_by'] ?? 'N/A') ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Department</div>
                    <div class="field-value"><?= htmlspecialchars($rts['department'] ?? 'N/A') ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Date Submitted</div>
                    <div class="field-value"><?= $rts['created_at'] instanceof DateTime ? $rts['created_at']->format('M d, Y') : 'N/A' ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Return Date</div>
                    <div class="field-value"><?= ($rts['return_date'] instanceof DateTime) ? $rts['return_date']->format('M d, Y') : 'N/A' ?></div>
                </div>
            </div>
        </div>

        <!-- Material Classification -->
        <div class="form-section no-page-break">
            <div class="section-header">
                <i class="fas fa-boxes"></i> Material Classification
            </div>
            <div class="field-grid">
                <div class="field-group">
                    <div class="field-label">Material Type</div>
                    <div class="field-value"><?= htmlspecialchars($rts['material_type'] ?? 'N/A') ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Material Status</div>
                    <div class="field-value">
                        <?php
                        $status_value = strtolower($rts['material_status'] ?? '');
                        $status_display = $status_value === 'defective' ? 'Material Defect' : htmlspecialchars($rts['material_status'] ?? 'N/A');
                        $status_class = match($status_value) {
                            'good' => 'good',
                            'defective', 'material defect' => 'defect',
                            'human error' => 'error',
                            'eol' => 'eol',
                            default => 'defect'
                        };
                        ?>
                        <span class="status <?= $status_class ?>"><?= $status_display ?></span>
                    </div>
                </div>
                <div class="field-group">
                    <div class="field-label">Judgement</div>
                    <div class="field-value"><?= htmlspecialchars($rts['judgement'] ?? 'N/A') ?></div>
                </div>
                <div class="field-group">
                    <div class="field-label">Model</div>
                    <div class="field-value"><?= htmlspecialchars($rts['model'] ?? 'N/A') ?></div>
                </div>
            </div>
        </div>

        <!-- SAP Location & Additional Information -->
        <div class="form-section no-page-break">
            <div class="section-header">
                <i class="fas fa-map-marker-alt"></i> Location & Additional Information
            </div>
            <div class="field-grid">
                <div class="field-group" style="grid-column: 1 / -1;">
                    <div class="field-label">SAP Location Details</div>
                    <div class="field-value">
                        <strong>Code:</strong> <?= htmlspecialchars($rts['sap_loc_code'] ?? 'N/A') ?> | 
                        <strong>Description:</strong> <?= htmlspecialchars($rts['LocationDescription'] ?? 'N/A') ?> | 
                        <strong>Department:</strong> <?= htmlspecialchars($rts['sap_department'] ?? 'N/A') ?>
                    </div>
                </div>
                <div class="field-group">
                    <div class="field-label">Details (Others)</div>
                    <div class="field-value">
                        <?= nl2br(htmlspecialchars(empty($rts['details']) ? 'N/A' : $rts['details'])) ?>
                    </div>
                </div>
                <div class="field-group">
                    <div class="field-label">Remarks</div>
                    <div class="field-value">
                        <?= nl2br(htmlspecialchars(empty($rts['remark']) ? 'N/A' : $rts['remark'])) ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Status Alert -->
        <?php
        $show_buttons = false;
        $action_role = '';
        $action_message = '';
        
        $current_status_from_db = $rts['material_status'] ?? 'N/A';

        if ($current_status_from_db === 'Completed') {
            $action_message = 'This request has been successfully completed and approved.';
            $alert_class = 'completed';
        } elseif ($current_status_from_db === 'Disapproved') {
            $disapproved_by_role = $rts['disapproved_by_role'] ?? '';
            $action_message = 'This request has been disapproved.';
            $alert_class = 'disapproved';
        } else {
            $alert_class = '';
            if (str_contains($user_role, 'checker') && ($rts['checked_status'] ?? '') === 'Pending') {
                $show_buttons = true;
                $action_role = 'checker';
                $action_message = 'This request is pending your review as a Checker.';
            } elseif (str_contains($user_role, 'approver') && ($rts['checked_status'] ?? '') === 'Approved' && ($rts['approved_status'] ?? '') === 'Pending') {
                $show_buttons = true;
                $action_role = 'approver';
                $action_message = 'This request is pending your approval as an Approver.';
            } elseif (str_contains($user_role, 'noter') && ($rts['checked_status'] ?? '') === 'Approved' && ($rts['approved_status'] ?? '') === 'Approved' && ($rts['noted_status'] ?? '') === 'Pending') {
                $show_buttons = true;
                $action_role = 'noter';
                $action_message = 'This request is pending your notes as a Noter.';
            } else {
                $action_message = 'This request is currently pending review in the approval workflow.';
            }
        }
        ?>

        <div class="status-alert <?= $alert_class ?> approval-alert">
            <span><strong>Status:</strong> <?= htmlspecialchars($action_message) ?></span>
            <?php if ($show_buttons): ?>
                <div class="action-buttons">
                    <button type="button" class="btn btn-approve approve-btn" 
                            data-rts-id="<?= $rts['id'] ?>" data-role="<?= htmlspecialchars($action_role) ?>">
                        <i class="fa fa-check"></i> Approve
                    </button>
                    <button type="button" class="btn btn-disapprove disapprove-btn" 
                            data-rts-id="<?= $rts['id'] ?>" data-role="<?= htmlspecialchars($action_role) ?>">
                        <i class="fa fa-times"></i> Disapprove
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <!-- Approval Matrix -->
        <div class="form-section no-page-break">
            <div class="section-header">
                <i class="fas fa-clipboard-check"></i> Approval Matrix
            </div>
            
            <div class="approval-matrix">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 25%;">Prepared By</th>
                            <th style="width: 25%;">Checked By</th>
                            <th style="width: 25%;">Approved By</th>
                            <th style="width: 25%;">Noted By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="signature-area">
                                    <?php if (!empty($prepared_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($prepared_by_signature_base64) ?>" 
                                             alt="Prepared By Signature" class="signature-image">
                                    <?php endif; ?>
                                    <div class="signature-name"><?= htmlspecialchars($rts['submitted_by'] ?? 'N/A') ?></div>
                                    <div class="signature-date">
                                        <?= $rts['created_at'] instanceof DateTime ? $rts['created_at']->format('M d, Y \a\t g:i A') : 'N/A' ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="signature-area">
                                    <?php if (($rts['checked_status'] ?? '') === 'Disapproved'): ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/not-approved.jpg'; ?>" 
                                             alt="Disapproved" class="signature-image">
                                    <?php elseif (!empty($checked_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($checked_by_signature_base64) ?>" 
                                             alt="Checked By Signature" class="signature-image">
                                    <?php else: ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" 
                                             alt="Pending" class="signature-image">
                                    <?php endif; ?>
                                    <div class="signature-name"><?= htmlspecialchars($rts['checked_by_name'] ?? 'Pending') ?></div>
                                    <div class="signature-date">
                                        <?= ($rts['checked_at'] ?? null) instanceof DateTime ? $rts['checked_at']->format('M d, Y \a\t g:i A') : 'Pending' ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="signature-area">
                                    <?php if (($rts['approved_status'] ?? '') === 'Disapproved'): ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/not-approved.jpg'; ?>" 
                                             alt="Disapproved" class="signature-image">
                                    <?php elseif (!empty($approved_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($approved_by_signature_base64) ?>" 
                                             alt="Approved By Signature" class="signature-image">
                                    <?php else: ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" 
                                             alt="Pending" class="signature-image">
                                    <?php endif; ?>
                                    <div class="signature-name"><?= htmlspecialchars($rts['approved_by_name'] ?? 'Pending') ?></div>
                                    <div class="signature-date">
                                        <?= ($rts['approved_at'] ?? null) instanceof DateTime ? $rts['approved_at']->format('M d, Y \a\t g:i A') : 'Pending' ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="signature-area">
                                    <?php if (($rts['noted_status'] ?? '') === 'Disapproved'): ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/not-approved.jpg'; ?>" 
                                             alt="Disapproved" class="signature-image">
                                    <?php elseif (!empty($noted_by_signature_base64)): ?>
                                        <img src="<?= htmlspecialchars($noted_by_signature_base64) ?>" 
                                             alt="Noted By Signature" class="signature-image">
                                    <?php else: ?>
                                        <img src="<?= BASE_URL . '/assets/img/e_signiture/pending-stamp.png'; ?>" 
                                             alt="Pending" class="signature-image">
                                    <?php endif; ?>
                                    <div class="signature-name"><?= htmlspecialchars($rts['noted_by_name'] ?? 'Pending') ?></div>
                                    <div class="signature-date">
                                        <?= ($rts['noted_at'] ?? null) instanceof DateTime ? $rts['noted_at']->format('M d, Y \a\t g:i A') : 'Pending' ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <?php if (!empty($rts['disapproval_reason'])): ?>
                <div class="disapproval-reason">
                    <span class="label">Disapproval Reason:</span>
                    <?= htmlspecialchars($rts['disapproval_reason']) ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Material Details -->
        <div class="materials-section page-break">
            <div class="section-header">
                <i class="fas fa-list-alt"></i> Material Details
            </div>
            
            <table class="materials-table">
                <thead>
                    <tr>
                        <th style="width: 4%;">No.</th>
                        <th style="width: 10%;">Ref. No</th>
                        <th style="width: 12%;">SAP Mat Doc Ref</th>
                        <th style="width: 10%;">Invoice No</th>
                        <th style="width: 12%;">Supplier</th>
                        <th style="width: 10%;">Part Number</th>
                        <th style="width: 12%;">Part Name</th>
                        <th style="width: 15%;">Description</th>
                        <th style="width: 6%;">Qty Returned</th>
                        <th style="width: 6%;">Qty Received</th>
                        <th style="width: 8%;">Amount</th>
                        <th style="width: 8%;">Due Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($items)): ?>
                        <tr>
                            <td colspan="12" style="text-align: center; font-style: italic; color: #6c757d; padding: 20px;">
                                No material details found for this request.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php $counter = 1; ?>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td class="number"><?= $counter++ ?></td>
                                <td><?= htmlspecialchars($item['ref_no'] ?? '') ?></td>
                                                                <td><?= htmlspecialchars($item['sap_doc'] ?? '') ?></td>
                                <td><?= htmlspecialchars($item['invoice_no'] ?? '') ?></td>
                                <td><?= htmlspecialchars($item['supplier'] ?? '') ?></td>
                                <td><?= htmlspecialchars($item['part_number'] ?? '') ?></td>
                                <td><?= htmlspecialchars($item['part_name'] ?? '') ?></td>
                                <td><?= htmlspecialchars($item['description'] ?? '') ?></td>
                                <td class="number"><?= is_numeric($item['qty_returned']) ? number_format($item['qty_returned']) : '' ?></td>
                                <td class="number"><?= is_numeric($item['qty_received']) ? number_format($item['qty_received']) : '' ?></td>
                                <td class="amount"><?= is_numeric($item['amount']) ? '₱' . number_format($item['amount'], 2) : '' ?></td>
                                <td class="number"><?= ($item['due_date'] instanceof DateTime) ? $item['due_date']->format('M d, Y') : '' ?></td>
                            </tr>
                        <?php endforeach; ?>
                        
                        <!-- Summary Row -->
                        <?php
                        $total_amount = 0;
                        $total_qty_returned = 0;
                        $total_qty_received = 0;
                        
                        foreach ($items as $item) {
                            if (is_numeric($item['amount'])) $total_amount += $item['amount'];
                            if (is_numeric($item['qty_returned'])) $total_qty_returned += $item['qty_returned'];
                            if (is_numeric($item['qty_received'])) $total_qty_received += $item['qty_received'];
                        }
                        ?>
                        <tr style="background: #f8f9fa; font-weight: 600; border-top: 2px solid #dee2e6;">
                            <td colspan="8" style="text-align: right; padding-right: 10px;">
                                <strong>TOTALS:</strong>
                            </td>
                            <td class="number"><?= number_format($total_qty_returned) ?></td>
                            <td class="number"><?= number_format($total_qty_received) ?></td>
                            <td class="amount" style="color: #e60012; font-weight: 700;">
                                ₱<?= number_format($total_amount, 2) ?>
                            </td>
                            <td></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Document Footer -->
        <div class="document-footer">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <div>
                    <strong>Generated:</strong> <?= date('M d, Y \a\t g:i A') ?><br>
                    <strong>System:</strong> FOPH-RTV-RTS System v1.0
                </div>
                <div style="text-align: right;">
                    <strong>Document ID:</strong> <?= htmlspecialchars($rts['control_no'] ?? 'N/A') ?><br>
                    <strong>Page:</strong> 1 of 1
                </div>
            </div>
            <div style="text-align: center; border-top: 1px solid #dee2e6; padding-top: 10px; color: #6c757d;">
                <small>
                    This document is generated electronically.<br>
                    For questions or concerns, please contact the IT Department.
                </small>
            </div>
        </div>

    <?php endif; ?>
</div>

<!-- Modal Footer with Actions -->
<div class="modal-footer" style="background: #f8f9fa; border-top: 2px solid #dee2e6; padding: 15px;">
    <div style="display: flex; justify-content: space-between; width: 100%; align-items: center;">
        <div style="font-size: 10pt; color: #6c757d;">
            <i class="fas fa-info-circle"></i> 
            Document optimized for printing 
        </div>
        <div>
            <button type="button" class="btn" id="downloadPdfBtn" 
                    style="background: #088be2ff; color: white; margin-right: 10px; padding: 8px 16px; border-radius: 4px; font-weight: 500;">
                <i class="fas fa-download"></i> Save as PDF
            </button>
            <button type="button" class="btn" onclick="window.print()" 
                    style="background: #6c757d; color: white; margin-right: 10px; padding: 8px 16px; border-radius: 4px; font-weight: 500;">
                <i class="fas fa-print"></i> Print
            </button>
            <button type="button" class="btn" data-dismiss="modal" 
                    style="background: #f8f9fa; color: #495057; border: 1px solid #dee2e6; padding: 8px 16px; border-radius: 4px; font-weight: 500;">
                <i class="fas fa-times"></i> Close
            </button>
        </div>
    </div>
</div>

<script>
 document.addEventListener('DOMContentLoaded', function() {
        // Enhanced print functionality
        const printBtn = document.querySelector('button[onclick="window.print()"]');
        if (printBtn) {
            printBtn.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Add print-specific styles before printing
                const printStyles = document.createElement('style');
                printStyles.id = 'print-styles';
                printStyles.textContent = `
                    @media print {
                        body * { visibility: hidden; }
                        #pdf-content, #pdf-content * { visibility: visible; }
                        #pdf-content { 
                            position: absolute; 
                            left: 0; 
                            top: 0; 
                            width: 100% !important;
                            margin: 0 !important;
                            padding: 15mm !important;
                        }
                        .modal-footer { display: none !important; }
                        .status-alert { display: none !important; }
                        .action-buttons { display: none !important; }
                    }
                `;
                document.head.appendChild(printStyles);
                
                // Print the document
                window.print();
                
                // Remove print styles after printing
                setTimeout(() => {
                    const styleElement = document.getElementById('print-styles');
                    if (styleElement) {
                        styleElement.remove();
                    }
                }, 1000);
            });
        }

        // PDF download functionality (if you have a PDF generation endpoint)
        const pdfBtn = document.getElementById('downloadPdfBtn');
        if (pdfBtn) {
            pdfBtn.addEventListener('click', function() {
                const rtsId = new URLSearchParams(window.location.search).get('id') || 
                             document.querySelector('[data-rts-id]')?.dataset.rtsId;
                
                if (rtsId) {
                    // Create a form to submit the PDF request
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '<?php echo BASE_URL; ?>/generate_pdf.php';
                    form.target = '_blank';
                    
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'rts_id';
                    input.value = rtsId;
                    
                    form.appendChild(input);
                    document.body.appendChild(form);
                    form.submit();
                    document.body.removeChild(form);
                } else {
                    alert('Unable to generate PDF. RTS ID not found.');
                }
            });
        }

        // Approval button functionality (keeping your existing logic)
        document.querySelectorAll('.approve-btn, .disapprove-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const action = this.classList.contains('approve-btn') ? 'approve' : 'disapprove';
                const rtsId = this.dataset.rtsId;
                const role = this.dataset.role;
                
                // Your existing approval/disapproval logic here
                console.log(`${action} action for RTS ${rtsId} by ${role}`);
            });
        });

        // Responsive table handling for mobile
        function handleResponsiveTable() {
            const table = document.querySelector('.materials-table');
            const container = table?.parentElement;
            
            if (table && window.innerWidth <= 768) {
                if (!container.style.overflowX) {
                    container.style.overflowX = 'auto';
                    container.style.webkitOverflowScrolling = 'touch';
                }
            }
        }

        // Initial check and resize listener
        handleResponsiveTable();
        window.addEventListener('resize', handleResponsiveTable);
    });
</script>