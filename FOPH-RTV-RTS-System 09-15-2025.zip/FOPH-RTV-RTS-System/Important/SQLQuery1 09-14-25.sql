﻿use dbfophcrtvsproject;

SELECT * FROM users;
SELECT * FROM rts_forms;
SELECT * FROM rts_materials;
SELECT * FROM rts_sequence;
SELECT * FROM sap_loc_code;
SELECT * FROM active_sessions;

CREATE TABLE users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(50) NOT NULL UNIQUE,
    password NVARCHAR(255) NOT NULL,
	requestor_name NVARCHAR(100),
    role NVARCHAR(20) NOT NULL DEFAULT 'user'
	id_number NVARCHAR (50) NOT NULL,
    email NVARCHAR(100) NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    is_active BIT DEFAULT 1
	department NVARCHAR (50) NOT NULL,
	category NVARCHAR(100) NOT NULL,
	e_signiture VARBINARY(MAX),
	last_login DATETIME NULL
);

CREATE TABLE [dbo].[rts_forms] (
    [id] INT IDENTITY(1,1) PRIMARY KEY,
    [control_no] NVARCHAR(100) NOT NULL,
    [requestor_id] INT NOT NULL,
    [requestor_name] NVARCHAR(255) NOT NULL,
    [requestor_department] NVARCHAR(255),
    [material_type] NVARCHAR(255),
    [material_status] NVARCHAR(100),
    [judgement] NVARCHAR(255),
    [details] NVARCHAR(MAX),
    [return_date] DATE,
    [department] NVARCHAR(100),
    [model] NVARCHAR(100),
    [sap_loc_code] NVARCHAR(100),
    [prepared_by] NVARCHAR(255),
    [checked_by] NVARCHAR(255),
    [approved_by] NVARCHAR(255),
    [noted_by] NVARCHAR(255),
    [created_at] DATETIME DEFAULT GETDATE(),
    [checked_status] NVARCHAR(50),
    [approved_status] NVARCHAR(50),
    [noted_status] NVARCHAR(50),
    [checked_by_id] INT,
    [approved_by_id] INT,
    [noted_by_id] INT,
    [checked_at] DATETIME,
    [approved_at] DATETIME,
    [noted_at] DATETIME,
    [remark] NVARCHAR(MAX),
    [prepared_by_signature_image] VARBINARY(MAX),
    [checked_by_signature_image] VARBINARY(MAX),
    [approved_by_signature_image] VARBINARY(MAX),
    [noted_by_signature_image] VARBINARY(MAX),
    [disapproval_reason] NVARCHAR(255),
    [disapproved_by_role] NVARCHAR(50),
    [resubmission_count] INT DEFAULT 0,
    [original_material_status_selection] NVARCHAR(255),
    [resubmitted_at] DATETIME
    -- Optionally, add foreign key constraints as appropriate for your structure
);

CREATE TABLE [dbo].[rts_materials] (
    [id] INT IDENTITY(1,1) PRIMARY KEY,
    [rts_form_id] INT NOT NULL,
    [ref_no] NVARCHAR(100),
    [sap_doc] NVARCHAR(100),
    [invoice_no] NVARCHAR(100),
    [supplier] NVARCHAR(255),
    [part_name] NVARCHAR(255),
    [part_number] NVARCHAR(100),
    [description] NVARCHAR(255),
    [qty_returned] INT,
    [qty_received] INT,
    [amount] FLOAT,
    [received_by] NVARCHAR(255),
    [due_date] DATE,
    -- Add FK constraint to rts_forms if desired
    FOREIGN KEY ([rts_form_id]) REFERENCES [dbo].[rts_forms]([id]) ON DELETE CASCADE
);

CREATE TABLE sap_loc_code (
    LocationCode VARCHAR(10) PRIMARY KEY,
    LocationDescription VARCHAR(50),
    Department VARCHAR(50)
);

	CREATE TABLE dbo.rts_Sequence (
    id INT PRIMARY KEY IDENTITY(1,1),
    current_year INT,
    current_month INT,
    current_sequence INT,
    updated_at DATETIME DEFAULT GETDATE()
);

CREATE TABLE active_sessions (
    session_id VARCHAR(255) PRIMARY KEY,
    user_id INT NOT NULL,
    last_activity DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);


INSERT INTO users (username, password, requestor_name, role, department, id_number, email, category, created_at, updated_at, is_active)
VALUES ('admin', '$2y$10$SFBaeHTrXp5/Xd/LvleyYuNzJ9ffu/gXsRb8bL0nrzaDYsKtVqIOy', 'System Administrator', 'admin', 'IT', '83912077', 'admin@foph.com', 'Good', GETDATE(), GETDATE(), 1);


DELETE FROM rts_materials;
DELETE FROM rts_forms;
DELETE FROM rts_sequence;

DROP TABLE user_approver_roles;

INSERT INTO sap_loc_code (LocationCode, LocationDescription, Department)
VALUES
('1021', 'Instax WH', 'INSTAX'),
('1022', 'Instax Assy', 'INSTAX'),
('1101', 'Instax-EOL/EN', 'INSTAX'),
('102Y', 'InstaxMD/HOParts', 'INSTAX'),
('110Z', 'INSTAX-SCRAP DISPOSAL', 'INSTAX')

DROP SEQUENCE IF EXISTS dbo.RTS_ControlNo_Seq;

CREATE SEQUENCE dbo.RTS_ControlNo_Seq
    START WITH 1
    INCREMENT BY 1
    MINVALUE 1
    MAXVALUE 999999
    NO CYCLE;

INSERT INTO dbo.rts_Sequence (current_year, current_month, current_sequence)
VALUES (YEAR(GETDATE()), MONTH(GETDATE()), 0);;

DELETE FROM rts_forms
WHERE id = 1003;






